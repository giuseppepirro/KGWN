#!/usr/bin/env python3
from __future__ import annotations

import argparse
import re
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Iterable, List, Tuple

import torch
from tqdm import tqdm

from datasets import KGDataset
from inductive.data.split_inductive import (
    InductiveSplit,
    assert_split_sane,
    load_split,
    make_entity_disjoint_split,
    save_split,
)
from inductive.data.subgraph import EnclosingSubgraphExtractor
from inductive.pipeline import (
    augment_with_inverse,
    build_known_true_set,
    edge_index_and_type_from_triples,
    sample_negatives_for_pos,
)


_VERSIONED_DATASET_RE = re.compile(r".*_v\d+_ind$")
_VERSION_ONLY_RE = re.compile(r".*_v\d+$")


def _resolve_inductive_root(data_root: str, *, induction_kind: str) -> str:
    root = Path(data_root)
    if root.name in {"entities", "relations"}:
        return str(root)
    subdir = "relations" if str(induction_kind).lower() == "relation" else "entities"
    return str(root / subdir)


def _list_dirs(data_root: str) -> List[str]:
    root = Path(data_root)
    if not root.exists():
        return []
    return sorted([p.name for p in root.iterdir() if p.is_dir()])


def _expand_entity_datasets(dataset: str, *, data_root: str) -> List[str]:
    if _VERSIONED_DATASET_RE.match(dataset):
        return [dataset]
    root = Path(data_root)
    versioned = []
    for v in range(1, 5):
        candidate = f"{dataset}_v{v}_ind"
        if (root / candidate).exists():
            versioned.append(candidate)
    if versioned:
        return versioned
    if _VERSION_ONLY_RE.match(dataset):
        candidate = f"{dataset}_ind"
        if (root / candidate).exists():
            return [candidate]
    return [dataset]


def _expand_relation_datasets(dataset: str, *, data_root: str) -> List[str]:
    root = Path(data_root)
    if (root / dataset).is_dir():
        return [dataset]
    prefix = f"{dataset}-".lower()
    choices = _list_dirs(data_root)
    matches = [name for name in choices if name.lower().startswith(prefix)]
    if not matches:
        return []

    def sort_key(name: str) -> Tuple[int, object]:
        tail = name.split("-")[-1]
        try:
            return (0, int(tail))
        except ValueError:
            return (1, name.lower())

    return sorted(matches, key=sort_key)


def _default_split_dir(*, data_root: str, dataset: str, p_test: float, p_val: float, seed: int) -> Path:
    tag = f"pTest{p_test:.2f}_pVal{p_val:.2f}_seed{int(seed):02d}".replace(".", "")
    return Path(data_root) / dataset / "inductive" / tag


def _split_from_dataset_splits(
    ds: KGDataset,
    *,
    seed: int,
    p_test_entities: float,
    p_val_triples: float,
    num_relations_original: int,
) -> InductiveSplit:
    train_pos = ds.train_data.to(dtype=torch.long, device="cpu")
    val_pos = ds.valid_data.to(dtype=torch.long, device="cpu")
    test_pos = ds.test_data.to(dtype=torch.long, device="cpu")

    if val_pos.numel() > 0:
        v_train = torch.unique(torch.cat([train_pos[:, [0, 2]], val_pos[:, [0, 2]]], dim=0).reshape(-1))
    else:
        v_train = torch.unique(train_pos[:, [0, 2]].reshape(-1)) if train_pos.numel() > 0 else torch.empty(0, dtype=torch.long)

    if test_pos.numel() > 0:
        v_test_all = torch.unique(test_pos[:, [0, 2]].reshape(-1))
        if v_train.numel() > 0:
            v_test = v_test_all[~torch.isin(v_test_all, v_train)]
        else:
            v_test = v_test_all
    else:
        v_test = torch.empty(0, dtype=torch.long)

    return InductiveSplit(
        dataset=str(ds.name),
        seed=int(seed),
        p_test_entities=float(p_test_entities),
        p_val_triples=float(p_val_triples),
        num_entities=int(ds.num_entities),
        num_relations=int(ds.num_relations),
        num_relations_original=int(num_relations_original),
        v_train=v_train.to(dtype=torch.long),
        v_test=v_test.to(dtype=torch.long),
        train_pos=train_pos.to(dtype=torch.long),
        val_pos=val_pos.to(dtype=torch.long),
        test_pos=test_pos.to(dtype=torch.long),
    )


def _pair_key(h: int, t: int) -> Tuple[int, int]:
    a = int(h)
    b = int(t)
    return (a, b) if a <= b else (b, a)


def _unique_pairs(triples: torch.Tensor) -> List[Tuple[int, int]]:
    pairs = set()
    for h, _, t in triples.to(dtype=torch.long, device="cpu").tolist():
        pairs.add(_pair_key(int(h), int(t)))
    return list(pairs)


def _collect_negative_pairs(
    *,
    triples: torch.Tensor,
    entity_pool: torch.Tensor,
    known_true: set[tuple[int, int, int]],
    num_neg: int,
    epoch_key: int,
) -> List[Tuple[int, int]]:
    if int(num_neg) <= 0:
        return []
    pairs = set()
    for row in triples.to(dtype=torch.long, device="cpu"):
        negs = sample_negatives_for_pos(
            row,
            num_neg=int(num_neg),
            entity_pool=entity_pool,
            known_true=known_true,
            epoch=int(epoch_key),
        )
        for nh, _, nt in negs.tolist():
            pairs.add(_pair_key(int(nh), int(nt)))
    return list(pairs)


def _precompute_pairs(
    *,
    name: str,
    extractor: EnclosingSubgraphExtractor,
    pairs: Iterable[Tuple[int, int]],
    k_hops: int,
    num_workers: int,
) -> None:
    pair_list = list(pairs)
    if not pair_list:
        return
    desc = f"{name} ({len(pair_list)} pairs)"

    def _extract_one(pair: Tuple[int, int]) -> int:
        h, t = pair
        extractor.extract(int(h), int(t), k_hops=int(k_hops))
        return 1

    if int(num_workers) <= 1:
        for pair in tqdm(pair_list, desc=desc, unit="pair"):
            _extract_one(pair)
        return

    with ThreadPoolExecutor(max_workers=int(num_workers)) as executor:
        list(tqdm(executor.map(_extract_one, pair_list), total=len(pair_list), desc=desc, unit="pair"))


def _precompute_entity_dataset(args: argparse.Namespace, dataset: str) -> None:
    ds = KGDataset(root=str(args.data_root), name=str(dataset), download=False, percentage=1.0)
    num_relations_total = int(ds.num_relations)
    num_relations_original = int(num_relations_total // 2)

    split_dir = Path(args.split_dir) if args.split_dir else _default_split_dir(
        data_root=str(args.data_root),
        dataset=str(dataset),
        p_test=float(args.p_test_entities),
        p_val=float(args.p_val_triples),
        seed=int(args.seed),
    )

    if args.force_split:
        all_triples = torch.cat([ds.train_data, ds.valid_data, ds.test_data], dim=0)
        split = make_entity_disjoint_split(
            all_triples,
            dataset=str(dataset),
            num_entities=int(ds.num_entities),
            num_relations=num_relations_total,
            num_relations_original=num_relations_original,
            p_test_entities=float(args.p_test_entities),
            p_val_triples=float(args.p_val_triples),
            seed=int(args.seed),
            min_rel_train=int(args.min_rel_train),
        )
        save_split(split, split_dir)
    elif split_dir.exists():
        split = load_split(split_dir)
    elif str(dataset).lower().endswith("_ind"):
        split = _split_from_dataset_splits(
            ds,
            seed=int(args.seed),
            p_test_entities=float(args.p_test_entities),
            p_val_triples=float(args.p_val_triples),
            num_relations_original=num_relations_original,
        )
        save_split(split, split_dir)
    else:
        all_triples = torch.cat([ds.train_data, ds.valid_data, ds.test_data], dim=0)
        split = make_entity_disjoint_split(
            all_triples,
            dataset=str(dataset),
            num_entities=int(ds.num_entities),
            num_relations=num_relations_total,
            num_relations_original=num_relations_original,
            p_test_entities=float(args.p_test_entities),
            p_val_triples=float(args.p_val_triples),
            seed=int(args.seed),
            min_rel_train=int(args.min_rel_train),
        )
        save_split(split, split_dir)

    assert_split_sane(split)

    train_graph = split.train_pos
    test_graph = split.test_pos
    if bool(args.use_augmented_graph):
        train_graph = augment_with_inverse(train_graph, num_relations_original=num_relations_original)
        test_graph = augment_with_inverse(test_graph, num_relations_original=num_relations_original)

    train_edge_index, train_edge_type = edge_index_and_type_from_triples(train_graph)
    test_edge_index, test_edge_type = edge_index_and_type_from_triples(test_graph)

    cache_root = Path(args.subgraph_cache_dir) if args.subgraph_cache_dir else split_dir / f"subgraphs_k{int(args.k_hops)}"
    extractor_train = EnclosingSubgraphExtractor(
        num_nodes=int(split.num_entities),
        edge_index=train_edge_index,
        edge_type=train_edge_type,
        cache_dir=str(cache_root / "train"),
    )
    extractor_test = EnclosingSubgraphExtractor(
        num_nodes=int(split.num_entities),
        edge_index=test_edge_index,
        edge_type=test_edge_type,
        cache_dir=str(cache_root / "test"),
    )

    train_pairs = set(_unique_pairs(split.train_pos))
    val_pairs = set(_unique_pairs(split.val_pos)) if split.val_pos.numel() > 0 else set()
    test_pairs = set(_unique_pairs(split.test_pos))

    if int(args.neg_per_pos) > 0:
        known_train = build_known_true_set(split.train_pos)
        entity_pool_train = split.v_train.to(dtype=torch.long, device="cpu") if split.v_train.numel() > 0 else torch.unique(split.train_pos[:, [0, 2]].reshape(-1))
        for epoch in range(1, int(args.neg_epochs) + 1):
            neg_pairs = _collect_negative_pairs(
                triples=split.train_pos,
                entity_pool=entity_pool_train,
                known_true=known_train,
                num_neg=int(args.neg_per_pos),
                epoch_key=int(args.seed) + epoch,
            )
            train_pairs.update(neg_pairs)

    if int(args.eval_neg_per_pos) > 0 and split.val_pos.numel() > 0:
        known_val = build_known_true_set(torch.cat([split.train_pos, split.val_pos], dim=0))
        entity_pool_train = split.v_train.to(dtype=torch.long, device="cpu") if split.v_train.numel() > 0 else torch.unique(split.train_pos[:, [0, 2]].reshape(-1))
        for epoch in range(1, int(args.eval_epochs) + 1):
            neg_pairs = _collect_negative_pairs(
                triples=split.val_pos,
                entity_pool=entity_pool_train,
                known_true=known_val,
                num_neg=int(args.eval_neg_per_pos),
                epoch_key=int(args.seed) + 10_000 + epoch,
            )
            val_pairs.update(neg_pairs)

    if int(args.eval_neg_per_pos) > 0:
        known_test = build_known_true_set(split.test_pos)
        if test_graph.numel() > 0:
            entity_pool_test = torch.unique(test_graph[:, [0, 2]].reshape(-1))
        else:
            entity_pool_test = split.v_test.to(dtype=torch.long, device="cpu")
        neg_pairs = _collect_negative_pairs(
            triples=split.test_pos,
            entity_pool=entity_pool_test,
            known_true=known_test,
            num_neg=int(args.eval_neg_per_pos),
            epoch_key=int(args.seed) + 20_000,
        )
        test_pairs.update(neg_pairs)

    _precompute_pairs(
        name=f"{dataset} train",
        extractor=extractor_train,
        pairs=sorted(train_pairs),
        k_hops=int(args.k_hops),
        num_workers=int(args.num_workers),
    )
    if val_pairs:
        _precompute_pairs(
            name=f"{dataset} val",
            extractor=extractor_train,
            pairs=sorted(val_pairs),
            k_hops=int(args.k_hops),
            num_workers=int(args.num_workers),
        )
    _precompute_pairs(
        name=f"{dataset} test",
        extractor=extractor_test,
        pairs=sorted(test_pairs),
        k_hops=int(args.k_hops),
        num_workers=int(args.num_workers),
    )

    if bool(args.precompute_relation_graphs):
        from inductive.relation_induction import build_relation_graph_cached

        rel_cache_root = Path(args.relation_graph_cache_dir) if args.relation_graph_cache_dir else split_dir / "relation_graphs"
        rel_text_path = Path(args.relation_text_features_path) if args.relation_text_features_path else (
            Path(args.data_root) / dataset / "text_features_relations_bert-base-uncased_cls_L32.pt"
        )
        if rel_text_path.exists():
            rel_text_feats = torch.load(rel_text_path, map_location="cpu")
        else:
            rel_text_feats = None

        build_relation_graph_cached(
            train_graph,
            num_relations=num_relations_total,
            rel_text_features=rel_text_feats,
            cooc_weight=float(args.relation_graph_cooc_weight),
            text_weight=float(args.relation_graph_text_weight),
            text_topk=int(args.relation_graph_topk),
            text_min_sim=float(args.relation_graph_min_sim),
            cache_dir=rel_cache_root,
            cache_tag="train",
        )
        build_relation_graph_cached(
            test_graph,
            num_relations=num_relations_total,
            rel_text_features=rel_text_feats,
            cooc_weight=float(args.relation_graph_cooc_weight),
            text_weight=float(args.relation_graph_text_weight),
            text_topk=int(args.relation_graph_topk),
            text_min_sim=float(args.relation_graph_min_sim),
            cache_dir=rel_cache_root,
            cache_tag="test",
        )


def _precompute_relation_dataset(args: argparse.Namespace, dataset: str) -> None:
    ds = KGDataset(root=str(args.data_root), name=str(dataset), download=False, percentage=1.0)
    num_relations_total = int(ds.num_relations)
    num_relations_original = int(num_relations_total // 2)

    split_dir = Path(args.split_dir) if args.split_dir else _default_split_dir(
        data_root=str(args.data_root),
        dataset=str(dataset),
        p_test=float(args.p_test_entities),
        p_val=float(args.p_val_triples),
        seed=int(args.seed),
    )

    if args.force_split or not split_dir.exists():
        all_triples = torch.cat([ds.train_data, ds.valid_data, ds.test_data], dim=0)
        split = make_entity_disjoint_split(
            all_triples,
            dataset=str(dataset),
            num_entities=int(ds.num_entities),
            num_relations=num_relations_total,
            num_relations_original=num_relations_original,
            p_test_entities=float(args.p_test_entities),
            p_val_triples=float(args.p_val_triples),
            seed=int(args.seed),
            min_rel_train=int(args.min_rel_train),
        )
        save_split(split, split_dir)
    else:
        split = load_split(split_dir)

    assert_split_sane(split)

    train_graph = split.train_pos
    if split.val_pos.numel() > 0:
        train_graph = torch.cat([train_graph, split.val_pos], dim=0)
    test_graph = split.test_pos
    if bool(args.use_augmented_graph):
        train_graph = augment_with_inverse(train_graph, num_relations_original=num_relations_original)
        test_graph = augment_with_inverse(test_graph, num_relations_original=num_relations_original)

    train_edge_index, train_edge_type = edge_index_and_type_from_triples(train_graph)
    test_edge_index, test_edge_type = edge_index_and_type_from_triples(test_graph)

    cache_root = Path(args.subgraph_cache_dir) if args.subgraph_cache_dir else split_dir / f"subgraphs_k{int(args.k_hops)}"
    extractor_train = EnclosingSubgraphExtractor(
        num_nodes=int(split.num_entities),
        edge_index=train_edge_index,
        edge_type=train_edge_type,
        cache_dir=str(cache_root / "train"),
    )
    extractor_test = EnclosingSubgraphExtractor(
        num_nodes=int(split.num_entities),
        edge_index=test_edge_index,
        edge_type=test_edge_type,
        cache_dir=str(cache_root / "test"),
    )

    train_pairs = set(_unique_pairs(split.train_pos))
    val_pairs = set(_unique_pairs(split.val_pos)) if split.val_pos.numel() > 0 else set()
    test_pairs = set(_unique_pairs(split.test_pos))

    if int(args.neg_per_pos) > 0:
        known_train = build_known_true_set(split.train_pos)
        entity_pool_train = split.v_train.to(dtype=torch.long, device="cpu") if split.v_train.numel() > 0 else torch.unique(split.train_pos[:, [0, 2]].reshape(-1))
        for epoch in range(1, int(args.neg_epochs) + 1):
            neg_pairs = _collect_negative_pairs(
                triples=split.train_pos,
                entity_pool=entity_pool_train,
                known_true=known_train,
                num_neg=int(args.neg_per_pos),
                epoch_key=int(args.seed) + epoch,
            )
            train_pairs.update(neg_pairs)

    if int(args.eval_neg_per_pos) > 0 and split.val_pos.numel() > 0:
        known_val = build_known_true_set(torch.cat([split.train_pos, split.val_pos], dim=0))
        entity_pool_train = split.v_train.to(dtype=torch.long, device="cpu") if split.v_train.numel() > 0 else torch.unique(split.train_pos[:, [0, 2]].reshape(-1))
        for epoch in range(1, int(args.eval_epochs) + 1):
            neg_pairs = _collect_negative_pairs(
                triples=split.val_pos,
                entity_pool=entity_pool_train,
                known_true=known_val,
                num_neg=int(args.eval_neg_per_pos),
                epoch_key=int(args.seed) + 10_000 + epoch,
            )
            val_pairs.update(neg_pairs)

    if int(args.eval_neg_per_pos) > 0:
        known_test = build_known_true_set(split.test_pos)
        if test_graph.numel() > 0:
            entity_pool_test = torch.unique(test_graph[:, [0, 2]].reshape(-1))
        else:
            entity_pool_test = split.v_test.to(dtype=torch.long, device="cpu")
        neg_pairs = _collect_negative_pairs(
            triples=split.test_pos,
            entity_pool=entity_pool_test,
            known_true=known_test,
            num_neg=int(args.eval_neg_per_pos),
            epoch_key=int(args.seed) + 20_000,
        )
        test_pairs.update(neg_pairs)

    _precompute_pairs(
        name=f"{dataset} train",
        extractor=extractor_train,
        pairs=sorted(train_pairs),
        k_hops=int(args.k_hops),
        num_workers=int(args.num_workers),
    )
    if val_pairs:
        _precompute_pairs(
            name=f"{dataset} val",
            extractor=extractor_train,
            pairs=sorted(val_pairs),
            k_hops=int(args.k_hops),
            num_workers=int(args.num_workers),
        )
    _precompute_pairs(
        name=f"{dataset} test",
        extractor=extractor_test,
        pairs=sorted(test_pairs),
        k_hops=int(args.k_hops),
        num_workers=int(args.num_workers),
    )

    if bool(args.precompute_relation_graphs):
        from inductive.relation_induction import build_relation_graph_cached

        rel_cache_root = Path(args.relation_graph_cache_dir) if args.relation_graph_cache_dir else split_dir / "relation_graphs"
        rel_text_path = Path(args.relation_text_features_path) if args.relation_text_features_path else (
            Path(args.data_root) / dataset / "text_features_relations_bert-base-uncased_cls_L32.pt"
        )
        if rel_text_path.exists():
            rel_text_feats = torch.load(rel_text_path, map_location="cpu")
        else:
            rel_text_feats = None

        build_relation_graph_cached(
            train_graph,
            num_relations=num_relations_total,
            rel_text_features=rel_text_feats,
            cooc_weight=float(args.relation_graph_cooc_weight),
            text_weight=float(args.relation_graph_text_weight),
            text_topk=int(args.relation_graph_topk),
            text_min_sim=float(args.relation_graph_min_sim),
            cache_dir=rel_cache_root,
            cache_tag="train",
        )
        build_relation_graph_cached(
            test_graph,
            num_relations=num_relations_total,
            rel_text_features=rel_text_feats,
            cooc_weight=float(args.relation_graph_cooc_weight),
            text_weight=float(args.relation_graph_text_weight),
            text_topk=int(args.relation_graph_topk),
            text_min_sim=float(args.relation_graph_min_sim),
            cache_dir=rel_cache_root,
            cache_tag="test",
        )


def main() -> int:
    p = argparse.ArgumentParser(description="Precompute and cache all k-hop subgraphs for inductive splits.")
    p.add_argument("--dataset", type=str, required=True)
    p.add_argument("--induction_kind", type=str, default="entity", choices=["entity", "relation"])
    p.add_argument("--data_root", type=str, default="src/data/inductive")
    p.add_argument("--split_dir", type=str, default=None)
    p.add_argument("--p_test_entities", type=float, default=0.2)
    p.add_argument("--p_val_triples", type=float, default=0.05)
    p.add_argument("--min_rel_train", type=int, default=1)
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--force_split", action="store_true")
    p.add_argument("--k_hops", type=int, default=2)
    p.add_argument("--use_augmented_graph", action="store_true")
    p.add_argument("--subgraph_cache_dir", type=str, default=None)
    p.add_argument("--num_workers", type=int, default=4)
    p.add_argument("--neg_per_pos", type=int, default=0, help="Negatives per positive to precompute (train).")
    p.add_argument("--neg_epochs", type=int, default=1, help="Epochs of training negatives to precompute.")
    p.add_argument("--eval_neg_per_pos", type=int, default=0, help="Negatives per positive to precompute for val/test.")
    p.add_argument("--eval_epochs", type=int, default=1, help="Epochs of validation negatives to precompute.")
    p.add_argument("--precompute_relation_graphs", action="store_true", help="Also precompute cached relation graphs.")
    p.add_argument("--relation_graph_cache_dir", type=str, default=None)
    p.add_argument("--relation_graph_topk", type=int, default=10)
    p.add_argument("--relation_graph_min_sim", type=float, default=0.0)
    p.add_argument("--relation_graph_cooc_weight", type=float, default=1.0)
    p.add_argument("--relation_graph_text_weight", type=float, default=1.0)
    p.add_argument("--relation_text_features_path", type=str, default=None)
    args = p.parse_args()

    resolved_root = _resolve_inductive_root(str(args.data_root), induction_kind=str(args.induction_kind))
    args.data_root = str(resolved_root)

    if str(args.induction_kind).lower() == "relation":
        datasets = _expand_relation_datasets(str(args.dataset), data_root=str(args.data_root))
        if not datasets:
            choices = _list_dirs(str(args.data_root))
            raise SystemExit(f"Unknown relation dataset '{args.dataset}'. Available choices: {', '.join(choices)}")
        if len(datasets) > 1:
            print(f"Expanded dataset '{args.dataset}' to {len(datasets)} versions: {', '.join(datasets)}")
        for ds in datasets:
            _precompute_relation_dataset(args, ds)
    else:
        datasets = _expand_entity_datasets(str(args.dataset), data_root=str(args.data_root))
        if len(datasets) > 1:
            print(f"Expanded dataset '{args.dataset}' to {len(datasets)} versions: {', '.join(datasets)}")
        for ds in datasets:
            _precompute_entity_dataset(args, ds)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
