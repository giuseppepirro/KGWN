#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
import resource
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

import numpy as np
import torch
import torch.nn as nn

from datasets import KGDataset
from inductive.data.adaprop_benchmark import load_adaprop_benchmark
from inductive.data.split_inductive import assert_split_sane, load_split, make_entity_disjoint_split, save_split
from inductive.data.subgraph import EnclosingSubgraphExtractor
from inductive.pipeline import (
    augment_with_inverse,
    build_known_true_set,
    edge_index_and_type_from_triples,
    sample_negatives_for_pos,
)
from inductive.relation_metrics import relation_ranking_metrics
from inductive.models.kgwn import KGWNSubgraphEncoder
from inductive.models.relation_scorer import InGramRelationScorer, RelationScorer
from inductive.relation_induction import RelationInductionModule, build_relation_graph_cached
from text_init import build_relation_texts, encode_texts_feature_hash, encode_texts_hf


def _device(s: str) -> str:
    if s == "auto":
        if torch.cuda.is_available():
            return "cuda"
        if torch.backends.mps.is_available():
            return "mps"
        return "cpu"
    return s


def _cpu_max_rss_bytes() -> int:
    rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    if sys.platform == "darwin":
        return int(rss)
    return int(rss) * 1024


def _reset_peak_memory(device: str) -> None:
    if device.startswith("cuda") and torch.cuda.is_available():
        torch.cuda.reset_peak_memory_stats()


def _update_peak_memory(stats: Dict[str, float], device: str, *, prefix: str) -> None:
    if device.startswith("cuda") and torch.cuda.is_available():
        val = float(torch.cuda.max_memory_allocated())
        key = f"{prefix}_peak_mem_bytes"
        stats[key] = max(stats.get(key, 0.0), val)
        return
    if device == "mps" and torch.backends.mps.is_available():
        if hasattr(torch.mps, "current_allocated_memory"):
            val = float(torch.mps.current_allocated_memory())
            key = f"{prefix}_peak_mem_bytes"
            stats[key] = max(stats.get(key, 0.0), val)
        if hasattr(torch.mps, "driver_allocated_memory"):
            val = float(torch.mps.driver_allocated_memory())
            key = f"{prefix}_peak_driver_mem_bytes"
            stats[key] = max(stats.get(key, 0.0), val)
        return
    val = float(_cpu_max_rss_bytes())
    key = f"{prefix}_peak_mem_bytes"
    stats[key] = max(stats.get(key, 0.0), val)


def _count_trainable_params(*modules: nn.Module | None) -> int:
    total = 0
    for mod in modules:
        if mod is None:
            continue
        for param in mod.parameters():
            if param.requires_grad:
                total += int(param.numel())
    return int(total)


def _count_trainable_params_by_module(mod: nn.Module | None) -> int:
    if mod is None:
        return 0
    return int(sum(int(p.numel()) for p in mod.parameters() if p.requires_grad))


def _default_split_dir(*, data_root: str, dataset: str, p_test: float, p_val: float, seed: int) -> Path:
    tag = f"pTest{p_test:.2f}_pVal{p_val:.2f}_seed{int(seed):02d}".replace(".", "")
    return Path(data_root) / dataset / "inductive" / tag


def _default_text_features_path(*, data_root: str, dataset: str) -> Path:
    return Path(data_root) / dataset / "text_features_entities_bert-base-uncased_cls_L64.pt"


def _list_relation_datasets(data_root: str) -> List[str]:
    root = Path(data_root)
    if not root.exists():
        return []
    return sorted([p.name for p in root.iterdir() if p.is_dir()])


def _expand_relation_datasets(dataset: str, *, data_root: str) -> List[str]:
    choices = _list_relation_datasets(data_root)
    for name in choices:
        if name.lower() == str(dataset).lower():
            return [name]
    prefix = f"{str(dataset).lower()}-"
    matches = [name for name in choices if name.lower().startswith(prefix)]
    if not matches:
        return []

    def sort_key(name: str) -> Tuple[int, object]:
        tail = name.split("-")[-1]
        try:
            return (0, int(tail))
        except ValueError:
            return (1, name.lower())

    return sorted(matches, key=sort_key)


def _run_for_datasets(datasets: List[str]) -> int:
    script = Path(__file__).resolve()
    base_args: List[str] = []
    skip = False
    for arg in sys.argv[1:]:
        if skip:
            skip = False
            continue
        if arg == "--dataset":
            skip = True
            continue
        if arg.startswith("--dataset="):
            continue
        base_args.append(arg)

    for ds in datasets:
        cmd = [sys.executable, str(script)] + base_args + ["--dataset", ds]
        print("Running:", " ".join(cmd))
        subprocess.run(cmd, check=True)
    return 0


def _default_relation_text_features_path(args: argparse.Namespace, *, data_root: str, dataset: str) -> Path:
    if bool(args.relation_text_use_hash):
        encoder_name = "hash"
    else:
        encoder_name = str(args.relation_text_model_name).replace("/", "_")
    return Path(data_root) / dataset / (
        f"text_features_relations_{encoder_name}_{args.relation_text_pooling}_L{int(args.relation_text_max_length)}.pt"
    )


def _run_relation_feature_generator(
    args: argparse.Namespace,
    *,
    dataset: str,
    data_root: str,
    out_path: Path,
) -> None:
    cmd = [
        sys.executable,
        "src/generate_inductive_relation_text_features.py",
        "--dataset",
        str(dataset),
        "--data_root",
        str(data_root),
        "--induction_kind",
        "relation",
        "--model_name",
        str(args.relation_text_model_name),
        "--pooling",
        str(args.relation_text_pooling),
        "--max_length",
        str(int(args.relation_text_max_length)),
        "--batch_size",
        str(int(args.relation_text_batch_size)),
        "--device",
        str(args.device),
        "--dim",
        str(int(args.relation_text_feature_dim)),
    ]
    if bool(args.relation_text_use_hash):
        cmd.append("--use_hash")
    print("Generating relation text features:")
    print("  " + " ".join(cmd))
    subprocess.run(cmd, check=True)
    if not out_path.exists():
        raise RuntimeError(f"Expected relation features at {out_path}, but file was not created.")


def _load_relation_text_features(args: argparse.Namespace, ds: KGDataset, *, device: str) -> torch.Tensor:
    if args.relation_text_features_path:
        return torch.load(Path(args.relation_text_features_path), map_location="cpu")

    default_path = _default_relation_text_features_path(args, data_root=str(args.data_root), dataset=str(ds.name))
    if default_path.exists():
        args.relation_text_features_path = str(default_path)
        return torch.load(default_path, map_location="cpu")

    if not bool(args.relation_text_use_hash):
        try:
            _run_relation_feature_generator(
                args,
                dataset=str(ds.name),
                data_root=str(args.data_root),
                out_path=default_path,
            )
            args.relation_text_features_path = str(default_path)
            return torch.load(default_path, map_location="cpu")
        except Exception as e:
            print(f"Automatic relation feature generation failed ({e}).")
            print("Falling back to in-process encoding.")

    rel_texts = build_relation_texts(ds, prefer="name_desc")
    if bool(args.relation_text_use_hash):
        feats = encode_texts_feature_hash(
            rel_texts,
            dim=int(args.relation_text_feature_dim),
            seed=0,
            normalize="l2",
            dtype=torch.float32,
        )
    else:
        feats = encode_texts_hf(
            rel_texts,
            model_name_or_path=str(args.relation_text_model_name),
            pooling=str(args.relation_text_pooling),
            max_length=int(args.relation_text_max_length),
            batch_size=int(args.relation_text_batch_size),
            device=str(device),
            local_files_only=True,
            dtype=None,
        )
    default_path.parent.mkdir(parents=True, exist_ok=True)
    torch.save(feats, default_path)
    args.relation_text_features_path = str(default_path)
    print(f"Saved relation text features to {default_path}")
    return feats


def _pair_true_relations(triples: torch.Tensor) -> Dict[Tuple[int, int], Set[int]]:
    out: Dict[Tuple[int, int], Set[int]] = {}
    for h, r, t in triples.to(dtype=torch.long, device="cpu").tolist():
        key = (int(h), int(t))
        s = out.get(key)
        if s is None:
            s = set()
            out[key] = s
        s.add(int(r))
    return out


@torch.no_grad()
def _eval_relation_prediction(
    triples: torch.Tensor,
    *,
    encoder: KGWNSubgraphEncoder,
    scorer: RelationScorer | InGramRelationScorer,
    extractor: EnclosingSubgraphExtractor,
    entity_text_features: torch.Tensor,
    k_hops: int,
    num_relations_pred: int,
    num_relations_original: int,
    drop_pair_edges: bool,
    use_augmented_graph: bool,
    tie_break: str,
    tie_seed: int,
    filter_dict: Optional[Dict[Tuple[int, int], Set[int]]] = None,
    relation_params: Optional[Dict[str, torch.Tensor]] = None,
    relation_embs: Optional[torch.Tensor] = None,
    stats: Optional[Dict[str, float]] = None,
) -> Dict[str, float]:
    encoder.eval()
    scorer.eval()
    all_scores: List[np.ndarray] = []
    y: List[int] = []
    filters: List[Set[int]] = []
    for h, r, t in triples.to(dtype=torch.long, device="cpu").tolist():
        t0 = time.perf_counter()
        sg = extractor.extract(int(h), int(t), k_hops=int(k_hops))
        t1 = time.perf_counter()
        inv_r = int(r) + int(num_relations_original) if use_augmented_graph else None
        t2 = time.perf_counter()
        xh, xt = encoder.encode(
            sg,
            entity_text_features=entity_text_features,
            rel_id=int(r),
            k_hops=int(k_hops),
            drop_target_edge=False,
            drop_pair_edges=bool(drop_pair_edges),
            drop_inverse_rel_id=inv_r,
            relation_params=relation_params,
        )
        t3 = time.perf_counter()
        if isinstance(scorer, InGramRelationScorer):
            logits = scorer.forward_all(xh, xt, relation_embs=relation_embs)  # [R_pred]
        else:
            logits = scorer.forward_all(xh, xt)  # [R_pred]
        t4 = time.perf_counter()
        if stats is not None:
            stats["extract_sec"] = float(stats.get("extract_sec", 0.0)) + (t1 - t0)
            stats["encode_sec"] = float(stats.get("encode_sec", 0.0)) + (t3 - t2)
            stats["score_sec"] = float(stats.get("score_sec", 0.0)) + (t4 - t3)
            stats["triples"] = int(stats.get("triples", 0)) + 1
        if int(num_relations_pred) != int(logits.numel()):
            logits = logits[:int(num_relations_pred)]
        all_scores.append(logits.detach().to("cpu").numpy())
        y.append(int(r))
        if filter_dict is None:
            filters.append(set())
        else:
            filters.append(set(filter_dict.get((int(h), int(t)), set())))

    return relation_ranking_metrics(
        all_scores,
        y,
        tie_break=str(tie_break),
        tie_seed=int(tie_seed),
        filter_other_true=filters if filter_dict is not None else None,
    )


def main() -> int:
    p = argparse.ArgumentParser(description="Inductive entity-disjoint relation prediction (GraIL-style) with KGWN.")
    p.add_argument("--dataset", type=str, default="FB-100")
    p.add_argument("--data_root", type=str, default="src/data/inductive/relations")
    p.add_argument("--device", type=str, default="auto")
    p.add_argument("--seed", type=int, default=0)

    # Official inductive benchmark (AdaProp/GraIL-style paired dirs: <base>, <base>_ind).
    p.add_argument(
        "--benchmark_dir",
        type=str,
        default=None,
        help="Use an official inductive benchmark directory (e.g., src/data/wn18rr/inductive/WN18RR_v1). "
             "Expects a sibling '<dir>_ind'. When set, ignores --p_test_entities split creation.",
    )

    # Split
    p.add_argument("--split_dir", type=str, default=None)
    p.add_argument("--p_test_entities", type=float, default=0.2)
    p.add_argument("--p_val_triples", type=float, default=0.05)
    p.add_argument("--min_rel_train", type=int, default=1)
    p.add_argument("--force_split", action="store_true")

    # Subgraphs / leakage prevention
    p.add_argument("--k_hops", type=int, default=2)
    p.add_argument("--use_augmented_graph", action="store_true", help="Add inverse edges to the background graph.")
    p.add_argument("--drop_pair_edges", action="store_true", help="Drop all edges between (h,t) (and (t,h)) before propagation.")
    p.add_argument("--filter_other_true_relations", action="store_true", help="Filter other true relations for the same (h,t) when ranking.")
    p.add_argument("--subgraph_cache_dir", type=str, default=None, help="Directory for on-disk subgraph cache (default: <split_dir>/subgraphs_k{K}).")
    p.add_argument("--no_subgraph_cache", action="store_true", help="Disable on-disk subgraph caching.")

    # Text
    p.add_argument("--text_features_path", type=str, default=None)
    p.add_argument("--text_feature_dim", type=int, default=768)

    # Relation induction (relation graph + text features)
    p.add_argument("--relation_text_features_path", type=str, default=None)
    p.add_argument("--relation_text_feature_dim", type=int, default=768)
    p.add_argument("--relation_text_use_hash", action="store_true")
    p.add_argument("--relation_text_model_name", type=str, default="bert-base-uncased")
    p.add_argument("--relation_text_pooling", type=str, default="cls", choices=["cls", "mean"])
    p.add_argument("--relation_text_max_length", type=int, default=32)
    p.add_argument("--relation_text_batch_size", type=int, default=64)
    p.add_argument("--relation_graph_topk", type=int, default=10)
    p.add_argument("--relation_graph_min_sim", type=float, default=0.0)
    p.add_argument("--relation_graph_cooc_weight", type=float, default=1.0)
    p.add_argument("--relation_graph_text_weight", type=float, default=1.0)
    p.add_argument("--relation_num_steps", type=int, default=1)
    p.add_argument("--relation_tau", type=float, default=0.005)
    p.add_argument("--relation_x1_mode", type=str, default="equal", choices=["equal", "taylor"])

    # Model (encoder)
    p.add_argument("--d_model", type=int, default=256)
    p.add_argument("--num_steps", type=int, default=1)
    p.add_argument("--tau", type=float, default=0.005)
    p.add_argument("--stability_margin", type=float, default=0.15)
    p.add_argument("--eps_anchor", type=float, default=0.0)
    p.add_argument("--use_two_stream", action="store_true")
    p.add_argument("--use_frequency_adaptation", action="store_true", default=True)
    p.add_argument("--no_frequency_adaptation", action="store_false", dest="use_frequency_adaptation")
    p.add_argument("--dropout", type=float, default=0.0)
    p.add_argument("--x1_mode", type=str, default="equal", choices=["equal", "taylor"])

    # Model (relation head)
    p.add_argument("--rel_hidden", type=int, default=512)
    p.add_argument("--rel_dropout", type=float, default=0.1)
    p.add_argument("--rel_scoring", type=str, default="ingram", choices=["ingram", "mlp"])
    p.add_argument("--rel_emb_dim", type=int, default=None)
    p.add_argument("--rel_loss", type=str, default="margin", choices=["margin", "ce"])
    p.add_argument("--rel_margin", type=float, default=1.0)
    p.add_argument("--rel_neg_per_pos", type=int, default=10, help="Negative triples per positive for margin loss")

    # Training
    p.add_argument("--save_dir", type=str, default="src/checkpoints/inductive_relation")
    p.add_argument("--num_epochs", type=int, default=10)
    p.add_argument("--batch_pos", type=int, default=32)
    p.add_argument("--learning_rate", type=float, default=5e-4)
    p.add_argument("--weight_decay", type=float, default=1e-6)
    p.add_argument("--grad_clip", type=float, default=1.0)
    p.add_argument("--patience", type=int, default=3)
    p.add_argument("--early_stop_metric", type=str, default="MRR", choices=["MRR", "Hits@1", "Hits@3", "Hits@10"])

    # Eval
    p.add_argument("--eval_fraction", type=float, default=1.0)
    p.add_argument("--eval_tie_break", type=str, default="random", choices=["top", "bottom", "random"])
    p.add_argument("--eval_tie_seed", type=int, default=None)

    args = p.parse_args()
    run_start = time.perf_counter()
    args.use_relation_induction = True
    device = _device(str(args.device))

    if args.benchmark_dir is None:
        datasets = _expand_relation_datasets(str(args.dataset), data_root=str(args.data_root))
        if not datasets:
            choices = _list_relation_datasets(str(args.data_root))
            print(f"Unknown relation dataset '{args.dataset}'. Available choices: {', '.join(choices)}")
            raise SystemExit(1)
        if len(datasets) > 1:
            print(f"Expanded dataset '{args.dataset}' to {len(datasets)} versions: {', '.join(datasets)}")
            raise SystemExit(_run_for_datasets(datasets))
        args.dataset = datasets[0]

    print("Hyperparameters:")
    for key in sorted(vars(args).keys()):
        print(f"  {key}: {getattr(args, key)}")

    torch.manual_seed(int(args.seed))
    np.random.seed(int(args.seed))

    benchmark = None
    if args.benchmark_dir:
        benchmark = load_adaprop_benchmark(Path(args.benchmark_dir))
        num_relations_original = int(benchmark.trans.num_relations)
        num_relations_total = 2 * num_relations_original
        num_relations_pred = num_relations_original
    else:
        ds = KGDataset(root=str(args.data_root), name=str(args.dataset), download=False, percentage=1.0)
        num_relations_total = int(ds.num_relations)
        num_relations_original = int(num_relations_total // 2)
        num_relations_pred = num_relations_original

        split_dir = Path(args.split_dir) if args.split_dir else _default_split_dir(
            data_root=str(args.data_root),
            dataset=str(args.dataset),
            p_test=float(args.p_test_entities),
            p_val=float(args.p_val_triples),
            seed=int(args.seed),
        )

        if args.force_split or not split_dir.exists():
            all_triples = torch.cat([ds.train_data, ds.valid_data, ds.test_data], dim=0)
            split = make_entity_disjoint_split(
                all_triples,
                dataset=str(args.dataset),
                num_entities=int(ds.num_entities),
                num_relations=num_relations_total,
                num_relations_original=num_relations_original,
                p_test_entities=float(args.p_test_entities),
                p_val_triples=float(args.p_val_triples),
                seed=int(args.seed),
                min_rel_train=int(args.min_rel_train),
            )
            save_split(split, split_dir)
        else:
            split = load_split(split_dir)
        assert_split_sane(split)

    if benchmark is not None:
        # Transductive side.
        trans_graph = benchmark.trans.train
        trans_val = benchmark.trans.valid
        # Inductive side (unseen entities).
        ind_graph = benchmark.ind.train
        ind_test = torch.cat([benchmark.ind.valid, benchmark.ind.test], dim=0)

        if bool(args.use_augmented_graph):
            trans_graph = augment_with_inverse(trans_graph, num_relations_original=num_relations_original)
            ind_graph = augment_with_inverse(ind_graph, num_relations_original=num_relations_original)

        train_edge_index, train_edge_type = edge_index_and_type_from_triples(trans_graph)
        test_edge_index, test_edge_type = edge_index_and_type_from_triples(ind_graph)

        cache_root = None
        if not bool(args.no_subgraph_cache):
            if args.subgraph_cache_dir:
                cache_root = Path(args.subgraph_cache_dir)
            else:
                cache_root = Path(str(benchmark.base_dir)) / "inductive_subgraphs" / f"k{int(args.k_hops)}"
        cache_train = cache_root / "train" if cache_root is not None else None
        cache_test = cache_root / "test" if cache_root is not None else None

        extractor_train = EnclosingSubgraphExtractor(
            num_nodes=int(benchmark.trans.num_entities),
            edge_index=train_edge_index,
            edge_type=train_edge_type,
            cache_dir=str(cache_train) if cache_train is not None else None,
        )
        extractor_test = EnclosingSubgraphExtractor(
            num_nodes=int(benchmark.ind.num_entities),
            edge_index=test_edge_index,
            edge_type=test_edge_type,
            cache_dir=str(cache_test) if cache_test is not None else None,
        )
    else:
        # Background graphs: allow using all observed edges among V_train (train+val positives).
        train_graph = split.train_pos
        if split.val_pos.numel() > 0:
            train_graph = torch.cat([train_graph, split.val_pos], dim=0)
        test_graph = split.test_pos
        if bool(args.use_augmented_graph):
            train_graph = augment_with_inverse(train_graph, num_relations_original=num_relations_original)
            test_graph = augment_with_inverse(test_graph, num_relations_original=num_relations_original)

        train_edge_index, train_edge_type = edge_index_and_type_from_triples(train_graph)
        test_edge_index, test_edge_type = edge_index_and_type_from_triples(test_graph)

        cache_root = None
        if not bool(args.no_subgraph_cache):
            if args.subgraph_cache_dir:
                cache_root = Path(args.subgraph_cache_dir)
            else:
                cache_root = Path(split_dir) / f"subgraphs_k{int(args.k_hops)}"
        cache_train = cache_root / "train" if cache_root is not None else None
        cache_test = cache_root / "test" if cache_root is not None else None

        extractor_train = EnclosingSubgraphExtractor(
            num_nodes=int(split.num_entities),
            edge_index=train_edge_index,
            edge_type=train_edge_type,
            cache_dir=str(cache_train) if cache_train is not None else None,
        )
        extractor_test = EnclosingSubgraphExtractor(
            num_nodes=int(split.num_entities),
            edge_index=test_edge_index,
            edge_type=test_edge_type,
            cache_dir=str(cache_test) if cache_test is not None else None,
        )

    # Text features.
    if benchmark is not None:
        # Expect per-benchmark cached features inside each directory by default.
        trans_feats_path = Path(args.text_features_path) if args.text_features_path else (
            Path(str(benchmark.base_dir)) / "text_features_entities_bert-base-uncased_cls_L64.pt"
        )
        ind_feats_path = Path(str(benchmark.ind_dir)) / "text_features_entities_bert-base-uncased_cls_L64.pt"
        feats_trans = torch.load(trans_feats_path, map_location="cpu").to(device=device)
        feats_ind = torch.load(ind_feats_path, map_location="cpu").to(device=device)
        if int(feats_trans.size(0)) != int(benchmark.trans.num_entities):
            raise RuntimeError(f"Trans text features size mismatch: {tuple(feats_trans.shape)} vs num_entities={benchmark.trans.num_entities}")
        if int(feats_ind.size(0)) != int(benchmark.ind.num_entities):
            raise RuntimeError(f"Ind text features size mismatch: {tuple(feats_ind.shape)} vs num_entities={benchmark.ind.num_entities}")
    else:
        text_features_path = Path(args.text_features_path) if args.text_features_path else _default_text_features_path(
            data_root=str(args.data_root), dataset=str(args.dataset)
        )
        feats = torch.load(text_features_path, map_location="cpu").to(device=device)

    relation_text_feats = None
    rel_graph_train = None
    rel_graph_test = None
    relation_module = None
    if benchmark is not None and bool(args.use_relation_induction):
        print("Warning: relation induction is not supported with --benchmark_dir yet; disabling.")
        args.use_relation_induction = False

    if bool(args.use_relation_induction):
        relation_text_feats = _load_relation_text_features(args, ds, device=device)
        if relation_text_feats.dim() != 2:
            raise RuntimeError(f"relation_text_features must be 2D, got {tuple(relation_text_feats.shape)}")
        if int(relation_text_feats.size(0)) < int(num_relations_pred):
            raise RuntimeError(
                f"relation_text_features must have at least {num_relations_pred} rows, got {tuple(relation_text_feats.shape)}"
            )
        if int(relation_text_feats.size(0)) > int(num_relations_pred):
            relation_text_feats = relation_text_feats[:int(num_relations_pred)]
        rel_cache_root = None
        if benchmark is None:
            rel_cache_root = Path(split_dir) / "relation_graphs"
        else:
            rel_cache_root = Path(str(benchmark.base_dir)) / "relation_graphs"
        rel_graph_train = build_relation_graph_cached(
            train_graph if benchmark is None else benchmark.trans.train,
            num_relations=num_relations_pred,
            rel_text_features=relation_text_feats,
            cooc_weight=float(args.relation_graph_cooc_weight),
            text_weight=float(args.relation_graph_text_weight),
            text_topk=int(args.relation_graph_topk),
            text_min_sim=float(args.relation_graph_min_sim),
            cache_dir=rel_cache_root,
            cache_tag="train",
        ).to(device=device)
        rel_graph_test = build_relation_graph_cached(
            test_graph if benchmark is None else benchmark.ind.train,
            num_relations=num_relations_pred,
            rel_text_features=relation_text_feats,
            cooc_weight=float(args.relation_graph_cooc_weight),
            text_weight=float(args.relation_graph_text_weight),
            text_topk=int(args.relation_graph_topk),
            text_min_sim=float(args.relation_graph_min_sim),
            cache_dir=rel_cache_root,
            cache_tag="test",
        ).to(device=device)
        relation_text_feats = relation_text_feats.to(device=device)
        relation_module = RelationInductionModule(
            num_relations=num_relations_pred,
            text_feature_dim=int(relation_text_feats.size(1)),
            d_model=int(args.d_model),
            num_steps=int(args.relation_num_steps),
            tau=float(args.relation_tau),
            x1_mode=str(args.relation_x1_mode),
        ).to(device)

    encoder = KGWNSubgraphEncoder(
        num_relations=num_relations_total if args.use_augmented_graph else num_relations_original,
        text_feature_dim=int(args.text_feature_dim),
        d_model=int(args.d_model),
        num_steps=int(args.num_steps),
        tau=float(args.tau),
        margin=float(args.stability_margin),
        eps_anchor=float(args.eps_anchor),
        use_two_stream=bool(args.use_two_stream),
        use_frequency_adaptation=bool(args.use_frequency_adaptation),
        dropout=float(args.dropout),
        x1_mode=str(args.x1_mode),
    ).to(device)
    if str(args.rel_scoring).lower() == "mlp":
        scorer = RelationScorer(
            num_relations=num_relations_pred,
            d_model=int(args.d_model),
            hidden=int(args.rel_hidden),
            dropout=float(args.rel_dropout),
        ).to(device)
    else:
        scorer = InGramRelationScorer(
            num_relations=num_relations_pred,
            d_model=int(args.d_model),
            rel_emb_dim=int(args.rel_emb_dim) if args.rel_emb_dim is not None else None,
        ).to(device)
    num_parameters = _count_trainable_params(encoder, scorer, relation_module)
    num_enc = _count_trainable_params_by_module(encoder)
    num_scorer = _count_trainable_params_by_module(scorer)
    num_relmod = _count_trainable_params_by_module(relation_module)
    print(f"Trainable parameters: total={num_parameters} encoder={num_enc} scorer={num_scorer} relation_module={num_relmod}")

    opt_params = list(encoder.parameters()) + list(scorer.parameters())
    if relation_module is not None:
        opt_params = opt_params + list(relation_module.parameters())
    opt = torch.optim.Adam(opt_params, lr=float(args.learning_rate), weight_decay=float(args.weight_decay))
    loss_fn = nn.CrossEntropyLoss()

    save_dir = Path(args.save_dir) / f"{args.dataset}_seed{int(args.seed):02d}"
    save_dir.mkdir(parents=True, exist_ok=True)
    with open(save_dir / "config.json", "w") as f:
        json.dump(vars(args), f, indent=2)
    with open(save_dir / "split_dir.txt", "w") as f:
        f.write(str(split_dir))

    # Optional "filtered" relation ranking.
    if benchmark is not None:
        # Filter within each side separately (entity IDs are disjoint).
        filter_dict = None
    else:
        filter_dict = _pair_true_relations(torch.cat([split.train_pos, split.val_pos, split.test_pos], dim=0)) if args.filter_other_true_relations else None

    tie_seed = int(args.eval_tie_seed) if args.eval_tie_seed is not None else int(args.seed)

    best = -1.0
    best_epoch = 0
    patience_left = int(args.patience)
    best_state: Dict[str, object] = {}

    train_pos = (benchmark.trans.train if benchmark is not None else split.train_pos).to(dtype=torch.long, device="cpu")
    if benchmark is not None:
        entity_pool_train = torch.arange(int(benchmark.trans.num_entities), dtype=torch.long)
    else:
        entity_pool_train = split.v_train.to(dtype=torch.long, device="cpu") if split.v_train.numel() > 0 else torch.unique(train_pos[:, [0, 2]].reshape(-1))
    known_train = build_known_true_set(train_pos)
    gen = torch.Generator(device="cpu")
    gen.manual_seed(int(args.seed))

    setup_end = time.perf_counter()
    timing_train = {
        "extract_sec": 0.0,
        "encode_sec": 0.0,
        "score_sec": 0.0,
        "backward_sec": 0.0,
        "neg_sample_sec": 0.0,
        "triples": 0,
    }
    timing_val = {"extract_sec": 0.0, "encode_sec": 0.0, "score_sec": 0.0, "triples": 0, "wall_sec": 0.0}
    timing_test = {"extract_sec": 0.0, "encode_sec": 0.0, "score_sec": 0.0, "triples": 0, "wall_sec": 0.0}
    epoch_stats: List[Dict[str, float]] = []

    def score_triple(
        x_h: torch.Tensor,
        x_t: torch.Tensor,
        rel_id: int,
        relation_embs: Optional[torch.Tensor],
    ) -> torch.Tensor:
        rel_tensor = torch.tensor(int(rel_id), device=device)
        if isinstance(scorer, InGramRelationScorer):
            return scorer.forward(x_h, x_t, rel_tensor, relation_embs=relation_embs)
        return scorer.forward(x_h, x_t, rel_tensor)

    def maybe_subsample(triples: torch.Tensor, *, seed_off: int) -> torch.Tensor:
        frac = float(args.eval_fraction)
        if frac >= 1.0 or triples.numel() == 0:
            return triples
        n = int(triples.size(0))
        k = max(1, int(n * frac))
        g = torch.Generator(device="cpu")
        g.manual_seed(int(args.seed) + int(seed_off))
        return triples[torch.randperm(n, generator=g)[:k]]

    def encode_pair(
        h: int,
        t: int,
        r: int,
        *,
        inv_r: Optional[int],
        relation_params: Optional[Dict[str, torch.Tensor]],
        stats: Dict[str, float],
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        t0 = time.perf_counter()
        sg = extractor_train.extract(int(h), int(t), k_hops=int(args.k_hops))
        t1 = time.perf_counter()
        xh, xt = encoder.encode(
            sg,
            entity_text_features=feats,
            rel_id=int(r),
            k_hops=int(args.k_hops),
            drop_target_edge=False,
            drop_pair_edges=bool(args.drop_pair_edges),
            drop_inverse_rel_id=inv_r,
            relation_params=relation_params,
        )
        t2 = time.perf_counter()
        stats["extract_sec"] += float(t1 - t0)
        stats["encode_sec"] += float(t2 - t1)
        stats["triples"] += 1
        return xh, xt

    train_start = time.perf_counter()
    for epoch in range(1, int(args.num_epochs) + 1):
        encoder.train()
        scorer.train()
        if relation_module is not None:
            relation_module.train()
        epoch_key = int(args.seed) + epoch
        epoch_train_start = time.perf_counter()
        epoch_mem: Dict[str, float] = {}
        _reset_peak_memory(device)

        perm = torch.randperm(int(train_pos.size(0)), generator=gen)
        total_loss = 0.0
        steps = 0

        for start in range(0, int(train_pos.size(0)), int(args.batch_pos)):
            batch = train_pos[perm[start:start + int(args.batch_pos)]]
            relation_params = None
            relation_embs = None
            if relation_module is not None:
                rel_out = relation_module(relation_text_feats, norm_adj=rel_graph_train)
                relation_params = {
                    "raw_velocities": rel_out["raw_velocities"],
                    "raw_alpha": rel_out["raw_alpha"],
                    "raw_beta": rel_out["raw_beta"],
                }
                relation_embs = rel_out["relation_embs"]
            if str(args.rel_loss).lower() == "ce":
                logits_list: List[torch.Tensor] = []
                labels: List[int] = []
                for h, r, t in batch.tolist():
                    inv_r = int(r) + int(num_relations_original) if bool(args.use_augmented_graph) else None
                    xh, xt = encode_pair(
                        int(h),
                        int(t),
                        int(r),
                        inv_r=inv_r,
                        relation_params=relation_params,
                        stats=timing_train,
                    )
                    t_score0 = time.perf_counter()
                    if isinstance(scorer, InGramRelationScorer):
                        logits = scorer.forward_all(xh, xt, relation_embs=relation_embs)  # [R]
                    else:
                        logits = scorer.forward_all(xh, xt)  # [R]
                    t_score1 = time.perf_counter()
                    timing_train["score_sec"] += float(t_score1 - t_score0)
                    logits_list.append(logits)
                    labels.append(int(r))

                logit_mat = torch.stack(logits_list, dim=0)  # [B, R]
                y = torch.tensor(labels, dtype=torch.long, device=device)
                loss = loss_fn(logit_mat, y)
            else:
                if int(args.rel_neg_per_pos) <= 0:
                    raise RuntimeError("rel_neg_per_pos must be > 0 for margin loss.")
                pos_scores: List[torch.Tensor] = []
                neg_scores: List[torch.Tensor] = []
                for h, r, t in batch.tolist():
                    inv_r = int(r) + int(num_relations_original) if bool(args.use_augmented_graph) else None
                    xh, xt = encode_pair(
                        int(h),
                        int(t),
                        int(r),
                        inv_r=inv_r,
                        relation_params=relation_params,
                        stats=timing_train,
                    )
                    t_score0 = time.perf_counter()
                    pos_score = score_triple(xh, xt, int(r), relation_embs)
                    t_score1 = time.perf_counter()
                    timing_train["score_sec"] += float(t_score1 - t_score0)
                    t_neg0 = time.perf_counter()
                    negs = sample_negatives_for_pos(
                        torch.tensor([int(h), int(r), int(t)], dtype=torch.long),
                        num_neg=int(args.rel_neg_per_pos),
                        entity_pool=entity_pool_train,
                        known_true=known_train,
                        epoch=epoch_key,
                    )
                    t_neg1 = time.perf_counter()
                    timing_train["neg_sample_sec"] += float(t_neg1 - t_neg0)
                    for nh, nr, nt in negs.tolist():
                        inv_nr = int(nr) + int(num_relations_original) if bool(args.use_augmented_graph) else None
                        xh_neg, xt_neg = encode_pair(
                            int(nh),
                            int(nt),
                            int(nr),
                            inv_r=inv_nr,
                            relation_params=relation_params,
                            stats=timing_train,
                        )
                        t_score2 = time.perf_counter()
                        neg_score = score_triple(xh_neg, xt_neg, int(nr), relation_embs)
                        t_score3 = time.perf_counter()
                        timing_train["score_sec"] += float(t_score3 - t_score2)
                        pos_scores.append(pos_score)
                        neg_scores.append(neg_score)

                pos_scores_t = torch.stack(pos_scores, dim=0)
                neg_scores_t = torch.stack(neg_scores, dim=0)
                margin = float(args.rel_margin)
                loss = torch.relu(margin - pos_scores_t + neg_scores_t).mean()

            t_back0 = time.perf_counter()
            opt.zero_grad(set_to_none=True)
            loss.backward()
            if float(args.grad_clip) > 0:
                torch.nn.utils.clip_grad_norm_(list(encoder.parameters()) + list(scorer.parameters()), float(args.grad_clip))
            opt.step()
            t_back1 = time.perf_counter()
            timing_train["backward_sec"] += float(t_back1 - t_back0)
            _update_peak_memory(epoch_mem, device, prefix="train")

            total_loss += float(loss.detach().cpu().item())
            steps += 1

        epoch_train_end = time.perf_counter()
        epoch_record = {
            "epoch": int(epoch),
            "train_sec": float(epoch_train_end - epoch_train_start),
        }
        epoch_record.update(epoch_mem)

        # Validate.
        encoder.eval()
        scorer.eval()
        if benchmark is None and split.val_pos.numel() == 0:
            print(f"Epoch {epoch}: train_loss={total_loss/max(1,steps):.4f} (no val)")
            epoch_stats.append(epoch_record)
            continue

        val_data = trans_val if benchmark is not None else split.val_pos
        val_subset = maybe_subsample(val_data, seed_off=10_000 + epoch)
        relation_params_eval = None
        relation_embs_eval = None
        if relation_module is not None:
            relation_module.eval()
            with torch.no_grad():
                rel_out = relation_module(relation_text_feats, norm_adj=rel_graph_train)
            relation_params_eval = {
                "raw_velocities": rel_out["raw_velocities"],
                "raw_alpha": rel_out["raw_alpha"],
                "raw_beta": rel_out["raw_beta"],
            }
            relation_embs_eval = rel_out["relation_embs"]

        val_mem: Dict[str, float] = {}
        _reset_peak_memory(device)
        val_start = time.perf_counter()
        val_metrics = _eval_relation_prediction(
            val_subset,
            encoder=encoder,
            scorer=scorer,
            extractor=extractor_train,
            entity_text_features=feats_trans if benchmark is not None else feats,
            k_hops=int(args.k_hops),
            num_relations_pred=num_relations_pred,
            num_relations_original=num_relations_original,
            drop_pair_edges=bool(args.drop_pair_edges),
            use_augmented_graph=bool(args.use_augmented_graph),
            tie_break=str(args.eval_tie_break),
            tie_seed=tie_seed,
            filter_dict=filter_dict,
            relation_params=relation_params_eval,
            relation_embs=relation_embs_eval,
            stats=timing_val,
        )
        val_end = time.perf_counter()
        timing_val["wall_sec"] += float(val_end - val_start)
        _update_peak_memory(val_mem, device, prefix="val")
        epoch_record["val_sec"] = float(val_end - val_start)
        epoch_record.update(val_mem)
        epoch_stats.append(epoch_record)

        key = str(args.early_stop_metric)
        cur = float(val_metrics.get(key, float("nan")))
        print(f"Epoch {epoch}: train_loss={total_loss/max(1,steps):.4f} val={val_metrics}")

        if cur > best:
            best = cur
            best_epoch = epoch
            patience_left = int(args.patience)
            best_state = {
                "epoch": int(epoch),
                "encoder_state_dict": encoder.state_dict(),
                "scorer_state_dict": scorer.state_dict(),
                "config": vars(args),
                "split_dir": str(split_dir),
                "val_metrics": val_metrics,
                "num_relations_original": int(num_relations_original),
                "num_relations_total": int(num_relations_total),
            }
            if relation_module is not None:
                best_state["relation_induction_state_dict"] = relation_module.state_dict()
            torch.save(best_state, save_dir / "best_model.pt")
        else:
            patience_left -= 1
            if patience_left <= 0:
                print(f"Early stopping at epoch {epoch} (best_epoch={best_epoch}, best_{key}={best:.4f})")
                break

    train_end = time.perf_counter()
    # Final test.
    ckpt = torch.load(save_dir / "best_model.pt", map_location="cpu")
    encoder.load_state_dict(ckpt["encoder_state_dict"])
    scorer.load_state_dict(ckpt["scorer_state_dict"])
    if relation_module is not None and "relation_induction_state_dict" in ckpt:
        relation_module.load_state_dict(ckpt["relation_induction_state_dict"])
    encoder.to(device)
    scorer.to(device)
    if relation_module is not None:
        relation_module.eval()

    test_data = ind_test if benchmark is not None else split.test_pos
    relation_params = None
    relation_embs = None
    if relation_module is not None:
        with torch.no_grad():
            rel_out = relation_module(relation_text_feats, norm_adj=rel_graph_test)
        relation_params = {
            "raw_velocities": rel_out["raw_velocities"],
            "raw_alpha": rel_out["raw_alpha"],
            "raw_beta": rel_out["raw_beta"],
        }
        relation_embs = rel_out["relation_embs"]

    test_mem: Dict[str, float] = {}
    _reset_peak_memory(device)
    test_start = time.perf_counter()
    test_metrics = _eval_relation_prediction(
        test_data,
        encoder=encoder,
        scorer=scorer,
        extractor=extractor_test,
        entity_text_features=feats_ind if benchmark is not None else feats,
        k_hops=int(args.k_hops),
        num_relations_pred=num_relations_pred,
        num_relations_original=num_relations_original,
        drop_pair_edges=bool(args.drop_pair_edges),
        use_augmented_graph=bool(args.use_augmented_graph),
        tie_break=str(args.eval_tie_break),
        tie_seed=tie_seed,
        filter_dict=filter_dict,
        relation_params=relation_params,
        relation_embs=relation_embs,
        stats=timing_test,
    )
    _update_peak_memory(test_mem, device, prefix="test")
    test_end = time.perf_counter()
    timing_test["wall_sec"] += float(test_end - test_start)

    epochs_run = int(epoch)
    train_peak_mem = max((float(e.get("train_peak_mem_bytes", 0.0)) for e in epoch_stats), default=0.0)
    val_peak_mem = max((float(e.get("val_peak_mem_bytes", 0.0)) for e in epoch_stats), default=0.0)
    train_peak_driver = max((float(e.get("train_peak_driver_mem_bytes", 0.0)) for e in epoch_stats), default=0.0)
    val_peak_driver = max((float(e.get("val_peak_driver_mem_bytes", 0.0)) for e in epoch_stats), default=0.0)

    timing = {
        "setup_time_sec": float(setup_end - run_start),
        "train_time_sec": float(train_end - train_start),
        "val_time_sec": float(timing_val.get("wall_sec", 0.0)),
        "test_time_sec": float(test_end - test_start),
        "total_time_sec": float(test_end - run_start),
        "train_core_time_sec": float(timing_train["encode_sec"] + timing_train["score_sec"] + timing_train["backward_sec"]),
        "train_data_time_sec": float(timing_train["extract_sec"] + timing_train["neg_sample_sec"]),
        "train_extract_sec": float(timing_train["extract_sec"]),
        "train_encode_sec": float(timing_train["encode_sec"]),
        "train_score_sec": float(timing_train["score_sec"]),
        "train_backward_sec": float(timing_train["backward_sec"]),
        "train_neg_sample_sec": float(timing_train["neg_sample_sec"]),
        "val_extract_sec": float(timing_val.get("extract_sec", 0.0)),
        "val_encode_sec": float(timing_val.get("encode_sec", 0.0)),
        "val_score_sec": float(timing_val.get("score_sec", 0.0)),
        "test_extract_sec": float(timing_test.get("extract_sec", 0.0)),
        "test_encode_sec": float(timing_test.get("encode_sec", 0.0)),
        "test_score_sec": float(timing_test.get("score_sec", 0.0)),
        "train_peak_mem_bytes": train_peak_mem,
        "val_peak_mem_bytes": val_peak_mem,
        "train_peak_driver_mem_bytes": train_peak_driver,
        "val_peak_driver_mem_bytes": val_peak_driver,
    }
    timing.update(test_mem)
    timing["avg_train_epoch_sec"] = float(timing["train_time_sec"] / max(1, epochs_run))
    timing["avg_train_core_epoch_sec"] = float(timing["train_core_time_sec"] / max(1, epochs_run))
    timing["avg_train_data_epoch_sec"] = float(timing["train_data_time_sec"] / max(1, epochs_run))

    results = {
        "best_epoch": int(best_epoch),
        "best_val": float(best),
        "num_parameters": int(num_parameters),
        "num_parameters_breakdown": {
            "encoder": int(num_enc),
            "scorer": int(num_scorer),
            "relation_module": int(num_relmod),
        },
        "test": test_metrics,
        "timing": timing,
        "epoch_stats": epoch_stats,
    }
    with open(save_dir / "results.json", "w") as f:
        json.dump(results, f, indent=2)
    print(f"Saved: {save_dir / 'best_model.pt'}")
    print(f"Test: {test_metrics}")
    print(
        f"Timing (sec): train={timing['train_time_sec']:.2f} "
        f"core={timing['train_core_time_sec']:.2f} "
        f"val={timing['val_time_sec']:.2f} "
        f"test={timing['test_time_sec']:.2f} "
        f"total={timing['total_time_sec']:.2f}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
