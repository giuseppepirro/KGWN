"""
Text-as-initial-condition utilities.

This module intentionally avoids heavy dependencies. It provides:
  - entity text loading (from `datasets/<name>/entities_data.txt` if present)
  - a lightweight frozen text encoder based on feature hashing
  - optional caching of computed text features

If you later install `transformers`, you can extend this module to add a real
LM encoder; the rest of KGWN can stay unchanged.
"""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import torch


_TOKEN_RE = re.compile(r"[A-Za-z0-9_]+")


def _repo_root() -> Path:
    # src/text_init.py -> repo_root/src/text_init.py
    return Path(__file__).resolve().parents[1]


def _stable_u64(s: str) -> int:
    # Stable across processes/Python versions (unlike built-in hash()).
    return int.from_bytes(hashlib.blake2b(s.encode("utf-8"), digest_size=8).digest(), "little")


def _tokenize(text: str) -> List[str]:
    return _TOKEN_RE.findall(text.lower())


def resolve_entities_data_path(dataset_name: str, data_root: Optional[str] = None) -> Optional[Path]:
    """
    Tries to find an `entities_data.txt` file that maps entity IDs to text.

    Expected format (tab-separated):
      <entity_id>  <name>  <description>
    """
    name = dataset_name.lower()
    root = _repo_root()
    candidates = []

    # Prefer explicit data_root if it contains metadata.
    if data_root:
        dr = Path(data_root)
        candidates.extend([
            dr / name / "entities_data.txt",
            dr / name / "entities_data.tsv",
        ])

    # Common location in this repo (copied from competitors).
    candidates.extend([
        root / "datasets" / name / "entities_data.txt",
        root / "datasets" / name / "entities_data.tsv",
    ])

    # Competitor folder (if user dropped datasets there).
    candidates.extend([
        root / "competitors" / "MoCoKGC" / "data" / name / "entities_data.txt",
        root / "competitors" / "MoCoKGC" / "data" / name / "entities_data.tsv",
        root / "competitors" / "MoCoKGC" / "data" / name.upper() / "entities_data.txt",
        root / "competitors" / "MoCoKGC" / "data" / name.upper() / "entities_data.tsv",
    ])

    for p in candidates:
        if p.exists():
            return p
    return None


def load_entities_data(path: Path) -> Dict[str, Tuple[str, str]]:
    """
    Returns mapping: entity_id_str -> (name, description).
    """
    out: Dict[str, Tuple[str, str]] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.rstrip("\n")
        if not line.strip():
            continue
        parts = line.split("\t")
        if len(parts) < 1:
            continue
        ent = parts[0]
        name = parts[1] if len(parts) > 1 else ""
        desc = parts[2] if len(parts) > 2 else ""
        out[ent] = (name, desc)
    return out


def resolve_relations_data_path(dataset_name: str, data_root: Optional[str] = None) -> Optional[Path]:
    """
    Tries to find a `relations_data.txt` file.

    Expected format (tab-separated):
      <relation_id>  <name>  [optional description...]
    """
    name = dataset_name.lower()
    root = _repo_root()
    candidates = []

    if data_root:
        dr = Path(data_root)
        candidates.extend([
            dr / name / "relations_data.txt",
            dr / name / "relations_data.tsv",
        ])

    candidates.extend([
        root / "datasets" / name / "relations_data.txt",
        root / "datasets" / name / "relations_data.tsv",
        root / "src" / "data" / name / "relations_data.txt",
        root / "src" / "data" / name / "relations_data.tsv",
    ])

    candidates.extend([
        root / "competitors" / "MoCoKGC" / "data" / name / "relations_data.txt",
        root / "competitors" / "MoCoKGC" / "data" / name / "relations_data.tsv",
        root / "competitors" / "MoCoKGC" / "data" / name.upper() / "relations_data.txt",
        root / "competitors" / "MoCoKGC" / "data" / name.upper() / "relations_data.tsv",
    ])

    for p in candidates:
        if p.exists():
            return p
    return None


def load_relations_data(path: Path) -> Dict[str, str]:
    """
    Returns mapping: relation_id_str -> readable name/description string.
    """
    out: Dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.rstrip("\n")
        if not line.strip():
            continue
        parts = line.split("\t")
        rid = parts[0]
        name = parts[1] if len(parts) > 1 else ""
        desc = parts[2] if len(parts) > 2 else ""
        txt = " ".join([x for x in [name, desc] if x]).strip() or rid
        out[rid] = txt
    return out


def build_entity_texts(dataset, *, prefer: str = "name_desc") -> List[str]:
    """
    Build a text string per entity aligned with `dataset.id2entity`.

    If `datasets/<name>/entities_data.txt` exists, use it. Otherwise fall back to
    the entity ID string itself.
    """
    entities_path = resolve_entities_data_path(dataset.name, data_root=getattr(dataset, "root", None))
    meta = load_entities_data(entities_path) if entities_path else {}

    texts: List[str] = []
    for i in range(dataset.num_entities):
        ent = dataset.id2entity[i]
        if ent in meta:
            name, desc = meta[ent]
            if prefer == "desc":
                txt = desc or name or ent
            elif prefer == "name":
                txt = name or ent
            else:
                combined = " ".join([x for x in [name, desc] if x])
                txt = combined or ent
        else:
            txt = ent
        texts.append(txt)
    return texts


def build_relation_texts(dataset, *, prefer: str = "name_desc") -> List[str]:
    """
    Build a text string per relation aligned with `dataset.id2relation`.

    Uses `relations_data.txt` if available. For inverse relations created by this repo
    (suffix `_inverse`), derives text as "inverse of <base>" when possible.
    """
    rels_path = resolve_relations_data_path(dataset.name, data_root=getattr(dataset, "root", None))
    meta = load_relations_data(rels_path) if rels_path else {}

    out: List[str] = []
    for i in range(dataset.num_relations):
        rid = dataset.id2relation[i]
        if rid in meta:
            out.append(meta[rid])
            continue

        if rid.endswith("_inverse"):
            base = rid[: -len("_inverse")]
            base_txt = meta.get(base) or base
            out.append(f"inverse of {base_txt}")
            continue

        out.append(rid)

    return out


def encode_texts_feature_hash(
    texts: List[str],
    *,
    dim: int,
    seed: int = 0,
    normalize: str = "l2",
    dtype: torch.dtype = torch.float16,
) -> torch.Tensor:
    """
    Lightweight frozen text encoder:
      - tokenizes on [A-Za-z0-9_]+
      - feature hashing into a dense vector of length `dim`
      - optional L2 normalization

    Returns:
      Tensor [N, dim] on CPU.
    """
    if dim <= 0:
        raise ValueError(f"dim must be > 0 (got {dim})")

    out = torch.zeros((len(texts), dim), dtype=torch.float32)

    # Mix in seed so different runs can choose different hash families, if desired.
    seed_u64 = _stable_u64(f"seed={seed}")

    for i, text in enumerate(texts):
        toks = _tokenize(text)
        if not toks:
            continue
        row = out[i]
        for tok in toks:
            h = _stable_u64(tok) ^ seed_u64
            idx = int(h % dim)
            # Deterministic sign bit.
            sign = 1.0 if ((h >> 1) & 1) == 0 else -1.0
            row[idx] += sign

    if normalize == "l2":
        out = torch.nn.functional.normalize(out, p=2, dim=1)
    elif normalize in {"none", None}:
        pass
    else:
        raise ValueError(f"Unsupported normalize={normalize}")

    return out.to(dtype=dtype)


@torch.no_grad()
def encode_texts_hf(
    texts: List[str],
    *,
    model_name_or_path: str,
    pooling: str = "cls",
    max_length: int = 64,
    batch_size: int = 64,
    device: str = "cpu",
    local_files_only: bool = True,
    dtype: Optional[torch.dtype] = None,
) -> torch.Tensor:
    """
    Frozen HuggingFace encoder for entity texts.

    This is optional: requires `transformers` installed and the model weights available
    (locally if `local_files_only=True`).
    """
    try:
        from transformers import AutoModel, AutoTokenizer  # type: ignore
    except Exception as e:
        raise RuntimeError(
            "HuggingFace text encoder requested but `transformers` is not installed. "
            "Install it (and model weights) or use encoder='hash'."
        ) from e

    if pooling not in {"cls", "mean"}:
        raise ValueError(f"Unsupported pooling={pooling} (expected 'cls' or 'mean')")

    tok = AutoTokenizer.from_pretrained(model_name_or_path, local_files_only=local_files_only)
    mdl = AutoModel.from_pretrained(model_name_or_path, local_files_only=local_files_only)
    mdl.eval()

    dev = torch.device(device)
    mdl.to(dev)

    if dtype is not None:
        # Keep LayerNorm stable: only cast parameters; inputs remain int.
        mdl.to(dtype=dtype)

    outs: List[torch.Tensor] = []
    for start in range(0, len(texts), batch_size):
        batch = texts[start:start + batch_size]
        enc = tok(
            batch,
            padding=True,
            truncation=True,
            max_length=max_length,
            return_tensors="pt",
        )
        enc = {k: v.to(dev) for k, v in enc.items()}
        out = mdl(**enc)
        last = out.last_hidden_state  # [B, L, H]
        if pooling == "cls":
            vec = last[:, 0, :]  # [B, H]
        else:
            mask = enc.get("attention_mask")
            if mask is None:
                vec = last.mean(dim=1)
            else:
                m = mask.unsqueeze(-1).to(last.dtype)
                vec = (last * m).sum(dim=1) / (m.sum(dim=1).clamp_min_(1.0))
        vec = torch.nn.functional.normalize(vec, p=2, dim=1)
        outs.append(vec.detach().to("cpu"))

    return torch.cat(outs, dim=0)


def _cache_key(*, dataset_name: str, num_entities: int, dim: int, seed: int, prefer: str, normalize: str) -> str:
    payload = f"{dataset_name}|n={num_entities}|dim={dim}|seed={seed}|prefer={prefer}|norm={normalize}"
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()[:16]


def get_or_build_text_features(
    dataset,
    *,
    encoder: str = "hash",
    dim: int,
    seed: int,
    prefer: str,
    normalize: str,
    cache_dir: Optional[str],
    dtype: torch.dtype,
    hf_model_name_or_path: Optional[str] = None,
    hf_pooling: str = "cls",
    hf_max_length: int = 64,
    hf_batch_size: int = 64,
    hf_device: str = "cpu",
    hf_local_files_only: bool = True,
) -> torch.Tensor:
    """
    Build (or load) text features aligned with dataset entity ordering.

    Cache format:
      <cache_dir>/text_features_<key>.pt
      <cache_dir>/text_features_<key>.json  (metadata)
    """
    cache_root = Path(cache_dir) if cache_dir else None
    encoder = str(encoder).lower()
    if encoder not in {"hash", "hf"}:
        raise ValueError(f"Unsupported encoder={encoder} (expected 'hash' or 'hf')")

    # Extend cache key with encoder-specific details while keeping hashing stable.
    base_key = _cache_key(
        dataset_name=dataset.name,
        num_entities=dataset.num_entities,
        dim=dim,
        seed=seed,
        prefer=prefer,
        normalize=normalize,
    )
    extra = ""
    if encoder == "hf":
        extra = f"|hf={hf_model_name_or_path}|pool={hf_pooling}|ml={hf_max_length}"
    key = hashlib.sha256((base_key + "|" + encoder + extra).encode("utf-8")).hexdigest()[:16]

    if cache_root:
        cache_root.mkdir(parents=True, exist_ok=True)
        pt_path = cache_root / f"text_features_{key}.pt"
        meta_path = cache_root / f"text_features_{key}.json"
        if pt_path.exists() and meta_path.exists():
            return torch.load(str(pt_path), map_location="cpu")

    texts = build_entity_texts(dataset, prefer=prefer)
    if encoder == "hash":
        feats = encode_texts_feature_hash(texts, dim=dim, seed=seed, normalize=normalize, dtype=dtype)
    else:
        if not hf_model_name_or_path:
            raise ValueError("encoder='hf' requires hf_model_name_or_path")
        # HF outputs float32 by default; keep features on CPU and cast to requested dtype.
        feats = encode_texts_hf(
            texts,
            model_name_or_path=hf_model_name_or_path,
            pooling=hf_pooling,
            max_length=hf_max_length,
            batch_size=hf_batch_size,
            device=hf_device,
            local_files_only=hf_local_files_only,
            dtype=None,
        ).to(dtype=dtype)

    if cache_root:
        pt_path = cache_root / f"text_features_{key}.pt"
        meta_path = cache_root / f"text_features_{key}.json"
        torch.save(feats, str(pt_path))
        meta_path.write_text(
            json.dumps(
                {
                    "dataset": dataset.name,
                    "num_entities": dataset.num_entities,
                    "encoder": encoder,
                    "dim": dim,
                    "seed": seed,
                    "prefer": prefer,
                    "normalize": normalize,
                    "dtype": str(dtype),
                    "hf_model_name_or_path": hf_model_name_or_path or "",
                    "hf_pooling": hf_pooling,
                    "hf_max_length": hf_max_length,
                    "hf_batch_size": hf_batch_size,
                    "hf_device": hf_device,
                    "hf_local_files_only": hf_local_files_only,
                    "entities_data_path": str(resolve_entities_data_path(dataset.name, data_root=getattr(dataset, "root", None)) or ""),
                },
                indent=2,
            )
            + "\n"
        )

    return feats


def get_or_build_relation_features(
    dataset,
    *,
    encoder: str = "hash",
    dim: int,
    seed: int,
    prefer: str,
    normalize: str,
    cache_dir: Optional[str],
    dtype: torch.dtype,
    hf_model_name_or_path: Optional[str] = None,
    hf_pooling: str = "cls",
    hf_max_length: int = 64,
    hf_batch_size: int = 64,
    hf_device: str = "cpu",
    hf_local_files_only: bool = True,
) -> torch.Tensor:
    """
    Same as `get_or_build_text_features`, but aligned to relations instead of entities.
    """
    cache_root = Path(cache_dir) if cache_dir else None
    encoder = str(encoder).lower()
    if encoder not in {"hash", "hf"}:
        raise ValueError(f"Unsupported encoder={encoder} (expected 'hash' or 'hf')")

    payload = f"{dataset.name}|R={dataset.num_relations}|dim={dim}|seed={seed}|prefer={prefer}|norm={normalize}"
    extra = ""
    if encoder == "hf":
        extra = f"|hf={hf_model_name_or_path}|pool={hf_pooling}|ml={hf_max_length}"
    key = hashlib.sha256((payload + "|" + encoder + extra).encode("utf-8")).hexdigest()[:16]

    if cache_root:
        cache_root.mkdir(parents=True, exist_ok=True)
        pt_path = cache_root / f"rel_text_features_{key}.pt"
        meta_path = cache_root / f"rel_text_features_{key}.json"
        if pt_path.exists() and meta_path.exists():
            return torch.load(str(pt_path), map_location="cpu")

    texts = build_relation_texts(dataset, prefer=prefer)
    if encoder == "hash":
        feats = encode_texts_feature_hash(texts, dim=dim, seed=seed, normalize=normalize, dtype=dtype)
    else:
        if not hf_model_name_or_path:
            raise ValueError("encoder='hf' requires hf_model_name_or_path")
        feats = encode_texts_hf(
            texts,
            model_name_or_path=hf_model_name_or_path,
            pooling=hf_pooling,
            max_length=hf_max_length,
            batch_size=hf_batch_size,
            device=hf_device,
            local_files_only=hf_local_files_only,
            dtype=None,
        ).to(dtype=dtype)

    if cache_root:
        pt_path = cache_root / f"rel_text_features_{key}.pt"
        meta_path = cache_root / f"rel_text_features_{key}.json"
        torch.save(feats, str(pt_path))
        meta_path.write_text(
            json.dumps(
                {
                    "dataset": dataset.name,
                    "num_relations": dataset.num_relations,
                    "encoder": encoder,
                    "dim": dim,
                    "seed": seed,
                    "prefer": prefer,
                    "normalize": normalize,
                    "dtype": str(dtype),
                    "hf_model_name_or_path": hf_model_name_or_path or "",
                    "hf_pooling": hf_pooling,
                    "hf_max_length": hf_max_length,
                    "hf_batch_size": hf_batch_size,
                    "hf_device": hf_device,
                    "hf_local_files_only": hf_local_files_only,
                    "relations_data_path": str(resolve_relations_data_path(dataset.name, data_root=getattr(dataset, "root", None)) or ""),
                },
                indent=2,
            )
            + "\n"
        )

    return feats
