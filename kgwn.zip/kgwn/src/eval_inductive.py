#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path
from typing import List

import numpy as np
import torch

from datasets import KGDataset
from inductive.data.split_inductive import assert_split_sane, load_split
from inductive.data.subgraph import EnclosingSubgraphExtractor
from inductive.metrics import all_metrics, best_f1_threshold
from inductive.models.kgwn import KGWNSubgraphEncoder
from inductive.models.scorer import TripleScorer
from inductive.pipeline import augment_with_inverse, build_known_true_set, edge_index_and_type_from_triples, sample_negatives_for_pos
from inductive.tasks import score_triples
from inductive.relation_induction import RelationInductionModule, build_relation_graph_cached
from text_init import build_relation_texts, encode_texts_feature_hash, encode_texts_hf
from text_init import build_entity_texts


def _device(s: str) -> str:
    if s == "auto":
        if torch.cuda.is_available():
            return "cuda"
        if torch.backends.mps.is_available():
            return "mps"
        return "cpu"
    return s


def _build_eval_dataset(
    pos: torch.Tensor,
    *,
    neg_per_pos: int,
    entity_pool: torch.Tensor,
    known_true: set[tuple[int, int, int]],
    epoch_key: int,
) -> tuple[torch.Tensor, torch.Tensor, list[int] | None]:
    triples: List[List[int]] = []
    labels: List[float] = []
    group_sizes: List[int] | None = None
    all_neg = int(neg_per_pos) < 0

    if all_neg:
        group_sizes = []
        pool = entity_pool.to(dtype=torch.long, device="cpu").tolist()
        for row in pos.to(dtype=torch.long, device="cpu"):
            h, r, t = (int(row[0]), int(row[1]), int(row[2]))
            triples.append([h, r, t])
            labels.append(1.0)
            group_count = 1
            for ent in pool:
                cand = (h, r, int(ent))
                if cand != (h, r, t) and cand not in known_true:
                    triples.append([cand[0], cand[1], cand[2]])
                    labels.append(0.0)
                    group_count += 1
            for ent in pool:
                cand = (int(ent), r, t)
                if cand != (h, r, t) and cand not in known_true:
                    triples.append([cand[0], cand[1], cand[2]])
                    labels.append(0.0)
                    group_count += 1
            group_sizes.append(group_count)
    else:
        for row in pos.to(dtype=torch.long, device="cpu"):
            triples.append([int(row[0]), int(row[1]), int(row[2])])
            labels.append(1.0)
            if int(neg_per_pos) > 0:
                negs = sample_negatives_for_pos(
                    row,
                    num_neg=int(neg_per_pos),
                    entity_pool=entity_pool,
                    known_true=known_true,
                    epoch=int(epoch_key),
                )
                for neg in negs:
                    triples.append([int(neg[0]), int(neg[1]), int(neg[2])])
                    labels.append(0.0)

    if not triples:
        return (
            torch.empty(0, 3, dtype=torch.long),
            torch.empty(0, dtype=torch.float32),
            group_sizes,
        )
    return (
        torch.tensor(triples, dtype=torch.long),
        torch.tensor(labels, dtype=torch.float32),
        group_sizes,
    )


def _load_relation_text_features(cfg: dict, ds: KGDataset, *, device: str, data_root: str) -> torch.Tensor:
    path = cfg.get("relation_text_features_path")
    if path:
        return torch.load(Path(str(path)), map_location="cpu")
    encoder_name = "hash" if bool(cfg.get("relation_text_use_hash", False)) else str(cfg.get("relation_text_model_name", "bert-base-uncased")).replace("/", "_")
    default_path = Path(str(data_root)) / str(ds.name) / f"text_features_relations_{encoder_name}_{cfg.get('relation_text_pooling', 'cls')}_L{int(cfg.get('relation_text_max_length', 32))}.pt"
    if default_path.exists():
        return torch.load(default_path, map_location="cpu")

    if not bool(cfg.get("relation_text_use_hash", False)):
        induction_kind = str(cfg.get("induction_kind", "entity"))
        cmd = [
            sys.executable,
            "src/generate_inductive_relation_text_features.py",
            "--dataset",
            str(ds.name),
            "--data_root",
            str(data_root),
            "--induction_kind",
            induction_kind,
            "--model_name",
            str(cfg.get("relation_text_model_name", "bert-base-uncased")),
            "--pooling",
            str(cfg.get("relation_text_pooling", "cls")),
            "--max_length",
            str(int(cfg.get("relation_text_max_length", 32))),
            "--batch_size",
            str(int(cfg.get("relation_text_batch_size", 64))),
            "--device",
            str(device),
            "--dim",
            str(int(cfg.get("relation_text_feature_dim", 768))),
        ]
        print("Generating relation text features:")
        print("  " + " ".join(cmd))
        subprocess.run(cmd, check=True)
        if default_path.exists():
            return torch.load(default_path, map_location="cpu")
        raise RuntimeError(f"Expected relation features at {default_path}, but file was not created.")

    rel_texts = build_relation_texts(ds, prefer="name_desc")
    if bool(cfg.get("relation_text_use_hash", False)):
        return encode_texts_feature_hash(
            rel_texts,
            dim=int(cfg.get("relation_text_feature_dim", 768)),
            seed=0,
            normalize="l2",
            dtype=torch.float32,
        )

    try:
        return encode_texts_hf(
            rel_texts,
            model_name_or_path=str(cfg.get("relation_text_model_name", "bert-base-uncased")),
            pooling=str(cfg.get("relation_text_pooling", "cls")),
            max_length=int(cfg.get("relation_text_max_length", 32)),
            batch_size=int(cfg.get("relation_text_batch_size", 64)),
            device=str(device),
            local_files_only=True,
            dtype=None,
        )
    except Exception as e:
        print(f"Relation HF encoder failed ({e}); falling back to feature hashing.")
        return encode_texts_feature_hash(
            rel_texts,
            dim=int(cfg.get("relation_text_feature_dim", 768)),
            seed=0,
            normalize="l2",
            dtype=torch.float32,
        )


def _load_entity_text_features(
    cfg: dict,
    ds: KGDataset,
    *,
    device: str,
    data_root: str,
    explicit_path: str | None,
) -> torch.Tensor:
    if explicit_path:
        return torch.load(Path(str(explicit_path)), map_location="cpu")
    default_path = Path(data_root) / str(ds.name) / "text_features_entities_bert-base-uncased_cls_L64.pt"
    if default_path.exists():
        return torch.load(default_path, map_location="cpu")

    if not bool(cfg.get("entity_text_use_hash", False)):
        induction_kind = str(cfg.get("induction_kind", "entity"))
        cmd = [
            sys.executable,
            "src/generate_inductive_text_features.py",
            "--dataset",
            str(ds.name),
            "--data_root",
            str(data_root),
            "--induction_kind",
            induction_kind,
            "--model_name",
            str(cfg.get("entity_text_model_name", "bert-base-uncased")),
            "--pooling",
            str(cfg.get("entity_text_pooling", "cls")),
            "--max_length",
            str(int(cfg.get("entity_text_max_length", 64))),
            "--batch_size",
            str(int(cfg.get("entity_text_batch_size", 64))),
            "--device",
            str(device),
            "--dim",
            str(int(cfg.get("text_feature_dim", 768))),
        ]
        print("Generating entity text features:")
        print("  " + " ".join(cmd))
        subprocess.run(cmd, check=True)
        if default_path.exists():
            return torch.load(default_path, map_location="cpu")
        raise RuntimeError(f"Expected entity features at {default_path}, but file was not created.")

    entity_texts = build_entity_texts(ds, prefer="name_desc")
    return encode_texts_feature_hash(
        entity_texts,
        dim=int(cfg.get("text_feature_dim", 768)),
        seed=0,
        normalize="l2",
        dtype=torch.float16,
    )


def main() -> int:
    p = argparse.ArgumentParser(description="Evaluate an inductive KGWN triple validation checkpoint.")
    p.add_argument("--checkpoint", type=str, required=True)
    p.add_argument("--device", type=str, default="auto")
    p.add_argument("--data_root", type=str, default="src/data")
    p.add_argument("--text_features_path", type=str, default=None)
    p.add_argument("--eval_neg_per_pos", type=int, default=-1)
    p.add_argument("--k_hops", type=int, default=None, help="Override k_hops from checkpoint config")
    p.add_argument("--drop_target_edge", action="store_true")
    p.add_argument("--relation_text_features_path", type=str, default=None)
    args = p.parse_args()

    device = _device(str(args.device))
    ckpt = torch.load(args.checkpoint, map_location="cpu")
    cfg = ckpt.get("config", {})
    if args.relation_text_features_path:
        cfg["relation_text_features_path"] = args.relation_text_features_path

    split_dir = Path(str(ckpt.get("split_dir")))
    split = load_split(split_dir)
    assert_split_sane(split)

    data_root = str(cfg.get("data_root", args.data_root))

    # Load dataset just for num_relations.
    ds = KGDataset(root=data_root, name=str(split.dataset), download=False, percentage=1.0)
    num_relations = int(ds.num_relations)

    feats = _load_entity_text_features(
        cfg,
        ds,
        device=device,
        data_root=data_root,
        explicit_path=args.text_features_path,
    ).to(device=device)
    k_hops = int(args.k_hops) if args.k_hops is not None else int(cfg.get("k_hops", 2))

    # Graphs for subgraph extraction.
    train_graph_triples = split.train_pos
    test_graph_triples = split.test_pos
    use_aug = bool(cfg.get("use_augmented_graph", False))
    if use_aug:
        train_graph_triples = augment_with_inverse(train_graph_triples, num_relations_original=int(split.num_relations_original))
        test_graph_triples = augment_with_inverse(test_graph_triples, num_relations_original=int(split.num_relations_original))
    train_edge_index, train_edge_type = edge_index_and_type_from_triples(train_graph_triples)
    test_edge_index, test_edge_type = edge_index_and_type_from_triples(test_graph_triples)
    cache_root = Path(split_dir) / f"subgraphs_k{int(k_hops)}"
    cache_train = cache_root / "train"
    cache_test = cache_root / "test"
    extractor_train = EnclosingSubgraphExtractor(
        num_nodes=int(split.num_entities),
        edge_index=train_edge_index,
        edge_type=train_edge_type,
        cache_dir=str(cache_train),
    )
    extractor_test = EnclosingSubgraphExtractor(
        num_nodes=int(split.num_entities),
        edge_index=test_edge_index,
        edge_type=test_edge_type,
        cache_dir=str(cache_test),
    )

    entity_pool_train = split.v_train.to(dtype=torch.long, device="cpu")
    if test_graph_triples.numel() > 0:
        entity_pool_test = torch.unique(test_graph_triples[:, [0, 2]].reshape(-1))
    else:
        entity_pool_test = split.v_test.to(dtype=torch.long, device="cpu")

    known_val = build_known_true_set(torch.cat([split.train_pos, split.val_pos], dim=0)) if split.val_pos.numel() > 0 else build_known_true_set(split.train_pos)
    known_test = build_known_true_set(split.test_pos)

    encoder = KGWNSubgraphEncoder(
        num_relations=num_relations,
        text_feature_dim=int(cfg.get("text_feature_dim", 768)),
        d_model=int(cfg.get("d_model", 256)),
        num_steps=int(cfg.get("num_steps", 1)),
        tau=float(cfg.get("tau", 0.005)),
        margin=float(cfg.get("stability_margin", 0.15)),
        eps_anchor=float(cfg.get("eps_anchor", 0.0)),
        use_two_stream=bool(cfg.get("use_two_stream", False)),
        dropout=float(cfg.get("dropout", 0.0)),
        x1_mode=str(cfg.get("x1_mode", "equal")),
    ).to(device)
    scorer = TripleScorer(num_relations=num_relations, d_model=int(cfg.get("d_model", 256))).to(device)
    encoder.load_state_dict(ckpt["encoder_state_dict"])
    scorer.load_state_dict(ckpt["scorer_state_dict"])

    relation_module = None
    rel_text_feats = None
    rel_graph_train = None
    rel_graph_test = None
    use_relation_induction = bool(cfg.get("use_relation_induction", False)) or ("relation_induction_state_dict" in ckpt)
    if use_relation_induction:
        rel_text_feats = _load_relation_text_features(cfg, ds, device=device, data_root=data_root)
        if rel_text_feats.dim() != 2 or int(rel_text_feats.size(0)) != int(num_relations):
            raise RuntimeError(
                f"relation_text_features must be [num_relations, d] with num_relations={num_relations}, got {tuple(rel_text_feats.shape)}"
            )
        rel_cache_root = Path(split_dir) / "relation_graphs"
        rel_graph_train = build_relation_graph_cached(
            train_graph_triples,
            num_relations=num_relations,
            rel_text_features=rel_text_feats,
            cooc_weight=float(cfg.get("relation_graph_cooc_weight", 1.0)),
            text_weight=float(cfg.get("relation_graph_text_weight", 1.0)),
            text_topk=int(cfg.get("relation_graph_topk", 10)),
            text_min_sim=float(cfg.get("relation_graph_min_sim", 0.0)),
            cache_dir=rel_cache_root,
            cache_tag="train",
        ).to(device=device)
        rel_graph_test = build_relation_graph_cached(
            test_graph_triples,
            num_relations=num_relations,
            rel_text_features=rel_text_feats,
            cooc_weight=float(cfg.get("relation_graph_cooc_weight", 1.0)),
            text_weight=float(cfg.get("relation_graph_text_weight", 1.0)),
            text_topk=int(cfg.get("relation_graph_topk", 10)),
            text_min_sim=float(cfg.get("relation_graph_min_sim", 0.0)),
            cache_dir=rel_cache_root,
            cache_tag="test",
        ).to(device=device)
        rel_text_feats = rel_text_feats.to(device=device)
        relation_module = RelationInductionModule(
            num_relations=num_relations,
            text_feature_dim=int(rel_text_feats.size(1)),
            d_model=int(cfg.get("d_model", 256)),
            num_steps=int(cfg.get("relation_num_steps", 1)),
            tau=float(cfg.get("relation_tau", 0.005)),
            x1_mode=str(cfg.get("relation_x1_mode", "equal")),
        ).to(device)
        if "relation_induction_state_dict" in ckpt:
            relation_module.load_state_dict(ckpt["relation_induction_state_dict"])
        relation_module.eval()

    drop_target_edge = bool(args.drop_target_edge) or bool(cfg.get("drop_target_edge", False))

    # Val threshold selection.
    if split.val_pos.numel() > 0:
        val_triples, val_labels, val_group_sizes = _build_eval_dataset(
            split.val_pos,
            neg_per_pos=int(args.eval_neg_per_pos),
            entity_pool=entity_pool_train,
            known_true=known_val,
            epoch_key=int(cfg.get("seed", 0)) + 10_000,
        )
        relation_params = None
        relation_embs = None
        if relation_module is not None:
            with torch.no_grad():
                rel_out = relation_module(rel_text_feats, norm_adj=rel_graph_train)
            relation_params = {
                "raw_velocities": rel_out["raw_velocities"],
                "raw_alpha": rel_out["raw_alpha"],
                "raw_beta": rel_out["raw_beta"],
            }
            relation_embs = rel_out["relation_embs"]
        val_logits = score_triples(
            val_triples,
            encoder=encoder,
            scorer=scorer,
            extractor=extractor_train,
            entity_text_features=feats,
            k_hops=k_hops,
            drop_target_edge=drop_target_edge,
            relation_params=relation_params,
            relation_embs=relation_embs,
        ).numpy()
        val_probs = 1.0 / (1.0 + np.exp(-val_logits))
        thr = best_f1_threshold(val_labels.numpy(), val_probs)
    else:
        thr = 0.5

    test_triples, test_labels, test_group_sizes = _build_eval_dataset(
        split.test_pos,
        neg_per_pos=int(args.eval_neg_per_pos),
        entity_pool=entity_pool_test,
        known_true=known_test,
        epoch_key=int(cfg.get("seed", 0)) + 20_000,
    )
    relation_params = None
    relation_embs = None
    if relation_module is not None:
        with torch.no_grad():
            rel_out = relation_module(rel_text_feats, norm_adj=rel_graph_test)
        relation_params = {
            "raw_velocities": rel_out["raw_velocities"],
            "raw_alpha": rel_out["raw_alpha"],
            "raw_beta": rel_out["raw_beta"],
        }
        relation_embs = rel_out["relation_embs"]
    test_logits = score_triples(
        test_triples,
        encoder=encoder,
        scorer=scorer,
        extractor=extractor_test,
        entity_text_features=feats,
        k_hops=k_hops,
        drop_target_edge=drop_target_edge,
        relation_params=relation_params,
        relation_embs=relation_embs,
    ).numpy()
    test_probs = 1.0 / (1.0 + np.exp(-test_logits))
    test_m = all_metrics(test_labels.numpy(), test_probs, threshold=float(thr), include_ranking=True, group_sizes=test_group_sizes)
    print(json.dumps({"threshold": float(thr), "test": test_m}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
