#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Dict, Set, Tuple

import numpy as np
import torch

from datasets import KGDataset
from inductive.data.adaprop_benchmark import load_adaprop_benchmark
from inductive.data.split_inductive import assert_split_sane, load_split
from inductive.data.subgraph import EnclosingSubgraphExtractor
from inductive.pipeline import augment_with_inverse, edge_index_and_type_from_triples
from inductive.relation_metrics import relation_ranking_metrics
from inductive.models.kgwn import KGWNSubgraphEncoder
from inductive.models.relation_scorer import InGramRelationScorer, RelationScorer
from inductive.relation_induction import RelationInductionModule, build_relation_graph_cached
from text_init import build_relation_texts, encode_texts_feature_hash, encode_texts_hf


def _device(s: str) -> str:
    if s == "auto":
        if torch.cuda.is_available():
            return "cuda"
        if torch.backends.mps.is_available():
            return "mps"
        return "cpu"
    return s


def _pair_true_relations(triples: torch.Tensor) -> Dict[Tuple[int, int], Set[int]]:
    out: Dict[Tuple[int, int], Set[int]] = {}
    for h, r, t in triples.to(dtype=torch.long, device="cpu").tolist():
        key = (int(h), int(t))
        s = out.get(key)
        if s is None:
            s = set()
            out[key] = s
        s.add(int(r))
    return out


def _default_relation_text_features_path(cfg: dict, *, data_root: str, dataset: str) -> Path:
    encoder_name = "hash" if bool(cfg.get("relation_text_use_hash", False)) else str(cfg.get("relation_text_model_name", "bert-base-uncased")).replace("/", "_")
    return Path(str(data_root)) / str(dataset) / f"text_features_relations_{encoder_name}_{cfg.get('relation_text_pooling', 'cls')}_L{int(cfg.get('relation_text_max_length', 32))}.pt"


def _load_relation_text_features(cfg: dict, *, data_root: str, dataset: str, device: str) -> torch.Tensor:
    path = cfg.get("relation_text_features_path")
    if path:
        return torch.load(Path(str(path)), map_location="cpu")

    default_path = _default_relation_text_features_path(cfg, data_root=data_root, dataset=dataset)
    if default_path.exists():
        return torch.load(default_path, map_location="cpu")

    rel_texts = build_relation_texts(KGDataset(root=str(data_root), name=str(dataset), download=False, percentage=1.0), prefer="name_desc")
    if bool(cfg.get("relation_text_use_hash", False)):
        feats = encode_texts_feature_hash(
            rel_texts,
            dim=int(cfg.get("relation_text_feature_dim", 768)),
            seed=0,
            normalize="l2",
            dtype=torch.float32,
        )
    else:
        feats = encode_texts_hf(
            rel_texts,
            model_name_or_path=str(cfg.get("relation_text_model_name", "bert-base-uncased")),
            pooling=str(cfg.get("relation_text_pooling", "cls")),
            max_length=int(cfg.get("relation_text_max_length", 32)),
            batch_size=int(cfg.get("relation_text_batch_size", 64)),
            device=str(device),
            local_files_only=True,
            dtype=None,
        )
    default_path.parent.mkdir(parents=True, exist_ok=True)
    torch.save(feats, default_path)
    return feats


@torch.no_grad()
def _scores_for_triples(
    triples: torch.Tensor,
    *,
    encoder: KGWNSubgraphEncoder,
    scorer: RelationScorer | InGramRelationScorer,
    extractor: EnclosingSubgraphExtractor,
    entity_text_features: torch.Tensor,
    k_hops: int,
    num_relations_pred: int,
    num_relations_original: int,
    drop_pair_edges: bool,
    use_augmented_graph: bool,
    relation_params: Dict[str, torch.Tensor] | None = None,
    relation_embs: torch.Tensor | None = None,
) -> tuple[list[np.ndarray], list[int], list[set[int]]]:
    encoder.eval()
    scorer.eval()
    all_scores: list[np.ndarray] = []
    y: list[int] = []
    filters: list[set[int]] = []
    for h, r, t in triples.to(dtype=torch.long, device="cpu").tolist():
        sg = extractor.extract(int(h), int(t), k_hops=int(k_hops))
        inv_r = int(r) + int(num_relations_original) if use_augmented_graph else None
        xh, xt = encoder.encode(
            sg,
            entity_text_features=entity_text_features,
            rel_id=int(r),
            k_hops=int(k_hops),
            drop_target_edge=False,
            drop_pair_edges=bool(drop_pair_edges),
            drop_inverse_rel_id=inv_r,
            relation_params=relation_params,
        )
        if isinstance(scorer, InGramRelationScorer):
            logits = scorer.forward_all(xh, xt, relation_embs=relation_embs)
        else:
            logits = scorer.forward_all(xh, xt)
        if int(num_relations_pred) != int(logits.numel()):
            logits = logits[:int(num_relations_pred)]
        all_scores.append(logits.detach().to("cpu").numpy())
        y.append(int(r))
        filters.append(set())
    return all_scores, y, filters


def main() -> int:
    p = argparse.ArgumentParser(description="Evaluate an inductive KGWN relation prediction checkpoint.")
    p.add_argument("--checkpoint", type=str, required=True)
    p.add_argument("--device", type=str, default="auto")
    p.add_argument("--data_root", type=str, default="src/data")
    p.add_argument(
        "--benchmark_dir",
        type=str,
        default=None,
        help="Evaluate on an AdaProp-style benchmark dir (e.g., src/data/wn18rr/inductive/WN18RR_v1) with sibling '<dir>_ind'.",
    )
    p.add_argument("--text_features_path", type=str, default=None)
    p.add_argument("--k_hops", type=int, default=None)
    p.add_argument("--use_augmented_graph", action="store_true")
    p.add_argument("--drop_pair_edges", action="store_true")
    p.add_argument("--filter_other_true_relations", action="store_true")
    p.add_argument("--eval_tie_break", type=str, default="random", choices=["top", "bottom", "random"])
    p.add_argument("--eval_tie_seed", type=int, default=0)
    args = p.parse_args()

    device = _device(str(args.device))
    ckpt = torch.load(args.checkpoint, map_location="cpu")
    cfg = ckpt.get("config", {})

    benchmark = load_adaprop_benchmark(Path(args.benchmark_dir)) if args.benchmark_dir else None
    if benchmark is None:
        split_dir = Path(str(ckpt.get("split_dir")))
        split = load_split(split_dir)
        assert_split_sane(split)

        ds = KGDataset(root=str(args.data_root), name=str(split.dataset), download=False, percentage=1.0)
        num_relations_total = int(ds.num_relations)
        num_relations_original = int(num_relations_total // 2)
        num_relations_pred = num_relations_original
    else:
        num_relations_original = int(benchmark.trans.num_relations)
        num_relations_total = 2 * num_relations_original
        num_relations_pred = num_relations_original

    use_aug = bool(args.use_augmented_graph) or bool(cfg.get("use_augmented_graph", False))
    if benchmark is None:
        text_features_path = Path(args.text_features_path) if args.text_features_path else (
            Path(args.data_root) / str(split.dataset) / "text_features_entities_bert-base-uncased_cls_L64.pt"
        )
        feats = torch.load(text_features_path, map_location="cpu").to(device=device)
    else:
        trans_feats_path = Path(args.text_features_path) if args.text_features_path else (
            Path(str(benchmark.base_dir)) / "text_features_entities_bert-base-uncased_cls_L64.pt"
        )
        ind_feats_path = Path(str(benchmark.ind_dir)) / "text_features_entities_bert-base-uncased_cls_L64.pt"
        feats_trans = torch.load(trans_feats_path, map_location="cpu").to(device=device)
        feats_ind = torch.load(ind_feats_path, map_location="cpu").to(device=device)

    # Background graphs
    if benchmark is None:
        train_graph = split.train_pos
        if split.val_pos.numel() > 0:
            train_graph = torch.cat([train_graph, split.val_pos], dim=0)
        test_graph = split.test_pos
        if use_aug:
            train_graph = augment_with_inverse(train_graph, num_relations_original=num_relations_original)
            test_graph = augment_with_inverse(test_graph, num_relations_original=num_relations_original)

        train_edge_index, train_edge_type = edge_index_and_type_from_triples(train_graph)
        test_edge_index, test_edge_type = edge_index_and_type_from_triples(test_graph)
        cache_root = Path(split_dir) / f"subgraphs_k{int(k_hops)}"
        cache_train = cache_root / "train"
        cache_test = cache_root / "test"
        extractor_train = EnclosingSubgraphExtractor(
            num_nodes=int(split.num_entities),
            edge_index=train_edge_index,
            edge_type=train_edge_type,
            cache_dir=str(cache_train),
        )
        extractor_test = EnclosingSubgraphExtractor(
            num_nodes=int(split.num_entities),
            edge_index=test_edge_index,
            edge_type=test_edge_type,
            cache_dir=str(cache_test),
        )
    else:
        trans_graph = benchmark.trans.train
        ind_graph = benchmark.ind.train
        if use_aug:
            trans_graph = augment_with_inverse(trans_graph, num_relations_original=num_relations_original)
            ind_graph = augment_with_inverse(ind_graph, num_relations_original=num_relations_original)
        train_edge_index, train_edge_type = edge_index_and_type_from_triples(trans_graph)
        test_edge_index, test_edge_type = edge_index_and_type_from_triples(ind_graph)
        cache_root = Path(str(benchmark.base_dir)) / "inductive_subgraphs" / f"k{int(k_hops)}"
        cache_train = cache_root / "train"
        cache_test = cache_root / "test"
        extractor_train = EnclosingSubgraphExtractor(
            num_nodes=int(benchmark.trans.num_entities),
            edge_index=train_edge_index,
            edge_type=train_edge_type,
            cache_dir=str(cache_train),
        )
        extractor_test = EnclosingSubgraphExtractor(
            num_nodes=int(benchmark.ind.num_entities),
            edge_index=test_edge_index,
            edge_type=test_edge_type,
            cache_dir=str(cache_test),
        )

    encoder = KGWNSubgraphEncoder(
        num_relations=num_relations_total if use_aug else num_relations_original,
        text_feature_dim=int(cfg.get("text_feature_dim", 768)),
        d_model=int(cfg.get("d_model", 256)),
        num_steps=int(cfg.get("num_steps", 1)),
        tau=float(cfg.get("tau", 0.005)),
        margin=float(cfg.get("stability_margin", 0.15)),
        eps_anchor=float(cfg.get("eps_anchor", 0.0)),
        use_two_stream=bool(cfg.get("use_two_stream", False)),
        use_frequency_adaptation=bool(cfg.get("use_frequency_adaptation", False)),
        dropout=float(cfg.get("dropout", 0.0)),
        x1_mode=str(cfg.get("x1_mode", "equal")),
    ).to(device)
    rel_scoring = str(cfg.get("rel_scoring", "mlp")).lower()
    if rel_scoring == "ingram":
        scorer = InGramRelationScorer(
            num_relations=num_relations_pred,
            d_model=int(cfg.get("d_model", 256)),
            rel_emb_dim=cfg.get("rel_emb_dim"),
        ).to(device)
    else:
        scorer = RelationScorer(
            num_relations=num_relations_pred,
            d_model=int(cfg.get("d_model", 256)),
            hidden=int(cfg.get("rel_hidden", 512)),
            dropout=float(cfg.get("rel_dropout", 0.1)),
        ).to(device)
    encoder.load_state_dict(ckpt["encoder_state_dict"])
    scorer.load_state_dict(ckpt["scorer_state_dict"])

    relation_module = None
    rel_text_feats = None
    rel_graph_train = None
    rel_graph_test = None
    use_relation_induction = bool(cfg.get("use_relation_induction", False)) or ("relation_induction_state_dict" in ckpt)
    if use_relation_induction and benchmark is not None:
        print("Warning: relation induction evaluation with --benchmark_dir is not supported yet; disabling.")
        use_relation_induction = False

    if use_relation_induction:
        rel_text_feats = _load_relation_text_features(
            cfg,
            data_root=str(args.data_root),
            dataset=str(split.dataset),
            device=str(device),
        )
        if rel_text_feats.dim() != 2:
            raise RuntimeError(f"relation_text_features must be 2D, got {tuple(rel_text_feats.shape)}")
        if int(rel_text_feats.size(0)) < int(num_relations_pred):
            raise RuntimeError(
                f"relation_text_features must have at least {num_relations_pred} rows, got {tuple(rel_text_feats.shape)}"
            )
        if int(rel_text_feats.size(0)) > int(num_relations_pred):
            rel_text_feats = rel_text_feats[:int(num_relations_pred)]
        rel_cache_root = Path(split_dir) / "relation_graphs"
        rel_graph_train = build_relation_graph_cached(
            train_graph,
            num_relations=num_relations_pred,
            rel_text_features=rel_text_feats,
            cooc_weight=float(cfg.get("relation_graph_cooc_weight", 1.0)),
            text_weight=float(cfg.get("relation_graph_text_weight", 1.0)),
            text_topk=int(cfg.get("relation_graph_topk", 10)),
            text_min_sim=float(cfg.get("relation_graph_min_sim", 0.0)),
            cache_dir=rel_cache_root,
            cache_tag="train",
        ).to(device=device)
        rel_graph_test = build_relation_graph_cached(
            test_graph,
            num_relations=num_relations_pred,
            rel_text_features=rel_text_feats,
            cooc_weight=float(cfg.get("relation_graph_cooc_weight", 1.0)),
            text_weight=float(cfg.get("relation_graph_text_weight", 1.0)),
            text_topk=int(cfg.get("relation_graph_topk", 10)),
            text_min_sim=float(cfg.get("relation_graph_min_sim", 0.0)),
            cache_dir=rel_cache_root,
            cache_tag="test",
        ).to(device=device)
        rel_text_feats = rel_text_feats.to(device=device)
        relation_module = RelationInductionModule(
            num_relations=num_relations_pred,
            text_feature_dim=int(rel_text_feats.size(1)),
            d_model=int(cfg.get("d_model", 256)),
            num_steps=int(cfg.get("relation_num_steps", 1)),
            tau=float(cfg.get("relation_tau", 0.005)),
            x1_mode=str(cfg.get("relation_x1_mode", "equal")),
        ).to(device)
        if "relation_induction_state_dict" in ckpt:
            relation_module.load_state_dict(ckpt["relation_induction_state_dict"])
        relation_module.eval()

    k_hops = int(args.k_hops) if args.k_hops is not None else int(cfg.get("k_hops", 2))
    drop_pair_edges = bool(args.drop_pair_edges) or bool(cfg.get("drop_pair_edges", False))

    filter_dict = None
    if args.filter_other_true_relations and benchmark is None:
        filter_dict = _pair_true_relations(torch.cat([split.train_pos, split.val_pos, split.test_pos], dim=0))

    # Validate (if present) and test.
    outs = {}
    if benchmark is None and split.val_pos.numel() > 0:
        relation_params = None
        relation_embs = None
        if relation_module is not None:
            with torch.no_grad():
                rel_out = relation_module(rel_text_feats, norm_adj=rel_graph_train)
            relation_params = {
                "raw_velocities": rel_out["raw_velocities"],
                "raw_alpha": rel_out["raw_alpha"],
                "raw_beta": rel_out["raw_beta"],
            }
            relation_embs = rel_out["relation_embs"]
        scores, y, _ = _scores_for_triples(
            split.val_pos,
            encoder=encoder,
            scorer=scorer,
            extractor=extractor_train,
            entity_text_features=feats,
            k_hops=k_hops,
            num_relations_pred=num_relations_pred,
            num_relations_original=num_relations_original,
            drop_pair_edges=drop_pair_edges,
            use_augmented_graph=use_aug,
            relation_params=relation_params,
            relation_embs=relation_embs,
        )
        filters = [set(filter_dict.get((int(h), int(t)), set())) for h, _, t in split.val_pos.tolist()] if filter_dict else None
        outs["val"] = relation_ranking_metrics(scores, y, tie_break=str(args.eval_tie_break), tie_seed=int(args.eval_tie_seed), filter_other_true=filters)

    if benchmark is None:
        test_triples = split.test_pos
        test_feats = feats
        filters = [set(filter_dict.get((int(h), int(t)), set())) for h, _, t in split.test_pos.tolist()] if filter_dict else None
    else:
        test_triples = torch.cat([benchmark.ind.valid, benchmark.ind.test], dim=0)
        test_feats = feats_ind
        filters = None

        if args.filter_other_true_relations:
            ind_filter = _pair_true_relations(torch.cat([benchmark.ind.train, benchmark.ind.valid, benchmark.ind.test], dim=0))
            filters = [set(ind_filter.get((int(h), int(t)), set())) for h, _, t in test_triples.tolist()]

        # Also report transductive validation as "val" if requested.
        if benchmark.trans.valid.numel() > 0:
            trans_filters = None
            if args.filter_other_true_relations:
                tra_filter = _pair_true_relations(torch.cat([benchmark.trans.train, benchmark.trans.valid, benchmark.trans.test], dim=0))
                trans_filters = [set(tra_filter.get((int(h), int(t)), set())) for h, _, t in benchmark.trans.valid.tolist()]
            scores_v, y_v, _ = _scores_for_triples(
                benchmark.trans.valid,
                encoder=encoder,
                scorer=scorer,
                extractor=extractor_train,
                entity_text_features=feats_trans,
                k_hops=k_hops,
                num_relations_pred=num_relations_pred,
                num_relations_original=num_relations_original,
                drop_pair_edges=drop_pair_edges,
                use_augmented_graph=use_aug,
            )
            outs["val"] = relation_ranking_metrics(
                scores_v, y_v, tie_break=str(args.eval_tie_break), tie_seed=int(args.eval_tie_seed), filter_other_true=trans_filters
            )

    relation_params = None
    relation_embs = None
    if relation_module is not None:
        with torch.no_grad():
            rel_out = relation_module(rel_text_feats, norm_adj=rel_graph_test)
        relation_params = {
            "raw_velocities": rel_out["raw_velocities"],
            "raw_alpha": rel_out["raw_alpha"],
            "raw_beta": rel_out["raw_beta"],
        }
        relation_embs = rel_out["relation_embs"]

    scores, y, _ = _scores_for_triples(
        test_triples,
        encoder=encoder,
        scorer=scorer,
        extractor=extractor_test,
        entity_text_features=test_feats,
        k_hops=k_hops,
        num_relations_pred=num_relations_pred,
        num_relations_original=num_relations_original,
        drop_pair_edges=drop_pair_edges,
        use_augmented_graph=use_aug,
        relation_params=relation_params,
        relation_embs=relation_embs,
    )
    outs["test"] = relation_ranking_metrics(scores, y, tie_break=str(args.eval_tie_break), tie_seed=int(args.eval_tie_seed), filter_other_true=filters)

    print(json.dumps(outs, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
