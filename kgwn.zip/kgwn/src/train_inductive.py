#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
import time
import resource
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import torch
import torch.nn as nn
from tqdm import tqdm

from datasets import KGDataset
from inductive.data.split_inductive import (
    InductiveSplit,
    assert_split_sane,
    load_split,
    make_entity_disjoint_split,
    save_split,
)
from inductive.data.subgraph import EnclosingSubgraphExtractor
from inductive.metrics import all_metrics, best_f1_threshold
from inductive.models.kgwn import KGWNSubgraphEncoder, create_compiled_encoder
from inductive.models.scorer import TripleScorer
from inductive.pipeline import (
    augment_with_inverse,
    build_known_true_set,
    edge_index_and_type_from_triples,
    sample_negatives_for_pos,
)
from inductive.tasks import score_triples
from inductive.batched_tasks import train_step_batched, score_triples_batched
from inductive.relation_induction import RelationInductionModule, build_relation_graph_cached
from text_init import build_entity_texts, build_relation_texts, encode_texts_feature_hash, encode_texts_hf


def _device(s: str) -> str:
    if s == "auto":
        if torch.cuda.is_available():
            return "cuda"
        if torch.backends.mps.is_available():
            return "mps"
        return "cpu"
    return s


def _cpu_max_rss_bytes() -> int:
    rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    if sys.platform == "darwin":
        return int(rss)
    return int(rss) * 1024


def _reset_peak_memory(device: str) -> None:
    if device.startswith("cuda") and torch.cuda.is_available():
        torch.cuda.reset_peak_memory_stats()


def _update_peak_memory(stats: Dict[str, float], device: str, *, prefix: str) -> None:
    if device.startswith("cuda") and torch.cuda.is_available():
        val = float(torch.cuda.max_memory_allocated())
        key = f"{prefix}_peak_mem_bytes"
        stats[key] = max(stats.get(key, 0.0), val)
        return
    if device == "mps" and torch.backends.mps.is_available():
        if hasattr(torch.mps, "current_allocated_memory"):
            val = float(torch.mps.current_allocated_memory())
            key = f"{prefix}_peak_mem_bytes"
            stats[key] = max(stats.get(key, 0.0), val)
        if hasattr(torch.mps, "driver_allocated_memory"):
            val = float(torch.mps.driver_allocated_memory())
            key = f"{prefix}_peak_driver_mem_bytes"
            stats[key] = max(stats.get(key, 0.0), val)
        return
    val = float(_cpu_max_rss_bytes())
    key = f"{prefix}_peak_mem_bytes"
    stats[key] = max(stats.get(key, 0.0), val)


def _count_trainable_params(*modules: nn.Module | None) -> int:
    total = 0
    for mod in modules:
        if mod is None:
            continue
        for param in mod.parameters():
            if param.requires_grad:
                total += int(param.numel())
    return int(total)


def _count_trainable_params_by_module(mod: nn.Module | None) -> int:
    if mod is None:
        return 0
    return int(sum(int(p.numel()) for p in mod.parameters() if p.requires_grad))


def _default_split_dir(*, data_root: str, dataset: str, p_test: float, p_val: float, seed: int) -> Path:
    tag = f"pTest{p_test:.2f}_pVal{p_val:.2f}_seed{int(seed):02d}".replace(".", "")
    return Path(data_root) / dataset / "inductive" / tag


def _default_text_features_path(*, data_root: str, dataset: str) -> Path:
    return Path(data_root) / dataset / "text_features_entities_bert-base-uncased_cls_L64.pt"


def _run_entity_feature_generator(
    args: argparse.Namespace,
    *,
    dataset: str,
    data_root: str,
    out_path: Path,
) -> None:
    cmd = [
        sys.executable,
        "src/generate_inductive_text_features.py",
        "--dataset",
        str(dataset),
        "--data_root",
        str(data_root),
        "--induction_kind",
        str(args.induction_kind),
        "--model_name",
        str(args.entity_text_model_name),
        "--pooling",
        str(args.entity_text_pooling),
        "--max_length",
        str(int(args.entity_text_max_length)),
        "--batch_size",
        str(int(args.entity_text_batch_size)),
        "--device",
        str(args.device),
        "--dim",
        str(int(args.text_feature_dim)),
    ]
    if bool(args.entity_text_use_hash):
        cmd.append("--use_hash")
    print("Generating entity text features:")
    print("  " + " ".join(cmd))
    subprocess.run(cmd, check=True)
    if not out_path.exists():
        raise RuntimeError(f"Expected entity features at {out_path}, but file was not created.")


def _default_relation_text_features_path(args: argparse.Namespace, *, data_root: str, dataset: str) -> Path:
    if bool(args.relation_text_use_hash):
        encoder_name = "hash"
    else:
        encoder_name = str(args.relation_text_model_name).replace("/", "_")
    return Path(data_root) / dataset / (
        f"text_features_relations_{encoder_name}_{args.relation_text_pooling}_L{int(args.relation_text_max_length)}.pt"
    )


def _run_relation_feature_generator(
    args: argparse.Namespace,
    *,
    dataset: str,
    data_root: str,
    out_path: Path,
) -> None:
    cmd = [
        sys.executable,
        "src/generate_inductive_relation_text_features.py",
        "--dataset",
        str(dataset),
        "--data_root",
        str(data_root),
        "--induction_kind",
        str(args.induction_kind),
        "--model_name",
        str(args.relation_text_model_name),
        "--pooling",
        str(args.relation_text_pooling),
        "--max_length",
        str(int(args.relation_text_max_length)),
        "--batch_size",
        str(int(args.relation_text_batch_size)),
        "--device",
        str(args.device),
        "--dim",
        str(int(args.relation_text_feature_dim)),
    ]
    if bool(args.relation_text_use_hash):
        cmd.append("--use_hash")
    print("Generating relation text features:")
    print("  " + " ".join(cmd))
    subprocess.run(cmd, check=True)
    if not out_path.exists():
        raise RuntimeError(f"Expected relation features at {out_path}, but file was not created.")


_VERSIONED_DATASET_RE = re.compile(r".*_v\d+_ind$")
_VERSION_ONLY_RE = re.compile(r".*_v\d+$")
_METRIC_ORDER = [
    "auroc",
    "auprc",
    "accuracy",
    "precision",
    "recall",
    "f1",
    "tp",
    "fp",
    "tn",
    "fn",
    "threshold",
    "hits@1",
    "hits@3",
    "hits@10",
    "mrr",
    "mr",
]


def _expand_datasets(dataset: str, *, data_root: str) -> List[str]:
    if _VERSIONED_DATASET_RE.match(dataset):
        return [dataset]
    root = Path(data_root)
    versioned = []
    for v in range(1, 5):
        candidate = f"{dataset}_v{v}_ind"
        if (root / candidate).exists():
            versioned.append(candidate)
    if versioned:
        return versioned
    if _VERSION_ONLY_RE.match(dataset):
        candidate = f"{dataset}_ind"
        if (root / candidate).exists():
            return [candidate]
    return [dataset]


def _resolve_inductive_root(data_root: str, *, induction_kind: str) -> str:
    root = Path(data_root)
    if root.name in {"entities", "relations"}:
        return str(root)
    subdir = "relations" if str(induction_kind).lower() == "relation" else "entities"
    return str(root / subdir)


def _list_relation_datasets(data_root: str) -> List[str]:
    root = Path(data_root)
    if not root.exists():
        return []
    return sorted([p.name for p in root.iterdir() if p.is_dir()])


def _expand_relation_datasets(dataset: str, *, data_root: str) -> List[str]:
    if (Path(data_root) / dataset).is_dir():
        return [dataset]
    all_names = _list_relation_datasets(data_root)
    prefix = f"{dataset}-"
    matches = [name for name in all_names if name.startswith(prefix)]
    if not matches:
        return []

    def sort_key(name: str) -> Tuple[int, object]:
        tail = name.split("-")[-1]
        try:
            return (0, int(tail))
        except ValueError:
            return (1, name)

    return sorted(matches, key=sort_key)


def _safe_name(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "_", name)


def _split_from_dataset_splits(
    ds: KGDataset,
    *,
    seed: int,
    p_test_entities: float,
    p_val_triples: float,
    num_relations_original: int,
) -> InductiveSplit:
    train_pos = ds.train_data.to(dtype=torch.long, device="cpu")
    val_pos = ds.valid_data.to(dtype=torch.long, device="cpu")
    test_pos = ds.test_data.to(dtype=torch.long, device="cpu")

    if val_pos.numel() > 0:
        v_train = torch.unique(torch.cat([train_pos[:, [0, 2]], val_pos[:, [0, 2]]], dim=0).reshape(-1))
    else:
        v_train = torch.unique(train_pos[:, [0, 2]].reshape(-1)) if train_pos.numel() > 0 else torch.empty(0, dtype=torch.long)

    if test_pos.numel() > 0:
        v_test_all = torch.unique(test_pos[:, [0, 2]].reshape(-1))
        if v_train.numel() > 0:
            v_test = v_test_all[~torch.isin(v_test_all, v_train)]
        else:
            v_test = v_test_all
    else:
        v_test = torch.empty(0, dtype=torch.long)

    return InductiveSplit(
        dataset=str(ds.name),
        seed=int(seed),
        p_test_entities=float(p_test_entities),
        p_val_triples=float(p_val_triples),
        num_entities=int(ds.num_entities),
        num_relations=int(ds.num_relations),
        num_relations_original=int(num_relations_original),
        v_train=v_train.to(dtype=torch.long),
        v_test=v_test.to(dtype=torch.long),
        train_pos=train_pos.to(dtype=torch.long),
        val_pos=val_pos.to(dtype=torch.long),
        test_pos=test_pos.to(dtype=torch.long),
    )


def _format_metric(value: object) -> str:
    try:
        v = float(value)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return str(value)
    if np.isnan(v):
        return "nan"
    if abs(v - round(v)) < 1e-8:
        return str(int(round(v)))
    return f"{v:.4f}"


def _write_multi_summary(
    run_summaries: List[Dict[str, object]],
    *,
    base_dataset: str,
    save_dir: str,
    timestamp: str,
    seed: int,
) -> Tuple[Path, Path]:
    safe_base = _safe_name(base_dataset)
    out_dir = Path(save_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    summary = {
        "base_dataset": base_dataset,
        "timestamp": timestamp,
        "seed": int(seed),
        "runs": run_summaries,
    }

    out_json = out_dir / f"summary_all_{safe_base}_seed{int(seed):02d}_{timestamp}.json"
    with open(out_json, "w") as f:
        json.dump(summary, f, indent=2)

    out_txt = out_dir / f"summary_all_{safe_base}_seed{int(seed):02d}_{timestamp}.txt"
    with open(out_txt, "w") as f:
        f.write(f"Base dataset: {base_dataset}\n")
        f.write(f"Timestamp: {timestamp}\n")
        f.write(f"Seed: {seed}\n")
        f.write("=" * 70 + "\n\n")

        for run in run_summaries:
            timing = run.get("timing", {})
            train_time = float(timing.get("train_time_sec", 0.0))
            test_time = float(timing.get("test_time_sec", 0.0))
            total_time = float(timing.get("total_time_sec", 0.0))

            f.write(f"Dataset: {run.get('dataset', 'unknown')}\n")
            f.write(f"Experiment: {run.get('experiment_name', 'unknown')}\n")
            f.write(f"Save dir: {run.get('save_dir', 'unknown')}\n")
            f.write(f"Timing (sec): train={train_time:.2f} test={test_time:.2f} total={total_time:.2f}\n")
            f.write(f"Best Validation {str(run.get('best_metric_name', 'metric')).upper()}: {float(run.get('best_metric', 0.0)):.4f}\n")

            val_best = run.get("validation_best", {})
            if isinstance(val_best, dict) and val_best:
                f.write("Best Validation Metrics:\n")
                if "epoch" in val_best:
                    f.write(f"  epoch: {_format_metric(val_best.get('epoch'))}\n")
                if "train_loss" in val_best:
                    f.write(f"  train_loss: {_format_metric(val_best.get('train_loss'))}\n")
                for key in _METRIC_ORDER:
                    if key in val_best:
                        f.write(f"  {key}: {_format_metric(val_best.get(key))}\n")
                extra_keys = [k for k in val_best.keys() if k not in _METRIC_ORDER and k not in {"epoch", "train_loss"}]
                for key in sorted(extra_keys):
                    f.write(f"  {key}: {_format_metric(val_best.get(key))}\n")

            test_metrics = run.get("test_metrics", {})
            if isinstance(test_metrics, dict) and test_metrics:
                f.write("Test Metrics:\n")
                for key in _METRIC_ORDER:
                    if key in test_metrics:
                        f.write(f"  {key}: {_format_metric(test_metrics.get(key))}\n")
                extra_keys = [k for k in test_metrics.keys() if k not in _METRIC_ORDER]
                for key in sorted(extra_keys):
                    f.write(f"  {key}: {_format_metric(test_metrics.get(key))}\n")

            f.write("-" * 70 + "\n")

    return out_json, out_txt


def _build_eval_dataset(
    pos: torch.Tensor,
    *,
    neg_per_pos: int,
    entity_pool: torch.Tensor,
    known_true: set[tuple[int, int, int]],
    epoch_key: int,
) -> Tuple[torch.Tensor, torch.Tensor, List[int] | None]:
    triples: List[List[int]] = []
    labels: List[float] = []
    group_sizes: List[int] | None = None
    all_neg = int(neg_per_pos) < 0

    if all_neg:
        group_sizes = []
        pool = entity_pool.to(dtype=torch.long, device="cpu").tolist()
        for row in pos.to(dtype=torch.long, device="cpu"):
            h, r, t = (int(row[0]), int(row[1]), int(row[2]))
            triples.append([h, r, t])
            labels.append(1.0)
            group_count = 1
            for ent in pool:
                cand = (h, r, int(ent))
                if cand != (h, r, t) and cand not in known_true:
                    triples.append([cand[0], cand[1], cand[2]])
                    labels.append(0.0)
                    group_count += 1
            for ent in pool:
                cand = (int(ent), r, t)
                if cand != (h, r, t) and cand not in known_true:
                    triples.append([cand[0], cand[1], cand[2]])
                    labels.append(0.0)
                    group_count += 1
            group_sizes.append(group_count)
    else:
        for row in pos.to(dtype=torch.long, device="cpu"):
            triples.append([int(row[0]), int(row[1]), int(row[2])])
            labels.append(1.0)
            if int(neg_per_pos) > 0:
                negs = sample_negatives_for_pos(
                    row,
                    num_neg=int(neg_per_pos),
                    entity_pool=entity_pool,
                    known_true=known_true,
                    epoch=int(epoch_key),
                )
                for neg in negs:
                    triples.append([int(neg[0]), int(neg[1]), int(neg[2])])
                    labels.append(0.0)

    if not triples:
        return (
            torch.empty(0, 3, dtype=torch.long),
            torch.empty(0, dtype=torch.float32),
            group_sizes,
        )
    return (
        torch.tensor(triples, dtype=torch.long),
        torch.tensor(labels, dtype=torch.float32),
        group_sizes,
    )


def _load_relation_text_features(args: argparse.Namespace, ds: KGDataset, *, device: str) -> torch.Tensor:
    if args.relation_text_features_path:
        feats = torch.load(Path(args.relation_text_features_path), map_location="cpu")
        return feats

    default_path = _default_relation_text_features_path(args, data_root=str(args.data_root), dataset=str(ds.name))
    if default_path.exists():
        args.relation_text_features_path = str(default_path)
        feats = torch.load(default_path, map_location="cpu")
        return feats

    rel_texts = build_relation_texts(ds, prefer="name_desc")
    if not bool(args.relation_text_use_hash):
        try:
            _run_relation_feature_generator(
                args,
                dataset=str(ds.name),
                data_root=str(args.data_root),
                out_path=default_path,
            )
            args.relation_text_features_path = str(default_path)
            feats = torch.load(default_path, map_location="cpu")
            return feats
        except Exception as e:
            print(f"Automatic relation feature generation failed ({e}).")
            print("Falling back to in-process encoding.")

    if bool(args.relation_text_use_hash):
        feats = encode_texts_feature_hash(
            rel_texts,
            dim=int(args.relation_text_feature_dim),
            seed=0,
            normalize="l2",
            dtype=torch.float32,
        )
        default_path.parent.mkdir(parents=True, exist_ok=True)
        torch.save(feats, default_path)
        args.relation_text_features_path = str(default_path)
        print(f"Saved relation text features to {default_path}")
        return feats

    try:
        feats = encode_texts_hf(
            rel_texts,
            model_name_or_path=str(args.relation_text_model_name),
            pooling=str(args.relation_text_pooling),
            max_length=int(args.relation_text_max_length),
            batch_size=int(args.relation_text_batch_size),
            device=str(device),
            local_files_only=True,
            dtype=None,
        )
        default_path.parent.mkdir(parents=True, exist_ok=True)
        torch.save(feats, default_path)
        args.relation_text_features_path = str(default_path)
        print(f"Saved relation text features to {default_path}")
        return feats
    except Exception as e:
        print(f"Relation HF encoder failed ({e}); falling back to feature hashing.")
        feats = encode_texts_feature_hash(
            rel_texts,
            dim=int(args.relation_text_feature_dim),
            seed=0,
            normalize="l2",
            dtype=torch.float32,
        )
        default_path.parent.mkdir(parents=True, exist_ok=True)
        torch.save(feats, default_path)
        args.relation_text_features_path = str(default_path)
        print(f"Saved relation text features to {default_path}")
        return feats


def _run_training(args: argparse.Namespace) -> Dict[str, object]:
    run_start = time.perf_counter()
    device = _device(str(args.device))
    config_preview = vars(args).copy()
    config_preview["resolved_device"] = device
    print("Hyperparameters:")
    print(json.dumps(config_preview, indent=2, sort_keys=True))
    torch.manual_seed(int(args.seed))
    np.random.seed(int(args.seed))

    # Load dataset (no downloads in inductive script).
    ds = KGDataset(root=str(args.data_root), name=str(args.dataset), download=False, percentage=1.0)
    num_relations = int(ds.num_relations)
    num_rel_original = int(ds.num_relations // 2)

    # Build or load split.
    split_dir = Path(args.split_dir) if args.split_dir else _default_split_dir(
        data_root=str(args.data_root),
        dataset=str(args.dataset),
        p_test=float(args.p_test_entities),
        p_val=float(args.p_val_triples),
        seed=int(args.seed),
    )

    if args.force_split:
        all_triples = torch.cat([ds.train_data, ds.valid_data, ds.test_data], dim=0)
        split = make_entity_disjoint_split(
            all_triples,
            dataset=str(args.dataset),
            num_entities=int(ds.num_entities),
            num_relations=num_relations,
            num_relations_original=num_rel_original,
            p_test_entities=float(args.p_test_entities),
            p_val_triples=float(args.p_val_triples),
            seed=int(args.seed),
            min_rel_train=int(args.min_rel_train),
        )
        save_split(split, split_dir)
    elif split_dir.exists():
        split = load_split(split_dir)
    elif str(args.dataset).lower().endswith("_ind"):
        split = _split_from_dataset_splits(
            ds,
            seed=int(args.seed),
            p_test_entities=float(args.p_test_entities),
            p_val_triples=float(args.p_val_triples),
            num_relations_original=num_rel_original,
        )
        save_split(split, split_dir)
        print(f"Using dataset-provided train/valid/test splits; cached split at {split_dir}")
    else:
        all_triples = torch.cat([ds.train_data, ds.valid_data, ds.test_data], dim=0)
        split = make_entity_disjoint_split(
            all_triples,
            dataset=str(args.dataset),
            num_entities=int(ds.num_entities),
            num_relations=num_relations,
            num_relations_original=num_rel_original,
            p_test_entities=float(args.p_test_entities),
            p_val_triples=float(args.p_val_triples),
            seed=int(args.seed),
            min_rel_train=int(args.min_rel_train),
        )
        save_split(split, split_dir)

    assert_split_sane(split)

    # Load entity text features.
    text_features_path = Path(args.text_features_path) if args.text_features_path else _default_text_features_path(
        data_root=str(args.data_root), dataset=str(args.dataset)
    )
    if not text_features_path.exists():
        if not bool(args.entity_text_use_hash):
            try:
                _run_entity_feature_generator(
                    args,
                    dataset=str(args.dataset),
                    data_root=str(args.data_root),
                    out_path=text_features_path,
                )
            except Exception as e:
                print(f"Automatic entity feature generation failed ({e}).")
                print("Falling back to in-process encoding.")
        if not text_features_path.exists():
            entity_texts = build_entity_texts(ds, prefer="name_desc")
            if bool(args.entity_text_use_hash):
                feats = encode_texts_feature_hash(
                    entity_texts,
                    dim=int(args.text_feature_dim),
                    seed=0,
                    normalize="l2",
                    dtype=torch.float16,
                )
            else:
                feats = encode_texts_hf(
                    entity_texts,
                    model_name_or_path=str(args.entity_text_model_name),
                    pooling=str(args.entity_text_pooling),
                    max_length=int(args.entity_text_max_length),
                    batch_size=int(args.entity_text_batch_size),
                    device=str(device),
                    local_files_only=True,
                    dtype=None,
                )
            text_features_path.parent.mkdir(parents=True, exist_ok=True)
            torch.save(feats, text_features_path)
            args.text_features_path = str(text_features_path)
            print(f"Saved entity text features to {text_features_path}")
    feats = torch.load(text_features_path, map_location="cpu")
    if feats.dim() != 2 or int(feats.size(0)) != int(split.num_entities):
        raise RuntimeError(f"text_features must be [num_entities, d] with num_entities={split.num_entities}, got {tuple(feats.shape)}")

    # Graphs for subgraph extraction (train uses train_pos graph; test uses test_pos graph).
    train_graph_triples = split.train_pos
    test_graph_triples = split.test_pos
    if bool(args.use_augmented_graph):
        train_graph_triples = augment_with_inverse(train_graph_triples, num_relations_original=int(split.num_relations_original))
        test_graph_triples = augment_with_inverse(test_graph_triples, num_relations_original=int(split.num_relations_original))

    train_edge_index, train_edge_type = edge_index_and_type_from_triples(train_graph_triples)
    test_edge_index, test_edge_type = edge_index_and_type_from_triples(test_graph_triples)

    cache_root = None
    if not bool(args.no_subgraph_cache):
        if args.subgraph_cache_dir:
            cache_root = Path(args.subgraph_cache_dir)
        else:
            cache_root = Path(split_dir) / f"subgraphs_k{int(args.k_hops)}"
    cache_train = cache_root / "train" if cache_root is not None else None
    cache_test = cache_root / "test" if cache_root is not None else None

    extractor_train = EnclosingSubgraphExtractor(
        num_nodes=int(split.num_entities),
        edge_index=train_edge_index,
        edge_type=train_edge_type,
        cache_dir=str(cache_train) if cache_train is not None else None,
    )
    extractor_test = EnclosingSubgraphExtractor(
        num_nodes=int(split.num_entities),
        edge_index=test_edge_index,
        edge_type=test_edge_type,
        cache_dir=str(cache_test) if cache_test is not None else None,
    )

    relation_text_feats = None
    rel_graph_train = None
    rel_graph_test = None
    relation_module = None
    if bool(getattr(args, "use_relation_induction", False)):
        relation_text_feats = _load_relation_text_features(args, ds, device=device)
        if relation_text_feats.dim() != 2 or int(relation_text_feats.size(0)) != int(num_relations):
            raise RuntimeError(
                f"relation_text_features must be [num_relations, d] with num_relations={num_relations}, got {tuple(relation_text_feats.shape)}"
            )
        rel_cache_root = Path(split_dir) / "relation_graphs"
        rel_graph_train = build_relation_graph_cached(
            train_graph_triples,
            num_relations=num_relations,
            rel_text_features=relation_text_feats,
            cooc_weight=float(args.relation_graph_cooc_weight),
            text_weight=float(args.relation_graph_text_weight),
            text_topk=int(args.relation_graph_topk),
            text_min_sim=float(args.relation_graph_min_sim),
            cache_dir=rel_cache_root,
            cache_tag="train",
        ).to(device=device)
        rel_graph_test = build_relation_graph_cached(
            test_graph_triples,
            num_relations=num_relations,
            rel_text_features=relation_text_feats,
            cooc_weight=float(args.relation_graph_cooc_weight),
            text_weight=float(args.relation_graph_text_weight),
            text_topk=int(args.relation_graph_topk),
            text_min_sim=float(args.relation_graph_min_sim),
            cache_dir=rel_cache_root,
            cache_tag="test",
        ).to(device=device)
        relation_text_feats = relation_text_feats.to(device=device)
        relation_module = RelationInductionModule(
            num_relations=num_relations,
            text_feature_dim=int(relation_text_feats.size(1)),
            d_model=int(args.d_model),
            num_steps=int(args.relation_num_steps),
            tau=float(args.relation_tau),
            x1_mode=str(args.relation_x1_mode),
        ).to(device)
        if not bool(args.use_frequency_adaptation):
            print("Warning: relation induction enabled but --use_frequency_adaptation is off; alpha/beta will be ignored.")

    # Pools / filtering sets.
    entity_pool_train = split.v_train.to(dtype=torch.long, device="cpu")
    if test_graph_triples.numel() > 0:
        entity_pool_test = torch.unique(test_graph_triples[:, [0, 2]].reshape(-1))
    else:
        entity_pool_test = split.v_test.to(dtype=torch.long, device="cpu")

    known_train = build_known_true_set(split.train_pos)
    known_val = build_known_true_set(torch.cat([split.train_pos, split.val_pos], dim=0)) if split.val_pos.numel() > 0 else known_train
    known_test = build_known_true_set(split.test_pos)

    # Model.
    encoder = KGWNSubgraphEncoder(
        num_relations=num_relations,
        text_feature_dim=int(args.text_feature_dim),
        d_model=int(args.d_model),
        num_steps=int(args.num_steps),
        tau=float(args.tau),
        margin=float(args.stability_margin),
        eps_anchor=float(args.eps_anchor),
        use_two_stream=bool(args.use_two_stream),
        use_frequency_adaptation=bool(args.use_frequency_adaptation),
        dropout=float(args.dropout),
        x1_mode=str(args.x1_mode),
    ).to(device)

    # Strategy 7: Apply torch.compile for JIT optimization
    if args.use_compile:
        print(f"Compiling encoder with mode={args.compile_mode}...")
        encoder = create_compiled_encoder(encoder, mode=args.compile_mode)
        print("Encoder compiled successfully.")

    scorer = TripleScorer(
        num_relations=num_relations,
        d_model=int(args.d_model),
        hidden=int(args.scorer_hidden),
    ).to(device)
    num_parameters = _count_trainable_params(encoder, scorer, relation_module)
    num_enc = _count_trainable_params_by_module(encoder)
    num_scorer = _count_trainable_params_by_module(scorer)
    num_relmod = _count_trainable_params_by_module(relation_module)
    print(f"Trainable parameters: total={num_parameters} encoder={num_enc} scorer={num_scorer} relation_module={num_relmod}")

    feats = feats.to(device=device)

    opt_params = list(encoder.parameters()) + list(scorer.parameters())
    if relation_module is not None:
        opt_params = opt_params + list(relation_module.parameters())
    opt = torch.optim.Adam(
        opt_params,
        lr=float(args.learning_rate),
        weight_decay=float(args.weight_decay),
    )
    loss_fn = nn.BCEWithLogitsLoss()

    # Save directory with timestamp for unique experiments.
    import datetime
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    experiment_name = f"{args.dataset}_seed{int(args.seed):02d}_{timestamp}"
    save_dir = Path(args.save_dir) / experiment_name
    save_dir.mkdir(parents=True, exist_ok=True)

    # Save full configuration
    config = vars(args).copy()
    config["experiment_name"] = experiment_name
    config["timestamp"] = timestamp
    config["split_dir"] = str(split_dir)
    config["num_train_triples"] = int(split.train_pos.size(0))
    config["num_val_triples"] = int(split.val_pos.size(0))
    config["num_test_triples"] = int(split.test_pos.size(0))
    config["num_train_entities"] = int(split.v_train.size(0))
    config["num_test_entities"] = int(split.v_test.size(0))

    with open(save_dir / "config.json", "w") as f:
        json.dump(config, f, indent=2)

    # Track validation metrics per epoch
    val_metrics_history: List[Dict[str, float]] = []
    epoch_stats: List[Dict[str, float]] = []

    best_metric = -1.0
    best_epoch = 0
    patience = int(args.patience)
    patience_left = patience
    best_state: Dict[str, object] = {}
    best_threshold = 0.0

    train_pos = split.train_pos.to(dtype=torch.long, device="cpu")
    gen = torch.Generator(device="cpu")
    gen.manual_seed(int(args.seed))

    setup_end = time.perf_counter()
    timing_train = {
        "neg_sample_sec": 0.0,
        "extract_sec": 0.0,
        "encode_sec": 0.0,
        "score_sec": 0.0,
        "backward_sec": 0.0,
        "batches": 0,
        "triples": 0,
    }
    timing_val = {"prep_sec": 0.0, "extract_sec": 0.0, "encode_sec": 0.0, "score_sec": 0.0, "batches": 0, "triples": 0, "wall_sec": 0.0}
    timing_test = {"prep_sec": 0.0, "extract_sec": 0.0, "encode_sec": 0.0, "score_sec": 0.0, "batches": 0, "triples": 0, "wall_sec": 0.0}

    train_start = time.perf_counter()
    epoch_pbar = tqdm(range(1, int(args.num_epochs) + 1), desc="Training", unit="epoch")
    for epoch in epoch_pbar:
        encoder.train()
        scorer.train()
        if relation_module is not None:
            relation_module.train()
        epoch_key = int(args.seed) + epoch
        epoch_train_start = time.perf_counter()
        epoch_mem: Dict[str, float] = {}
        _reset_peak_memory(device)

        perm = torch.randperm(int(train_pos.size(0)), generator=gen)
        total_loss = 0.0
        steps = 0

        num_batches = (int(train_pos.size(0)) + int(args.batch_pos) - 1) // int(args.batch_pos)
        batch_pbar = tqdm(
            range(0, int(train_pos.size(0)), int(args.batch_pos)),
            desc=f"Epoch {epoch}/{args.num_epochs}",
            unit="batch",
            total=num_batches,
            leave=False
        )

        for start in batch_pbar:
            pos_batch = train_pos[perm[start:start + int(args.batch_pos)]]
            triples: List[torch.Tensor] = []
            labels: List[torch.Tensor] = []
            t_neg0 = time.perf_counter()
            for row in pos_batch:
                triples.append(row)
                labels.append(torch.tensor(1.0))
                if int(args.neg_per_pos) > 0:
                    negs = sample_negatives_for_pos(
                        row,
                        num_neg=int(args.neg_per_pos),
                        entity_pool=entity_pool_train,
                        known_true=known_train,
                        epoch=epoch_key,
                    )
                    for neg in negs:
                        triples.append(neg)
                        labels.append(torch.tensor(0.0))
            t_neg1 = time.perf_counter()
            timing_train["neg_sample_sec"] += float(t_neg1 - t_neg0)

            batch_triples = torch.stack(triples, dim=0)
            y = torch.stack(labels, dim=0).to(device=device, dtype=torch.float32)

            relation_params = None
            relation_embs = None
            if relation_module is not None:
                rel_out = relation_module(relation_text_feats, norm_adj=rel_graph_train)
                relation_params = {
                    "raw_velocities": rel_out["raw_velocities"],
                    "raw_alpha": rel_out["raw_alpha"],
                    "raw_beta": rel_out["raw_beta"],
                }
                relation_embs = rel_out["relation_embs"]

            # Batched subgraph processing (with multi-threading!)
            xh_batch, xt_batch = train_step_batched(
                batch_triples,
                encoder=encoder,
                scorer=scorer,
                extractor=extractor_train,
                entity_text_features=feats,
                k_hops=int(args.k_hops),
                drop_target_edge=bool(args.drop_target_edge),
                relation_params=relation_params,
                num_workers=int(args.num_workers),
                stats=timing_train,
            )

            # Batch score all triples
            rel_ids = batch_triples[:, 1].to(device=device)
            t_score0 = time.perf_counter()
            logit_t = scorer.forward_batch(xh_batch, xt_batch, rel_ids, relation_embs=relation_embs)
            loss = loss_fn(logit_t, y)
            t_score1 = time.perf_counter()

            opt.zero_grad(set_to_none=True)
            loss.backward()
            if float(args.grad_clip) > 0:
                torch.nn.utils.clip_grad_norm_(list(encoder.parameters()) + list(scorer.parameters()), float(args.grad_clip))
            opt.step()
            t_score2 = time.perf_counter()
            timing_train["score_sec"] += float(t_score1 - t_score0)
            timing_train["backward_sec"] += float(t_score2 - t_score1)
            _update_peak_memory(epoch_mem, device, prefix="train")

            total_loss += float(loss.detach().cpu().item())
            steps += 1

            # Update batch progress bar with current loss
            avg_loss = total_loss / steps
            batch_pbar.set_postfix({"loss": f"{avg_loss:.4f}", "batch_loss": f"{float(loss.item()):.4f}"})

        # Validation: build pos+negs and score.
        epoch_train_end = time.perf_counter()
        epoch_record = {
            "epoch": int(epoch),
            "train_sec": float(epoch_train_end - epoch_train_start),
        }
        epoch_record.update(epoch_mem)
        if split.val_pos.numel() == 0:
            epoch_pbar.write(f"Epoch {epoch}: train_loss={total_loss/max(1,steps):.4f} (no val split)")
            epoch_stats.append(epoch_record)
            continue
        if int(args.eval_every) > 1 and (epoch % int(args.eval_every)) != 0:
            epoch_stats.append(epoch_record)
            continue

        val_mem: Dict[str, float] = {}
        _reset_peak_memory(device)
        val_wall_start = time.perf_counter()
        t_val0 = time.perf_counter()
        val_triples, val_labels, val_group_sizes = _build_eval_dataset(
            split.val_pos,
            neg_per_pos=int(args.eval_neg_per_pos),
            entity_pool=entity_pool_train,
            known_true=known_val,
            epoch_key=int(args.seed) + 10_000 + epoch,
        )
        t_val1 = time.perf_counter()
        timing_val["prep_sec"] += float(t_val1 - t_val0)

        # Validation with batched scoring (with multi-threading!)
        tqdm.write(f"Validating epoch {epoch}...")
        relation_params = None
        relation_embs = None
        if relation_module is not None:
            relation_module.eval()
            with torch.no_grad():
                rel_out = relation_module(relation_text_feats, norm_adj=rel_graph_train)
            relation_params = {
                "raw_velocities": rel_out["raw_velocities"],
                "raw_alpha": rel_out["raw_alpha"],
                "raw_beta": rel_out["raw_beta"],
            }
            relation_embs = rel_out["relation_embs"]
        val_logits = score_triples_batched(
            val_triples,
            encoder=encoder,
            scorer=scorer,
            extractor=extractor_train,
            entity_text_features=feats,
            k_hops=int(args.k_hops),
            drop_target_edge=bool(args.drop_target_edge),
            relation_params=relation_params,
            relation_embs=relation_embs,
            batch_size=int(args.batch_pos) * 2,  # Larger batches for validation (no gradients)
            show_progress=True,
            num_workers=int(args.num_workers),
            stats=timing_val,
        ).numpy()
        _update_peak_memory(val_mem, device, prefix="val")
        val_wall_end = time.perf_counter()
        epoch_record["val_sec"] = float(val_wall_end - val_wall_start)
        epoch_record.update(val_mem)
        epoch_stats.append(epoch_record)
        timing_val["wall_sec"] += float(val_wall_end - t_val0)
        val_probs = 1.0 / (1.0 + np.exp(-val_logits))
        y_true = val_labels.numpy()
        thr = best_f1_threshold(y_true, val_probs)
        m = all_metrics(
            y_true,
            val_probs,
            threshold=thr,
            include_ranking=True,
            group_sizes=val_group_sizes,
        )

        metric_name = str(args.early_stop_metric).lower()
        cur_metric = float(m.get(metric_name, float("nan")))

        # Save validation metrics for this epoch
        epoch_metrics = {
            "epoch": int(epoch),
            "train_loss": float(total_loss / max(1, steps)),
            **{k: float(v) for k, v in m.items()}
        }
        val_metrics_history.append(epoch_metrics)

        # Save metrics history to file (updated each epoch)
        with open(save_dir / "val_metrics_history.json", "w") as f:
            json.dump(val_metrics_history, f, indent=2)

        # Print epoch summary
        epoch_pbar.write(
            f"Epoch {epoch}/{args.num_epochs}: train_loss={total_loss/max(1,steps):.4f} "
            f"val_auroc={m['auroc']:.4f} val_auprc={m['auprc']:.4f} val_f1={m['f1']:.4f} "
            f"hits@1={m['hits@1']:.4f} hits@3={m['hits@3']:.4f} hits@10={m['hits@10']:.4f} "
            f"mrr={m['mrr']:.4f}"
        )

        # Update epoch progress bar
        epoch_pbar.set_postfix({
            "train_loss": f"{total_loss/max(1,steps):.4f}",
            "val_auroc": f"{m['auroc']:.4f}",
            "best_epoch": best_epoch
        })

        if cur_metric > best_metric:
            best_metric = cur_metric
            best_epoch = epoch
            best_threshold = float(thr)
            patience_left = patience
            best_state = {
                "epoch": int(epoch),
                "encoder_state_dict": encoder.state_dict(),
                "scorer_state_dict": scorer.state_dict(),
                "config": vars(args),
                "split_dir": str(split_dir),
                "val_metrics": m,
            }
            if relation_module is not None:
                best_state["relation_induction_state_dict"] = relation_module.state_dict()
            torch.save(best_state, save_dir / "best_model.pt")
        else:
            patience_left -= 1
            if patience_left <= 0:
                print(f"Early stopping at epoch {epoch} (best_epoch={best_epoch}, best_{metric_name}={best_metric:.4f})")
                break

    train_end = time.perf_counter()
    # Final test using best checkpoint.
    ckpt = torch.load(save_dir / "best_model.pt", map_location="cpu")
    encoder.load_state_dict(ckpt["encoder_state_dict"])
    scorer.load_state_dict(ckpt["scorer_state_dict"])
    if relation_module is not None and "relation_induction_state_dict" in ckpt:
        relation_module.load_state_dict(ckpt["relation_induction_state_dict"])
    encoder.to(device)
    scorer.to(device)
    if relation_module is not None:
        relation_module.eval()

    test_mem: Dict[str, float] = {}
    _reset_peak_memory(device)
    t_test0 = time.perf_counter()
    test_triples, test_labels, test_group_sizes = _build_eval_dataset(
        split.test_pos,
        neg_per_pos=int(args.eval_neg_per_pos),
        entity_pool=entity_pool_test,
        known_true=known_test,
        epoch_key=int(args.seed) + 20_000,
    )
    t_test1 = time.perf_counter()
    timing_test["prep_sec"] += float(t_test1 - t_test0)
    relation_params = None
    relation_embs = None
    if relation_module is not None:
        with torch.no_grad():
            rel_out = relation_module(relation_text_feats, norm_adj=rel_graph_test)
        relation_params = {
            "raw_velocities": rel_out["raw_velocities"],
            "raw_alpha": rel_out["raw_alpha"],
            "raw_beta": rel_out["raw_beta"],
        }
        relation_embs = rel_out["relation_embs"]
    test_logits = score_triples_batched(
        test_triples,
        encoder=encoder,
        scorer=scorer,
        extractor=extractor_test,
        entity_text_features=feats,
        k_hops=int(args.k_hops),
        drop_target_edge=bool(args.drop_target_edge),
        relation_params=relation_params,
        relation_embs=relation_embs,
        batch_size=int(args.batch_pos)*2,
        show_progress=True,
        num_workers=int(args.num_workers),
        stats=timing_test,
    ).numpy()
    _update_peak_memory(test_mem, device, prefix="test")
    test_probs = 1.0 / (1.0 + np.exp(-test_logits))
    test_m = all_metrics(
        test_labels.numpy(),
        test_probs,
        threshold=float(best_threshold),
        include_ranking=True,
        group_sizes=test_group_sizes,
    )
    test_end = time.perf_counter()
    timing_test["wall_sec"] += float(test_end - t_test0)

    epochs_run = int(epoch)
    train_peak_mem = max((float(e.get("train_peak_mem_bytes", 0.0)) for e in epoch_stats), default=0.0)
    val_peak_mem = max((float(e.get("val_peak_mem_bytes", 0.0)) for e in epoch_stats), default=0.0)
    train_peak_driver = max((float(e.get("train_peak_driver_mem_bytes", 0.0)) for e in epoch_stats), default=0.0)
    val_peak_driver = max((float(e.get("val_peak_driver_mem_bytes", 0.0)) for e in epoch_stats), default=0.0)

    timing = {
        "setup_time_sec": float(setup_end - run_start),
        "train_time_sec": float(train_end - train_start),
        "val_time_sec": float(timing_val.get("wall_sec", 0.0)),
        "test_time_sec": float(test_end - t_test0),
        "total_time_sec": float(test_end - run_start),
        "train_core_time_sec": float(timing_train["encode_sec"] + timing_train["score_sec"] + timing_train["backward_sec"]),
        "train_data_time_sec": float(timing_train["neg_sample_sec"] + timing_train["extract_sec"]),
        "train_extract_sec": float(timing_train["extract_sec"]),
        "train_encode_sec": float(timing_train["encode_sec"]),
        "train_score_sec": float(timing_train["score_sec"]),
        "train_backward_sec": float(timing_train["backward_sec"]),
        "train_neg_sample_sec": float(timing_train["neg_sample_sec"]),
        "val_prep_sec": float(timing_val.get("prep_sec", 0.0)),
        "val_extract_sec": float(timing_val.get("extract_sec", 0.0)),
        "val_encode_sec": float(timing_val.get("encode_sec", 0.0)),
        "val_score_sec": float(timing_val.get("score_sec", 0.0)),
        "test_prep_sec": float(timing_test.get("prep_sec", 0.0)),
        "test_extract_sec": float(timing_test.get("extract_sec", 0.0)),
        "test_encode_sec": float(timing_test.get("encode_sec", 0.0)),
        "test_score_sec": float(timing_test.get("score_sec", 0.0)),
        "train_peak_mem_bytes": train_peak_mem,
        "val_peak_mem_bytes": val_peak_mem,
        "train_peak_driver_mem_bytes": train_peak_driver,
        "val_peak_driver_mem_bytes": val_peak_driver,
    }
    timing.update(test_mem)
    timing["avg_train_epoch_sec"] = float(timing["train_time_sec"] / max(1, epochs_run))
    timing["avg_train_core_epoch_sec"] = float(timing["train_core_time_sec"] / max(1, epochs_run))
    timing["avg_train_data_epoch_sec"] = float(timing["train_data_time_sec"] / max(1, epochs_run))

    # Get best validation metrics
    best_val_metrics = val_metrics_history[best_epoch - 1] if best_epoch > 0 and best_epoch <= len(val_metrics_history) else {}

    # Comprehensive results
    results = {
        "experiment_name": experiment_name,
        "timestamp": timestamp,
        "dataset": str(args.dataset),
        "seed": int(args.seed),
        "num_parameters": int(num_parameters),
        "num_parameters_breakdown": {
            "encoder": int(num_enc),
            "scorer": int(num_scorer),
            "relation_module": int(num_relmod),
        },
        "best_epoch": int(best_epoch),
        "best_metric": float(best_metric),
        "best_metric_name": metric_name,
        "best_threshold": float(best_threshold),
        "total_epochs_run": int(epoch),
        "eval_every": int(args.eval_every),
        "validation_best": best_val_metrics,
        "test": test_m,
        "timing": timing,
        "epoch_stats": epoch_stats,
        "config_summary": {
            "d_model": int(args.d_model),
            "num_steps": int(args.num_steps),
            "k_hops": int(args.k_hops),
            "learning_rate": float(args.learning_rate),
            "batch_pos": int(args.batch_pos),
            "neg_per_pos": int(args.neg_per_pos),
            "eval_neg_per_pos": int(args.eval_neg_per_pos),
            "num_workers": int(args.num_workers),
            "num_parameters": int(num_parameters),
            "num_parameters_breakdown": {
                "encoder": int(num_enc),
                "scorer": int(num_scorer),
                "relation_module": int(num_relmod),
            },
            "scorer_hidden": int(args.scorer_hidden),
            "eval_every": int(args.eval_every),
        }
    }
    with open(save_dir / "results.json", "w") as f:
        json.dump(results, f, indent=2)

    # Create a summary text file for quick viewing
    with open(save_dir / "summary.txt", "w") as f:
        f.write(f"Experiment: {experiment_name}\n")
        f.write(f"Timestamp: {timestamp}\n")
        f.write(f"=" * 70 + "\n\n")
        f.write(f"Dataset: {args.dataset}\n")
        f.write(f"Seed: {args.seed}\n")
        f.write(f"Best Epoch: {best_epoch}/{epoch}\n")
        f.write(f"Best Validation {metric_name.upper()}: {best_metric:.4f}\n\n")
        f.write("Timing:\n")
        f.write(f"  Setup time (sec): {timing['setup_time_sec']:.2f}\n")
        f.write(f"  Train time (sec): {timing['train_time_sec']:.2f}\n")
        f.write(f"  Avg train epoch (sec): {timing['avg_train_epoch_sec']:.2f}\n")
        f.write(f"  Train core time (sec): {timing['train_core_time_sec']:.2f}\n")
        f.write(f"  Train data time (sec): {timing['train_data_time_sec']:.2f}\n")
        f.write(f"  Val time (sec):   {timing['val_time_sec']:.2f}\n")
        f.write(f"  Test time (sec):  {timing['test_time_sec']:.2f}\n")
        f.write(f"  Total time (sec): {timing['total_time_sec']:.2f}\n\n")
        train_peak = float(timing.get("train_peak_mem_bytes", 0.0))
        val_peak = float(timing.get("val_peak_mem_bytes", 0.0))
        if train_peak > 0:
            f.write(f"  Train peak mem (GB): {train_peak / (1024**3):.2f}\n")
        if val_peak > 0:
            f.write(f"  Val peak mem (GB):   {val_peak / (1024**3):.2f}\n")
        test_peak = float(timing.get("test_peak_mem_bytes", 0.0))
        if test_peak > 0:
            f.write(f"  Test peak mem (GB):  {test_peak / (1024**3):.2f}\n")
        f.write("\n")
        f.write("Test Results:\n")
        f.write("-" * 70 + "\n")
        f.write(f"Classification Metrics:\n")
        f.write(f"  AUROC:     {test_m['auroc']:.4f}\n")
        f.write(f"  AUPRC:     {test_m['auprc']:.4f}\n")
        f.write(f"  F1:        {test_m['f1']:.4f}\n")
        f.write(f"  Accuracy:  {test_m['accuracy']:.4f}\n")
        f.write(f"  Precision: {test_m['precision']:.4f}\n")
        f.write(f"  Recall:    {test_m['recall']:.4f}\n\n")
        f.write(f"Ranking Metrics:\n")
        f.write(f"  Hits@1:    {test_m['hits@1']:.4f}\n")
        f.write(f"  Hits@3:    {test_m['hits@3']:.4f}\n")
        f.write(f"  Hits@10:   {test_m['hits@10']:.4f}\n")
        f.write(f"  MRR:       {test_m['mrr']:.4f}\n")
        f.write(f"  MR:        {test_m['mr']:.2f}\n")

    print(f"\nSaved to: {save_dir}/")
    print(f"  - config.json (full configuration)")
    print(f"  - val_metrics_history.json (metrics per epoch)")
    print(f"  - results.json (final test results)")
    print(f"  - summary.txt (human-readable summary)")
    print(f"  - best_model.pt (best model checkpoint)")
    print(
        f"\nTiming (sec): train={timing['train_time_sec']:.2f} "
        f"core={timing['train_core_time_sec']:.2f} "
        f"val={timing['val_time_sec']:.2f} "
        f"test={timing['test_time_sec']:.2f} "
        f"total={timing['total_time_sec']:.2f}"
    )
    print(f"\nTest Results:")
    print(f"  Classification: auroc={test_m['auroc']:.4f} auprc={test_m['auprc']:.4f} f1={test_m['f1']:.4f} acc={test_m['accuracy']:.4f}")
    print(f"  Ranking: hits@1={test_m['hits@1']:.4f} hits@3={test_m['hits@3']:.4f} hits@10={test_m['hits@10']:.4f} mrr={test_m['mrr']:.4f} mr={test_m['mr']:.2f}")

    return {
        "dataset": str(args.dataset),
        "experiment_name": experiment_name,
        "save_dir": str(save_dir),
        "best_epoch": int(best_epoch),
        "best_metric_name": metric_name,
        "best_metric": float(best_metric),
        "best_threshold": float(best_threshold),
        "validation_best": best_val_metrics,
        "test_metrics": test_m,
        "timing": timing,
    }


def main() -> int:
    p = argparse.ArgumentParser(description="Inductive entity-disjoint triple validation with KGWN (text-only init).")
    p.add_argument(
        "--dataset",
        type=str,
        default="WN18RR_v1_ind",
        help="Dataset name. Use a base name (e.g., WN18RR, fb237, nell) to run all _v1-4_ind variants.",
    )
    p.add_argument("--induction_kind", type=str, default="entity", choices=["entity", "relation"])
    p.add_argument("--data_root", type=str, default="src/data/inductive")
    p.add_argument("--device", type=str, default="auto")
    p.add_argument("--seed", type=int, default=0)

    # Split
    p.add_argument("--split_dir", type=str, default=None)
    p.add_argument("--p_test_entities", type=float, default=0.2)
    p.add_argument("--p_val_triples", type=float, default=0.05)
    p.add_argument("--min_rel_train", type=int, default=1)
    p.add_argument("--force_split", action="store_true")

    # Subgraphs
    p.add_argument("--k_hops", type=int, default=2)
    p.add_argument("--use_augmented_graph", action="store_true", help="Include inverse edges in the graph used for subgraph extraction.")
    p.add_argument("--drop_target_edge", action="store_true", help="Remove (h,r,t) from the extracted subgraph before propagation.")
    p.add_argument("--subgraph_cache_dir", type=str, default=None, help="Directory for on-disk subgraph cache (default: <split_dir>/subgraphs_k{K}).")
    p.add_argument("--no_subgraph_cache", action="store_true", help="Disable on-disk subgraph caching.")

    # Model
    p.add_argument("--text_features_path", type=str, default=None)
    p.add_argument("--text_feature_dim", type=int, default=768)
    p.add_argument("--entity_text_use_hash", action="store_true", help="Use feature hashing for entity texts (no HF model).")
    p.add_argument("--entity_text_model_name", type=str, default="bert-base-uncased")
    p.add_argument("--entity_text_pooling", type=str, default="cls", choices=["cls", "mean"])
    p.add_argument("--entity_text_max_length", type=int, default=64)
    p.add_argument("--entity_text_batch_size", type=int, default=64)
    p.add_argument("--d_model", type=int, default=128)
    p.add_argument("--num_steps", type=int, default=3)
    p.add_argument("--tau", type=float, default=0.005)
    p.add_argument("--stability_margin", type=float, default=0.15)
    p.add_argument("--eps_anchor", type=float, default=0.2)
    p.add_argument("--use_two_stream", action="store_true", help="Use two-stream (lifted) mode for directional information")
    p.add_argument("--use_frequency_adaptation", action="store_true", help="Enable frequency-adaptive gates (α_r, β_r) for heterophilic relations (§3.3 in paper)")
    p.add_argument("--use_compile", action="store_true", help="Use torch.compile for 1.5-3x speedup (Strategy 7)")
    p.add_argument("--compile_mode", type=str, default="default", choices=["default", "reduce-overhead", "max-autotune"])
    p.add_argument("--dropout", type=float, default=0.2)
    p.add_argument("--x1_mode", type=str, default="equal", choices=["equal", "taylor"])
    p.add_argument("--scorer_hidden", type=int, default=128, help="Hidden size for the triple scoring MLP.")

    # Relation induction
    p.add_argument("--use_relation_induction", action="store_true", help="Enable relation-graph induction for per-relation parameters and relation embeddings.")
    p.add_argument("--relation_text_features_path", type=str, default=None)
    p.add_argument("--relation_text_feature_dim", type=int, default=768)
    p.add_argument("--relation_text_use_hash", action="store_true", help="Use feature hashing for relation texts (no HF model).")
    p.add_argument("--relation_text_model_name", type=str, default="bert-base-uncased")
    p.add_argument("--relation_text_pooling", type=str, default="cls", choices=["cls", "mean"])
    p.add_argument("--relation_text_max_length", type=int, default=32)
    p.add_argument("--relation_text_batch_size", type=int, default=64)
    p.add_argument("--relation_graph_topk", type=int, default=10)
    p.add_argument("--relation_graph_min_sim", type=float, default=0.0)
    p.add_argument("--relation_graph_cooc_weight", type=float, default=1.0)
    p.add_argument("--relation_graph_text_weight", type=float, default=1.0)
    p.add_argument("--relation_num_steps", type=int, default=1)
    p.add_argument("--relation_tau", type=float, default=0.005)
    p.add_argument("--relation_x1_mode", type=str, default="equal", choices=["equal", "taylor"])

    # Training
    p.add_argument("--save_dir", type=str, default="checkpoints/inductive")
    p.add_argument("--num_epochs", type=int, default=50)
    p.add_argument("--batch_pos", type=int, default=64, help="Number of positive triples per optimizer step.")
    p.add_argument("--neg_per_pos", type=int, default=20, help="Negatives per positive during training")
    p.add_argument(
        "--eval_neg_per_pos",
        type=int,
        default=-1,
        help="Negatives per positive during evaluation. Use -1 to rank against all entity corruptions (filtered).",
    )
    p.add_argument("--learning_rate", type=float, default=5e-4)
    p.add_argument("--weight_decay", type=float, default=1e-6)
    p.add_argument("--grad_clip", type=float, default=1.0)
    p.add_argument("--patience", type=int, default=3)
    p.add_argument("--early_stop_metric", type=str, default="mrr", choices=["mrr", "hits@10"])
    p.add_argument("--eval_every", type=int, default=1, help="Run validation every N epochs (default: 1).")
    p.add_argument("--num_workers", type=int, default=3, help="Number of parallel threads for subgraph extraction (default: 4, optimal with Python 3.13+ free-threading)")

    args = p.parse_args()
    resolved_root = _resolve_inductive_root(str(args.data_root), induction_kind=str(args.induction_kind))
    if Path(str(args.data_root)).name in {"entities", "relations"}:
        expected = "relations" if str(args.induction_kind).lower() == "relation" else "entities"
        if Path(str(args.data_root)).name != expected:
            print(f"Warning: --induction_kind={args.induction_kind} but data_root points to '{Path(str(args.data_root)).name}'. Using data_root as-is.")
    args.data_root = str(resolved_root)
    if str(args.induction_kind).lower() == "relation":
        datasets = _expand_relation_datasets(str(args.dataset), data_root=str(args.data_root))
        if not datasets:
            choices = _list_relation_datasets(str(args.data_root))
            print(f"Unknown relation dataset '{args.dataset}'. Available choices: {', '.join(choices)}")
            raise SystemExit(1)
    else:
        datasets = _expand_datasets(str(args.dataset), data_root=str(args.data_root))

    if len(datasets) > 1:
        print(f"Expanded dataset '{args.dataset}' to {len(datasets)} versions: {', '.join(datasets)}")
        if args.text_features_path:
            print("Warning: --text_features_path is set; the same file will be used for all datasets.")
        if args.split_dir:
            print("Warning: --split_dir is set; the same split directory will be used for all datasets.")

    run_summaries: List[Dict[str, object]] = []
    for dataset in datasets:
        run_args = argparse.Namespace(**vars(args))
        run_args.dataset = dataset
        print(f"\n=== Running dataset: {dataset} ===")
        print("Hyperparameters:")
        for key in sorted(vars(run_args).keys()):
            print(f"  {key}: {getattr(run_args, key)}")
        run_summary = _run_training(run_args)
        run_summaries.append(run_summary)

    if len(run_summaries) > 1:
        summary_timestamp = time.strftime("%Y%m%d_%H%M%S")
        out_json, out_txt = _write_multi_summary(
            run_summaries,
            base_dataset=str(args.dataset),
            save_dir=str(args.save_dir),
            timestamp=summary_timestamp,
            seed=int(args.seed),
        )
        print("\n=== Multi-run summary ===")
        print(f"Saved summary JSON: {out_json}")
        print(f"Saved summary TXT:  {out_txt}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
