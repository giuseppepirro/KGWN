"""
Batched subgraph processing for inductive KGWN.

This module provides efficient batched processing of multiple subgraphs,
avoiding the sequential one-at-a-time bottleneck.
"""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
import time
from typing import List, Tuple, Optional

import torch
from tqdm import tqdm

from inductive.data.subgraph import EnclosingSubgraphExtractor, Subgraph
from inductive.models.kgwn import KGWNSubgraphEncoder
from inductive.models.scorer import TripleScorer


def _extract_subgraph_worker(args):
    """Worker function for parallel subgraph extraction."""
    extractor, h, t, k_hops = args
    return extractor.extract(int(h), int(t), k_hops=int(k_hops))


def extract_subgraphs_parallel(
    batch_triples: torch.Tensor,
    extractor: EnclosingSubgraphExtractor,
    k_hops: int,
    num_workers: int = 4,
) -> List[Subgraph]:
    """
    Extract subgraphs in parallel using multi-threading.

    Args:
        batch_triples: [B, 3] tensor of (h, r, t) triples
        extractor: Subgraph extractor
        k_hops: Number of hops for extraction
        num_workers: Number of parallel threads (default: 4)

    Returns:
        List of subgraphs
    """
    if num_workers <= 1:
        # Sequential fallback
        subgraphs = []
        for i in range(batch_triples.size(0)):
            h, r, t = batch_triples[i]
            sg = extractor.extract(int(h.item()), int(t.item()), k_hops=int(k_hops))
            subgraphs.append(sg)
        return subgraphs

    # Parallel extraction
    tasks = [
        (extractor, batch_triples[i, 0].item(), batch_triples[i, 2].item(), k_hops)
        for i in range(batch_triples.size(0))
    ]

    with ThreadPoolExecutor(max_workers=num_workers) as executor:
        subgraphs = list(executor.map(_extract_subgraph_worker, tasks))

    return subgraphs


@torch.no_grad()
def score_triples_batched(
    triples: torch.Tensor,
    *,
    encoder: KGWNSubgraphEncoder,
    scorer: TripleScorer,
    extractor: EnclosingSubgraphExtractor,
    entity_text_features: torch.Tensor,
    k_hops: int,
    drop_target_edge: bool,
    relation_params: Optional[dict] = None,
    relation_embs: Optional[torch.Tensor] = None,
    batch_size: int = 32,
    show_progress: bool = True,
    num_workers: int = 4,
    stats: Optional[dict] = None,
) -> torch.Tensor:
    """
    Score triples in batches for better performance.

    Args:
        triples: [N, 3] tensor of (h, r, t) triples
        encoder: KGWN subgraph encoder
        scorer: Triple scorer
        extractor: Subgraph extractor
        entity_text_features: [num_entities, d] text features
        k_hops: Number of hops for subgraph extraction
        drop_target_edge: Whether to drop target edge
        batch_size: Number of triples to process in parallel
        show_progress: Whether to show progress bar

    Returns:
        logits: [N] tensor of scores
    """
    encoder.eval()
    scorer.eval()

    all_logits: List[torch.Tensor] = []
    triples_cpu = triples.to(dtype=torch.long, device="cpu")

    num_batches = (triples_cpu.size(0) + batch_size - 1) // batch_size
    iterator = range(0, triples_cpu.size(0), batch_size)

    if show_progress:
        iterator = tqdm(iterator, desc="Scoring batches", total=num_batches, unit="batch", leave=False)

    for start_idx in iterator:
        end_idx = min(start_idx + batch_size, triples_cpu.size(0))
        batch_triples = triples_cpu[start_idx:end_idx]

        # Extract all subgraphs for this batch (parallel!)
        t_extract0 = time.perf_counter()
        subgraphs = extract_subgraphs_parallel(
            batch_triples,
            extractor,
            k_hops=int(k_hops),
            num_workers=num_workers,
        )
        t_extract1 = time.perf_counter()
        rel_ids = [int(batch_triples[i, 1].item()) for i in range(batch_triples.size(0))]

        # Encode all subgraphs in parallel using multi-threading
        def _encode_worker(args):
            sg, rel_id = args
            xh, xt = encoder.encode(
                sg,
                entity_text_features=entity_text_features,
                rel_id=rel_id,
                k_hops=int(k_hops),
                drop_target_edge=bool(drop_target_edge),
                relation_params=relation_params,
            )
            return xh, xt

        t_encode0 = time.perf_counter()
        if num_workers <= 1:
            # Sequential fallback
            embeddings_h: List[torch.Tensor] = []
            embeddings_t: List[torch.Tensor] = []
            for sg, rel_id in zip(subgraphs, rel_ids):
                xh, xt = _encode_worker((sg, rel_id))
                embeddings_h.append(xh)
                embeddings_t.append(xt)
        else:
            # Parallel encoding
            encode_tasks = list(zip(subgraphs, rel_ids))
            with ThreadPoolExecutor(max_workers=num_workers) as executor:
                results = list(executor.map(_encode_worker, encode_tasks))
            embeddings_h = [xh for xh, xt in results]
            embeddings_t = [xt for xh, xt in results]
        t_encode1 = time.perf_counter()

        # Batch score all triples at once
        xh_batch = torch.stack(embeddings_h, dim=0)  # [batch_size, d]
        xt_batch = torch.stack(embeddings_t, dim=0)  # [batch_size, d]
        rel_batch = torch.tensor(rel_ids, device=xh_batch.device)  # [batch_size]

        # Score entire batch at once
        t_score0 = time.perf_counter()
        logits_batch = scorer.forward_batch(xh_batch, xt_batch, rel_batch, relation_embs=relation_embs)  # [batch_size]
        t_score1 = time.perf_counter()
        if stats is not None:
            stats["extract_sec"] = float(stats.get("extract_sec", 0.0)) + (t_extract1 - t_extract0)
            stats["encode_sec"] = float(stats.get("encode_sec", 0.0)) + (t_encode1 - t_encode0)
            stats["score_sec"] = float(stats.get("score_sec", 0.0)) + (t_score1 - t_score0)
            stats["batches"] = int(stats.get("batches", 0)) + 1
            stats["triples"] = int(stats.get("triples", 0)) + int(batch_triples.size(0))
        all_logits.append(logits_batch.detach().to("cpu"))

    return torch.cat(all_logits, dim=0)


def train_step_batched(
    batch_triples: torch.Tensor,
    *,
    encoder: KGWNSubgraphEncoder,
    scorer: TripleScorer,
    extractor: EnclosingSubgraphExtractor,
    entity_text_features: torch.Tensor,
    k_hops: int,
    drop_target_edge: bool,
    relation_params: Optional[dict] = None,
    num_workers: int = 4,
    stats: Optional[dict] = None,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """
    Training step with batched subgraph processing.

    Args:
        batch_triples: [B, 3] batch of (h, r, t) triples
        encoder: KGWN encoder (in train mode)
        scorer: Triple scorer (in train mode)
        extractor: Subgraph extractor
        entity_text_features: [num_entities, d] text features
        k_hops: Subgraph radius
        drop_target_edge: Whether to drop target edge

    Returns:
        xh_batch: [B, d] head embeddings
        xt_batch: [B, d] tail embeddings
    """
    # Extract all subgraphs (parallel!)
    t_extract0 = time.perf_counter()
    subgraphs = extract_subgraphs_parallel(
        batch_triples,
        extractor,
        k_hops=int(k_hops),
        num_workers=num_workers,
    )
    t_extract1 = time.perf_counter()
    rel_ids = [int(batch_triples[i, 1].item()) for i in range(batch_triples.size(0))]

    # Encode all subgraphs
    embeddings_h: List[torch.Tensor] = []
    embeddings_t: List[torch.Tensor] = []

    t_encode0 = time.perf_counter()
    for sg, rel_id in zip(subgraphs, rel_ids):
        xh, xt = encoder.encode(
            sg,
            entity_text_features=entity_text_features,
            rel_id=rel_id,
            k_hops=int(k_hops),
            drop_target_edge=bool(drop_target_edge),
            relation_params=relation_params,
        )
        embeddings_h.append(xh)
        embeddings_t.append(xt)
    t_encode1 = time.perf_counter()
    if stats is not None:
        stats["extract_sec"] = float(stats.get("extract_sec", 0.0)) + (t_extract1 - t_extract0)
        stats["encode_sec"] = float(stats.get("encode_sec", 0.0)) + (t_encode1 - t_encode0)
        stats["batches"] = int(stats.get("batches", 0)) + 1
        stats["triples"] = int(stats.get("triples", 0)) + int(batch_triples.size(0))

    # Stack into batches
    xh_batch = torch.stack(embeddings_h, dim=0)  # [B, d]
    xt_batch = torch.stack(embeddings_t, dim=0)  # [B, d]

    return xh_batch, xt_batch
