from __future__ import annotations

from typing import Dict, Iterable, List, Optional, Sequence, Tuple
import hashlib
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn


def _cooccurrence_edges(triples: torch.Tensor, num_relations: int) -> Dict[Tuple[int, int], float]:
    rels_by_entity: Dict[int, List[int]] = {}
    for h, r, t in triples.to(dtype=torch.long, device="cpu").tolist():
        rels_by_entity.setdefault(int(h), []).append(int(r))
        rels_by_entity.setdefault(int(t), []).append(int(r))

    counts: Dict[Tuple[int, int], float] = {}
    for rels in rels_by_entity.values():
        if len(rels) < 2:
            continue
        uniq = sorted(set(int(r) for r in rels if 0 <= int(r) < int(num_relations)))
        for i, r1 in enumerate(uniq):
            for r2 in uniq[i + 1:]:
                key = (int(r1), int(r2))
                counts[key] = counts.get(key, 0.0) + 1.0
    return counts


def _text_similarity_edges(
    rel_text_features: torch.Tensor,
    *,
    topk: int,
    min_sim: float,
) -> Dict[Tuple[int, int], float]:
    feats = rel_text_features.detach().to(dtype=torch.float32, device="cpu")
    if feats.numel() == 0:
        return {}
    num_rel = int(feats.size(0))
    if num_rel <= 1:
        return {}
    norms = torch.norm(feats, p=2, dim=1, keepdim=True).clamp(min=1e-12)
    feats = feats / norms
    sims = feats @ feats.t()

    edges: Dict[Tuple[int, int], float] = {}
    k = max(1, min(int(topk), num_rel - 1))
    for i in range(num_rel):
        row = sims[i]
        row[i] = -1.0
        vals, idxs = torch.topk(row, k=k)
        for v, j in zip(vals.tolist(), idxs.tolist()):
            if int(j) == int(i):
                continue
            if float(v) < float(min_sim):
                continue
            key = (int(min(i, j)), int(max(i, j)))
            cur = edges.get(key, 0.0)
            edges[key] = max(cur, float(v))
    return edges


def build_relation_graph(
    triples: torch.Tensor,
    *,
    num_relations: int,
    rel_text_features: Optional[torch.Tensor] = None,
    cooc_weight: float = 1.0,
    text_weight: float = 1.0,
    text_topk: int = 10,
    text_min_sim: float = 0.0,
) -> torch.sparse.Tensor:
    edges: Dict[Tuple[int, int], float] = {}

    if float(cooc_weight) > 0:
        cooc = _cooccurrence_edges(triples, num_relations)
        if cooc:
            max_c = max(cooc.values())
            denom = max(max_c, 1.0)
            for (i, j), v in cooc.items():
                w = float(cooc_weight) * float(v) / float(denom)
                edges[(i, j)] = edges.get((i, j), 0.0) + w

    if rel_text_features is not None and float(text_weight) > 0:
        sim = _text_similarity_edges(rel_text_features, topk=text_topk, min_sim=text_min_sim)
        for (i, j), v in sim.items():
            w = float(text_weight) * float(v)
            edges[(i, j)] = edges.get((i, j), 0.0) + w

    if not edges:
        indices = torch.empty(2, 0, dtype=torch.long)
        values = torch.empty(0, dtype=torch.float32)
        return torch.sparse_coo_tensor(indices, values, (int(num_relations), int(num_relations)))

    deg = torch.zeros(int(num_relations), dtype=torch.float32)
    for (i, j), w in edges.items():
        deg[int(i)] += float(w)
        deg[int(j)] += float(w)

    idx_rows: List[int] = []
    idx_cols: List[int] = []
    vals: List[float] = []
    for (i, j), w in edges.items():
        di = float(deg[int(i)])
        dj = float(deg[int(j)])
        if di <= 0.0 or dj <= 0.0:
            continue
        norm_w = float(w) / float(np.sqrt(di * dj))
        idx_rows.extend([int(i), int(j)])
        idx_cols.extend([int(j), int(i)])
        vals.extend([norm_w, norm_w])

    if not idx_rows:
        indices = torch.empty(2, 0, dtype=torch.long)
        values = torch.empty(0, dtype=torch.float32)
        return torch.sparse_coo_tensor(indices, values, (int(num_relations), int(num_relations)))

    indices = torch.tensor([idx_rows, idx_cols], dtype=torch.long)
    values = torch.tensor(vals, dtype=torch.float32)
    return torch.sparse_coo_tensor(indices, values, (int(num_relations), int(num_relations))).coalesce()


def _rel_graph_sig(
    rel_text_features: Optional[torch.Tensor],
    *,
    num_relations: int,
    cooc_weight: float,
    text_weight: float,
    text_topk: int,
    text_min_sim: float,
) -> str:
    parts = [
        f"R{int(num_relations)}",
        f"cw{str(float(cooc_weight)).replace('.', 'p')}",
        f"tw{str(float(text_weight)).replace('.', 'p')}",
        f"k{int(text_topk)}",
        f"ms{str(float(text_min_sim)).replace('.', 'p')}",
    ]
    if rel_text_features is None:
        parts.append("no_text")
        return "_".join(parts)
    feats = rel_text_features.detach().to(dtype=torch.float32, device="cpu")
    h = hashlib.sha1(feats.numpy().tobytes()).hexdigest()[:12]
    parts.append(f"h{h}")
    return "_".join(parts)


def build_relation_graph_cached(
    triples: torch.Tensor,
    *,
    num_relations: int,
    rel_text_features: Optional[torch.Tensor] = None,
    cooc_weight: float = 1.0,
    text_weight: float = 1.0,
    text_topk: int = 10,
    text_min_sim: float = 0.0,
    cache_dir: Optional[str | Path] = None,
    cache_tag: str = "graph",
) -> torch.sparse.Tensor:
    if cache_dir is None:
        return build_relation_graph(
            triples,
            num_relations=num_relations,
            rel_text_features=rel_text_features,
            cooc_weight=cooc_weight,
            text_weight=text_weight,
            text_topk=text_topk,
            text_min_sim=text_min_sim,
        )

    cache_root = Path(cache_dir)
    cache_root.mkdir(parents=True, exist_ok=True)
    sig = _rel_graph_sig(
        rel_text_features,
        num_relations=num_relations,
        cooc_weight=cooc_weight,
        text_weight=text_weight,
        text_topk=text_topk,
        text_min_sim=text_min_sim,
    )
    cache_path = cache_root / f"relgraph_{cache_tag}_{sig}.pt"
    if cache_path.exists():
        try:
            cached = torch.load(cache_path, map_location="cpu")
            if isinstance(cached, torch.Tensor):
                print(f"[relation graph cache] hit {cache_path}")
                return cached
        except Exception:
            pass

    graph = build_relation_graph(
        triples,
        num_relations=num_relations,
        rel_text_features=rel_text_features,
        cooc_weight=cooc_weight,
        text_weight=text_weight,
        text_topk=text_topk,
        text_min_sim=text_min_sim,
    )
    try:
        torch.save(graph.to(device="cpu").coalesce(), cache_path)
        print(f"[relation graph cache] saved {cache_path}")
    except Exception:
        pass
    return graph


def _apply_relation_operator(norm_adj: torch.sparse.Tensor, X: torch.Tensor) -> torch.Tensor:
    if norm_adj._nnz() == 0:
        return -X
    PX = torch.sparse.mm(norm_adj, X)
    return PX - X


def relation_wave_propagation(
    X0: torch.Tensor,
    *,
    norm_adj: torch.sparse.Tensor,
    num_steps: int,
    tau: float,
    x1_mode: str = "equal",
) -> torch.Tensor:
    if int(num_steps) <= 0:
        return X0
    x1_mode = str(x1_mode).lower()
    if x1_mode not in {"equal", "taylor"}:
        raise ValueError("x1_mode must be 'equal' or 'taylor'")

    X_prev = X0
    if x1_mode == "equal":
        X_curr = X0
    else:
        X_curr = X0 + (float(tau) ** 2 / 2.0) * _apply_relation_operator(norm_adj, X0)

    if int(num_steps) == 1:
        return X_curr

    for _ in range(1, int(num_steps)):
        X_next = (2.0 * X_curr + (float(tau) ** 2) * _apply_relation_operator(norm_adj, X_curr) - X_prev)
        X_prev, X_curr = X_curr, X_next
    return X_curr


class RelationInductionModule(nn.Module):
    """
    Relation induction via relation-graph wave propagation.

    Produces per-relation raw parameters (velocities, alpha, beta) and relation
    embeddings for relation-conditioned scoring.
    """

    def __init__(
        self,
        *,
        num_relations: int,
        text_feature_dim: int,
        d_model: int,
        num_steps: int,
        tau: float,
        x1_mode: str = "equal",
    ) -> None:
        super().__init__()
        self.num_relations = int(num_relations)
        self.text_feature_dim = int(text_feature_dim)
        self.d_model = int(d_model)
        self.num_steps = int(num_steps)
        self.tau = float(tau)
        self.x1_mode = str(x1_mode).lower()

        self.text_projector = nn.Linear(self.text_feature_dim, self.d_model, bias=True)
        self.fc_a = nn.Linear(self.d_model, 1, bias=True)
        self.fc_alpha = nn.Linear(self.d_model, 1, bias=True)
        self.fc_beta = nn.Linear(self.d_model, 1, bias=True)

    def forward(self, rel_text_features: torch.Tensor, *, norm_adj: torch.sparse.Tensor) -> Dict[str, torch.Tensor]:
        if int(rel_text_features.size(0)) != int(self.num_relations):
            raise ValueError(
                f"rel_text_features shape {tuple(rel_text_features.shape)} "
                f"does not match num_relations={self.num_relations}"
            )
        X0 = self.text_projector(rel_text_features)
        R = relation_wave_propagation(
            X0,
            norm_adj=norm_adj,
            num_steps=int(self.num_steps),
            tau=float(self.tau),
            x1_mode=self.x1_mode,
        )
        raw_velocities = self.fc_a(R).squeeze(-1)
        raw_alpha = self.fc_alpha(R).squeeze(-1)
        raw_beta = self.fc_beta(R).squeeze(-1)
        return {
            "relation_embs": R,
            "raw_velocities": raw_velocities,
            "raw_alpha": raw_alpha,
            "raw_beta": raw_beta,
        }
