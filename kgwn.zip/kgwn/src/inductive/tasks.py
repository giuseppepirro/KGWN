from __future__ import annotations

from dataclasses import dataclass
import time
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import torch
from tqdm import tqdm

from inductive.data.subgraph import EnclosingSubgraphExtractor
from inductive.models.kgwn import KGWNSubgraphEncoder
from inductive.models.scorer import TripleScorer


@dataclass
class TripleBatch:
    triples: torch.Tensor  # [B,3] on CPU
    labels: torch.Tensor  # [B] float on CPU


@torch.no_grad()
def score_triples(
    triples: torch.Tensor,
    *,
    encoder: KGWNSubgraphEncoder,
    scorer: TripleScorer,
    extractor: EnclosingSubgraphExtractor,
    entity_text_features: torch.Tensor,
    k_hops: int,
    drop_target_edge: bool,
    relation_params: Optional[Dict[str, torch.Tensor]] = None,
    relation_embs: Optional[torch.Tensor] = None,
    stats: Optional[dict] = None,
) -> torch.Tensor:
    """
    Returns logits [B] on CPU.
    """
    encoder.eval()
    scorer.eval()
    outs: List[torch.Tensor] = []
    triples_cpu = triples.to(dtype=torch.long, device="cpu")
    for i in tqdm(range(triples_cpu.size(0)), desc="Scoring triples", leave=False, unit="triple"):
        h, r, t = triples_cpu[i]
        t_extract0 = time.perf_counter()
        sg = extractor.extract(int(h.item()), int(t.item()), k_hops=int(k_hops))
        t_extract1 = time.perf_counter()
        t_encode0 = time.perf_counter()
        xh, xt = encoder.encode(
            sg,
            entity_text_features=entity_text_features,
            rel_id=int(r.item()),
            k_hops=int(k_hops),
            drop_target_edge=bool(drop_target_edge),
            relation_params=relation_params,
        )
        t_encode1 = time.perf_counter()
        t_score0 = time.perf_counter()
        logit = scorer(xh, xt, torch.tensor(int(r.item()), device=xh.device), relation_embs=relation_embs)
        t_score1 = time.perf_counter()
        if stats is not None:
            stats["extract_sec"] = float(stats.get("extract_sec", 0.0)) + (t_extract1 - t_extract0)
            stats["encode_sec"] = float(stats.get("encode_sec", 0.0)) + (t_encode1 - t_encode0)
            stats["score_sec"] = float(stats.get("score_sec", 0.0)) + (t_score1 - t_score0)
            stats["triples"] = int(stats.get("triples", 0)) + 1
        outs.append(logit.detach().to("cpu"))
    return torch.stack(outs, dim=0).reshape(-1)
