from __future__ import annotations

from typing import Dict, Optional, Sequence, Set, Tuple

import numpy as np


def _rank_true_from_scores(
    scores: np.ndarray,
    true_idx: int,
    *,
    tie_break: str = "random",
    rng: Optional[np.random.Generator] = None,
) -> int:
    """
    1-based rank of the true index among scores in descending order.
    Tie-breaking options: top, bottom, random (Sun et al.).
    """
    scores = np.asarray(scores, dtype=np.float64)
    true_idx = int(true_idx)
    s_true = float(scores[true_idx])
    higher = int(np.sum(scores > s_true))
    tied = np.where(scores == s_true)[0]
    tied_count = int(tied.size)
    if tied_count <= 1:
        return higher + 1
    tie_break = str(tie_break).lower()
    if tie_break == "top":
        return higher + 1
    if tie_break == "bottom":
        return higher + tied_count
    if tie_break == "random":
        if rng is None:
            rng = np.random.default_rng(0)
        u = int(rng.integers(1, tied_count + 1))
        return higher + u
    raise ValueError(f"Unknown tie_break={tie_break!r}")


def relation_ranking_metrics(
    all_scores: Sequence[np.ndarray],
    true_rel_ids: Sequence[int],
    *,
    hits_ks: Sequence[int] = (1, 3, 10),
    tie_break: str = "random",
    tie_seed: int = 0,
    filter_other_true: Optional[Sequence[Set[int]]] = None,
) -> Dict[str, float]:
    """
    Compute MRR/Hits@k for relation prediction.

    If `filter_other_true` is provided, it should be a list aligned to examples,
    containing other relation IDs (besides the target) that should be filtered out.
    """
    rng = np.random.default_rng(int(tie_seed))
    ranks: list[int] = []
    for i, (scores, y) in enumerate(zip(all_scores, true_rel_ids)):
        s = np.asarray(scores, dtype=np.float64).copy()
        y = int(y)
        if filter_other_true is not None:
            other = set(int(r) for r in filter_other_true[i])
            other.discard(y)
            for r in other:
                if 0 <= int(r) < int(s.size):
                    s[int(r)] = -np.inf
        rank = _rank_true_from_scores(s, y, tie_break=tie_break, rng=rng)
        ranks.append(rank)

    rr = [1.0 / float(r) for r in ranks]
    out: Dict[str, float] = {"MRR": float(np.mean(rr)), "MR": float(np.mean(ranks))}
    for k in hits_ks:
        out[f"Hits@{int(k)}"] = float(np.mean([1.0 if r <= int(k) else 0.0 for r in ranks]))
    return out

