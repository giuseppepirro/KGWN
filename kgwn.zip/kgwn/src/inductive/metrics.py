from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional, Sequence, Tuple

import numpy as np


def roc_auc(y_true: np.ndarray, y_score: np.ndarray) -> float:
    """
    ROC-AUC via rank statistics (tie-aware).
    """
    y_true = np.asarray(y_true).astype(np.int64)
    y_score = np.asarray(y_score).astype(np.float64)
    pos = (y_true == 1)
    neg = ~pos
    n_pos = int(pos.sum())
    n_neg = int(neg.sum())
    if n_pos == 0 or n_neg == 0:
        return float("nan")

    # Average ranks for ties.
    order = np.argsort(y_score, kind="mergesort")
    ranks = np.empty_like(order, dtype=np.float64)
    ranks[order] = np.arange(1, len(y_score) + 1, dtype=np.float64)

    # Tie correction: assign average rank within each tie block.
    sorted_scores = y_score[order]
    i = 0
    while i < len(sorted_scores):
        j = i + 1
        while j < len(sorted_scores) and sorted_scores[j] == sorted_scores[i]:
            j += 1
        if j - i > 1:
            avg = ranks[order[i:j]].mean()
            ranks[order[i:j]] = avg
        i = j

    sum_ranks_pos = ranks[pos].sum()
    auc = (sum_ranks_pos - n_pos * (n_pos + 1) / 2.0) / (n_pos * n_neg)
    return float(auc)


def average_precision(y_true: np.ndarray, y_score: np.ndarray) -> float:
    """
    Average precision (area under PR curve, stepwise).
    """
    y_true = np.asarray(y_true).astype(np.int64)
    y_score = np.asarray(y_score).astype(np.float64)
    n_pos = int((y_true == 1).sum())
    if n_pos == 0:
        return float("nan")

    order = np.argsort(-y_score, kind="mergesort")
    y = y_true[order]
    tp = (y == 1).astype(np.int64)
    fp = (y == 0).astype(np.int64)
    tp_cum = np.cumsum(tp)
    fp_cum = np.cumsum(fp)
    precision = tp_cum / np.maximum(tp_cum + fp_cum, 1)
    recall = tp_cum / float(n_pos)

    # AP = sum over points where y==1 of precision * delta_recall.
    ap = 0.0
    prev_recall = 0.0
    for i in range(len(y)):
        if y[i] == 1:
            ap += float(precision[i]) * float(recall[i] - prev_recall)
            prev_recall = float(recall[i])
    return float(ap)


def best_f1_threshold(y_true: np.ndarray, y_score: np.ndarray, *, num_thresholds: int = 200) -> float:
    y_true = np.asarray(y_true).astype(np.int64)
    y_score = np.asarray(y_score).astype(np.float64)
    lo = float(np.min(y_score))
    hi = float(np.max(y_score))
    if lo == hi:
        return lo
    best_thr = lo
    best_f1 = -1.0
    for thr in np.linspace(lo, hi, int(num_thresholds)):
        m = classification_metrics(y_true, y_score, threshold=float(thr))
        if m["f1"] > best_f1:
            best_f1 = float(m["f1"])
            best_thr = float(thr)
    return float(best_thr)


def classification_metrics(y_true: np.ndarray, y_score: np.ndarray, *, threshold: float) -> Dict[str, float]:
    y_true = np.asarray(y_true).astype(np.int64)
    y_score = np.asarray(y_score).astype(np.float64)
    y_pred = (y_score >= float(threshold)).astype(np.int64)
    tp = int(((y_pred == 1) & (y_true == 1)).sum())
    fp = int(((y_pred == 1) & (y_true == 0)).sum())
    tn = int(((y_pred == 0) & (y_true == 0)).sum())
    fn = int(((y_pred == 0) & (y_true == 1)).sum())
    precision = tp / float(tp + fp) if (tp + fp) > 0 else 0.0
    recall = tp / float(tp + fn) if (tp + fn) > 0 else 0.0
    f1 = (2 * precision * recall / (precision + recall)) if (precision + recall) > 0 else 0.0
    acc = (tp + tn) / float(tp + tn + fp + fn) if (tp + tn + fp + fn) > 0 else 0.0
    return {
        "accuracy": float(acc),
        "precision": float(precision),
        "recall": float(recall),
        "f1": float(f1),
        "tp": float(tp),
        "fp": float(fp),
        "tn": float(tn),
        "fn": float(fn),
    }


def ranking_metrics(
    y_true: np.ndarray,
    y_score: np.ndarray,
    group_size: Optional[int] = None,
    group_sizes: Optional[Sequence[int]] = None,
) -> Dict[str, float]:
    """
    Compute ranking metrics (Hits@K, MRR, MR) from binary labels and scores.

    Assumes data is organized in groups where each group has exactly one positive.
    Each group represents one query with candidates to rank. Use group_sizes for
    variable-sized groups (e.g., filtered ranking over all candidates).

    Args:
        y_true: Binary labels (1 for positive, 0 for negative) [N]
        y_score: Predicted scores (higher = more likely) [N]
        group_size: Size of each group. If None, infer from first positive position.

    Returns:
        Dictionary with hits@1, hits@3, hits@10, mrr (mean reciprocal rank), mr (mean rank)
    """
    y_true = np.asarray(y_true).astype(np.int64)
    y_score = np.asarray(y_score).astype(np.float64)

    if group_sizes is not None:
        sizes = [int(s) for s in group_sizes]
        if sum(sizes) != len(y_true):
            raise ValueError("group_sizes sum must match y_true length")
        ranks = []
        offset = 0
        for size in sizes:
            group_true = y_true[offset:offset + size]
            group_scores = y_score[offset:offset + size]
            pos_local = np.where(group_true == 1)[0]
            if len(pos_local) == 0:
                offset += size
                continue
            if len(pos_local) > 1:
                group_ranks = []
                for idx in pos_local:
                    pos_score = group_scores[int(idx)]
                    rank = int((group_scores > pos_score).sum()) + 1
                    group_ranks.append(rank)
                ranks.append(float(min(group_ranks)))
            else:
                pos_score = group_scores[int(pos_local[0])]
                rank = int((group_scores > pos_score).sum()) + 1
                ranks.append(float(rank))
            offset += size
        if not ranks:
            return {
                "hits@1": float("nan"),
                "hits@3": float("nan"),
                "hits@10": float("nan"),
                "mrr": float("nan"),
                "mr": float("nan"),
            }
        ranks = np.array(ranks, dtype=np.float64)
        return {
            "hits@1": float((ranks <= 1).mean()),
            "hits@3": float((ranks <= 3).mean()),
            "hits@10": float((ranks <= 10).mean()),
            "mrr": float((1.0 / ranks).mean()),
            "mr": float(ranks.mean()),
        }

    # Find positive examples
    pos_indices = np.where(y_true == 1)[0]
    n_pos = len(pos_indices)

    if n_pos == 0:
        return {
            "hits@1": float("nan"),
            "hits@3": float("nan"),
            "hits@10": float("nan"),
            "mrr": float("nan"),
            "mr": float("nan"),
        }

    # Infer group size from spacing between positives
    if group_size is None:
        if n_pos == 1:
            group_size = len(y_true)
        else:
            # Assume uniform group size based on first two positives
            group_size = int(pos_indices[1] - pos_indices[0])

    # For each positive, compute its rank within its group
    ranks = []
    for pos_idx in pos_indices:
        # Find the group this positive belongs to
        group_start = (pos_idx // group_size) * group_size
        group_end = group_start + group_size

        # Get scores for this group
        group_scores = y_score[group_start:group_end]
        pos_score = y_score[pos_idx]

        # Rank = number of candidates with higher score + 1
        # (Ties get optimistic rank)
        rank = int((group_scores > pos_score).sum()) + 1
        ranks.append(rank)

    ranks = np.array(ranks, dtype=np.float64)

    return {
        "hits@1": float((ranks <= 1).mean()),
        "hits@3": float((ranks <= 3).mean()),
        "hits@10": float((ranks <= 10).mean()),
        "mrr": float((1.0 / ranks).mean()),
        "mr": float(ranks.mean()),
    }


def all_metrics(
    y_true: np.ndarray,
    y_score: np.ndarray,
    *,
    threshold: Optional[float] = None,
    include_ranking: bool = False,
    group_size: Optional[int] = None,
    group_sizes: Optional[Sequence[int]] = None,
) -> Dict[str, float]:
    out: Dict[str, float] = {}
    out["auroc"] = roc_auc(y_true, y_score)
    out["auprc"] = average_precision(y_true, y_score)
    if threshold is not None:
        out.update(classification_metrics(y_true, y_score, threshold=float(threshold)))
        out["threshold"] = float(threshold)
    if include_ranking:
        out.update(ranking_metrics(y_true, y_score, group_size=group_size, group_sizes=group_sizes))
    return out
