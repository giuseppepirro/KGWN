"""Inductive models (subgraph KGWN encoder + task heads)."""
