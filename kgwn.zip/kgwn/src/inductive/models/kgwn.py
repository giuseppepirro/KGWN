from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn

from inductive.data.subgraph import Subgraph


def _stable_velocities(raw: torch.Tensor, *, tau: float, margin: float) -> torch.Tensor:
    """
    Positive velocities with global stability normalization (Eq. 14 style).
    """
    velocities = torch.nn.functional.softplus(raw)
    if tau == 0:
        return velocities
    sigma = torch.norm(velocities, p=2)
    threshold = float(np.sqrt(2.0 - float(margin)) / float(tau))
    if sigma > threshold:
        velocities = velocities * (threshold / sigma)
    return velocities


def _apply_centered_operator_sym(
    X: torch.Tensor,
    *,
    sym_heads: torch.Tensor,
    sym_tails: torch.Tensor,
    deg_inv_sqrt: torch.Tensor,
) -> torch.Tensor:
    if sym_heads.numel() == 0:
        return -X
    X_scaled = X * deg_inv_sqrt.unsqueeze(1)
    AX = torch.zeros_like(X_scaled)
    AX.index_add_(0, sym_heads, X_scaled[sym_tails])
    PX = AX * deg_inv_sqrt.unsqueeze(1)
    return PX - X


def _build_fused_laplacian_sym(
    rel_ops: List[_RelOpSym],
    velocities: torch.Tensor,
    num_nodes: int,
    device: torch.device,
    dtype: torch.dtype,
) -> torch.sparse.Tensor:
    """
    Build a fused sparse Laplacian that combines all relation operators.

    L_fused = Σ_r (velocity_r^2 * L_r)

    This allows computing L(X) = L_fused @ X in a single sparse matmul
    instead of looping over relations.
    """
    if not rel_ops:
        # No edges - return identity (so L(X) = -X)
        indices = torch.arange(num_nodes, device=device).unsqueeze(0).repeat(2, 1)
        values = torch.full((num_nodes,), -1.0, device=device, dtype=dtype)
        return torch.sparse_coo_tensor(indices, values, (num_nodes, num_nodes), dtype=dtype, device=device)

    all_indices = []
    all_values = []

    for op in rel_ops:
        # Extract velocity as scalar to avoid device issues
        a_sq = float((velocities[int(op.rel_id)] ** 2).item())

        # Keep tensors on CPU during construction
        sym_heads = op.sym_heads
        sym_tails = op.sym_tails
        deg_inv_sqrt = op.deg_inv_sqrt

        # Build P - I for this relation
        # P[i,j] = deg_inv_sqrt[i] * A[i,j] * deg_inv_sqrt[j]
        # where A[i,j] = 1 if edge (j→i)

        if sym_heads.numel() > 0:
            # P matrix: normalized adjacency (keep on CPU)
            p_values = deg_inv_sqrt[sym_heads] * deg_inv_sqrt[sym_tails] * a_sq
            p_indices = torch.stack([sym_heads, sym_tails], dim=0)

            all_indices.append(p_indices)
            all_values.append(p_values)

        # Add -a^2 * I (the -X part of P - I) - on CPU
        diag_indices = torch.arange(num_nodes, dtype=torch.long).unsqueeze(0).repeat(2, 1)
        diag_values = torch.full((num_nodes,), -a_sq, dtype=torch.float32)

        all_indices.append(diag_indices)
        all_values.append(diag_values)

    # Concatenate all indices and values
    indices = torch.cat(all_indices, dim=1)
    values = torch.cat(all_values, dim=0)

    # Create sparse tensor and coalesce (sum duplicate indices)
    L_fused = torch.sparse_coo_tensor(indices, values, (num_nodes, num_nodes), dtype=dtype, device=device)
    L_fused = L_fused.coalesce()

    return L_fused


def _build_fused_laplacian_lift(
    rel_ops: List["_RelOpLift"],
    velocities: torch.Tensor,
    num_nodes: int,
    device: torch.device,
    dtype: torch.dtype,
) -> torch.Tensor:
    """
    Build a fused sparse Laplacian for two-stream (lifted) mode.

    L_fused_lift = Σ_r (velocity_r^2 * L_r_lift)

    Each relation operator in lifted space:
      L_r_lift(Z) = P_r(Z) - Z
      P_r(Z) = D_r^{-1/2} B_r D_r^{-1/2} Z

    where B_r is the bipartite adjacency and D_r is the degree matrix.

    This allows propagation via: out = L_fused_lift @ Z (single matmul!)
    instead of: out = Σ_r (v_r^2 * L_r_lift(Z)) (loop over relations)
    """
    # Handle empty case (no edges in subgraph)
    if not rel_ops:
        # No edges - return -I (so L(Z) = -Z)
        indices = torch.arange(2 * num_nodes, dtype=torch.long).unsqueeze(0).repeat(2, 1)
        values = torch.full((2 * num_nodes,), -1.0, dtype=torch.float32)
        indices = indices.to(device=device)
        values = values.to(device=device, dtype=dtype)
        L_fused_lift = torch.sparse_coo_tensor(
            indices, values, (2 * num_nodes, 2 * num_nodes), dtype=dtype, device=device
        )
        return L_fused_lift.coalesce()

    all_indices = []
    all_values = []

    for op in rel_ops:
        lift_heads = op.lift_heads
        lift_tails = op.lift_tails
        deg_inv_sqrt = op.deg_inv_sqrt

        if lift_heads.numel() == 0:
            # Empty relation: L_r = -I
            # Add -velocity_r^2 * I to the diagonal
            v_sq_scalar = float((velocities[op.rel_id] ** 2).item())
            diag_indices = torch.arange(2 * num_nodes, dtype=torch.long)
            diag_vals = -v_sq_scalar * torch.ones(2 * num_nodes, dtype=torch.float32)
            all_indices.append(torch.stack([diag_indices, diag_indices], dim=0))
            all_values.append(diag_vals)
        else:
            # Build P_r = D^{-1/2} B D^{-1/2}
            # B has edges: (lift_heads[k], lift_tails[k])
            # P_r[i,j] = deg_inv_sqrt[i] * deg_inv_sqrt[j] if edge (i,j) in B

            # Scale by velocity (extract scalar to avoid device mismatch)
            v_sq_scalar = float((velocities[op.rel_id] ** 2).item())

            # Bipartite edges weighted by degree normalization
            edge_weights = deg_inv_sqrt[lift_heads] * deg_inv_sqrt[lift_tails] * v_sq_scalar

            # Add edges for P_r part
            all_indices.append(torch.stack([lift_heads, lift_tails], dim=0))
            all_values.append(edge_weights)

            # Add -I diagonal (the "-Z" part of L_r = P_r - I)
            # We need to add -v_sq to ALL diagonal entries
            diag_indices = torch.arange(2 * num_nodes, dtype=torch.long)
            diag_vals = -v_sq_scalar * torch.ones(2 * num_nodes, dtype=torch.float32)
            all_indices.append(torch.stack([diag_indices, diag_indices], dim=0))
            all_values.append(diag_vals)

    # Concatenate all contributions
    indices = torch.cat(all_indices, dim=1)
    values = torch.cat(all_values, dim=0)

    # Move to target device/dtype
    indices = indices.to(device=device)
    values = values.to(device=device, dtype=dtype)

    # Create sparse tensor and coalesce (sum duplicate indices)
    L_fused_lift = torch.sparse_coo_tensor(
        indices, values, (2 * num_nodes, 2 * num_nodes), dtype=dtype, device=device
    )
    L_fused_lift = L_fused_lift.coalesce()

    return L_fused_lift


def _apply_centered_operator_lift(
    Z: torch.Tensor,
    *,
    lift_heads: torch.Tensor,
    lift_tails: torch.Tensor,
    deg_inv_sqrt: torch.Tensor,
) -> torch.Tensor:
    if lift_heads.numel() == 0:
        return -Z
    Z_scaled = Z * deg_inv_sqrt.unsqueeze(1)
    BZ = torch.zeros_like(Z_scaled)
    BZ.index_add_(0, lift_heads, Z_scaled[lift_tails])
    PZ = BZ * deg_inv_sqrt.unsqueeze(1)
    return PZ - Z


@dataclass(frozen=True)
class _RelOpSym:
    rel_id: int
    sym_heads: torch.Tensor
    sym_tails: torch.Tensor
    deg_inv_sqrt: torch.Tensor


@dataclass(frozen=True)
class _RelOpLift:
    rel_id: int
    lift_heads: torch.Tensor
    lift_tails: torch.Tensor
    deg_inv_sqrt: torch.Tensor  # length 2N


def _build_rel_ops_sym(edge_index: torch.Tensor, edge_type: torch.Tensor, num_nodes: int) -> List[_RelOpSym]:
    if edge_index.numel() == 0:
        return []
    edge_index = edge_index.to(dtype=torch.long, device="cpu")
    edge_type = edge_type.to(dtype=torch.long, device="cpu")
    rel_ids = sorted(set(int(r) for r in edge_type.tolist()))
    ops: List[_RelOpSym] = []
    for r in rel_ids:
        mask = edge_type == int(r)
        rel_edges = edge_index[:, mask]
        if rel_edges.numel() == 0:
            sym_heads = torch.empty(0, dtype=torch.long)
            sym_tails = torch.empty(0, dtype=torch.long)
            deg = torch.zeros(int(num_nodes), dtype=torch.float32)
        else:
            heads = rel_edges[0].long()
            tails = rel_edges[1].long()
            sym_heads = torch.cat([heads, tails], dim=0)
            sym_tails = torch.cat([tails, heads], dim=0)
            deg = torch.bincount(sym_heads, minlength=int(num_nodes)).to(torch.float32)
        deg_inv_sqrt = torch.zeros_like(deg)
        nz = deg > 0
        deg_inv_sqrt[nz] = deg[nz].pow(-0.5)
        ops.append(_RelOpSym(rel_id=int(r), sym_heads=sym_heads, sym_tails=sym_tails, deg_inv_sqrt=deg_inv_sqrt))
    return ops


def _build_rel_ops_lift(edge_index: torch.Tensor, edge_type: torch.Tensor, num_nodes: int) -> List[_RelOpLift]:
    if edge_index.numel() == 0:
        return []
    edge_index = edge_index.to(dtype=torch.long, device="cpu")
    edge_type = edge_type.to(dtype=torch.long, device="cpu")
    rel_ids = sorted(set(int(r) for r in edge_type.tolist()))
    ops: List[_RelOpLift] = []
    N = int(num_nodes)
    for r in rel_ids:
        mask = edge_type == int(r)
        rel_edges = edge_index[:, mask]
        if rel_edges.numel() == 0:
            lift_heads = torch.empty(0, dtype=torch.long)
            lift_tails = torch.empty(0, dtype=torch.long)
            deg = torch.zeros(2 * N, dtype=torch.float32)
        else:
            heads = rel_edges[0].long()
            tails = rel_edges[1].long()
            heads_01 = heads
            tails_01 = tails + N
            heads_10 = tails + N
            tails_10 = heads
            lift_heads = torch.cat([heads_01, heads_10], dim=0)
            lift_tails = torch.cat([tails_01, tails_10], dim=0)
            deg = torch.bincount(lift_heads, minlength=2 * N).to(torch.float32)
        deg_inv_sqrt = torch.zeros_like(deg)
        nz = deg > 0
        deg_inv_sqrt[nz] = deg[nz].pow(-0.5)
        ops.append(_RelOpLift(rel_id=int(r), lift_heads=lift_heads, lift_tails=lift_tails, deg_inv_sqrt=deg_inv_sqrt))
    return ops


class KGWNSubgraphEncoder(nn.Module):
    """
    KGWN encoder for an induced subgraph with TEXT-only node initial features.

    This module does not contain learned per-entity embeddings; it relies on
    external frozen text features indexed by global entity IDs.
    """

    def __init__(
        self,
        *,
        num_relations: int,
        text_feature_dim: int,
        d_model: int,
        num_steps: int,
        tau: float,
        margin: float,
        eps_anchor: float = 0.0,
        use_two_stream: bool = False,
        marker_dim: int = 4,
        dropout: float = 0.0,
        x1_mode: str = "equal",
        use_frequency_adaptation: bool = False,
    ):
        super().__init__()
        self.num_relations = int(num_relations)
        self.text_feature_dim = int(text_feature_dim)
        self.d_model = int(d_model)
        self.num_steps = int(num_steps)
        self.tau = float(tau)
        self.margin = float(margin)
        self.eps_anchor = float(eps_anchor)
        self.use_two_stream = bool(use_two_stream)
        self.use_frequency_adaptation = bool(use_frequency_adaptation)
        self.marker_dim = int(marker_dim)
        self.x1_mode = str(x1_mode).lower()
        if self.x1_mode not in {"equal", "taylor"}:
            raise ValueError("x1_mode must be 'equal' or 'taylor'")

        self.text_projector = nn.Linear(self.text_feature_dim, self.d_model, bias=True)
        self.marker_projector = nn.Linear(self.marker_dim, self.d_model, bias=True)
        self.dropout = nn.Dropout(float(dropout))

        # Global learnable relation velocities (shared across all subgraphs).
        self.raw_velocities = nn.Parameter(torch.ones(self.num_relations))

        # Frequency adaptation parameters (§3.3 in paper)
        if self.use_frequency_adaptation:
            # α_r ∈ [-1,1]: signed frequency gates (smoothing vs sharpening)
            self.raw_alpha = nn.Parameter(torch.zeros(self.num_relations))
            # β_r: raw importance scores (will be normalized with softmax)
            self.raw_beta = nn.Parameter(torch.zeros(self.num_relations))
        else:
            self.raw_alpha = None
            self.raw_beta = None

        # Two-stream fusion (maps 2*d -> d for node readout).
        self.two_stream_fusion = nn.Linear(2 * self.d_model, self.d_model, bias=True) if self.use_two_stream else None

    def _marker_features(self, sg: Subgraph, *, k_hops: int, device: torch.device, dtype: torch.dtype) -> torch.Tensor:
        n = int(sg.node_ids.numel())
        is_h = torch.zeros(n, dtype=dtype, device=device)
        is_t = torch.zeros(n, dtype=dtype, device=device)
        is_h[int(sg.head_idx)] = 1.0
        is_t[int(sg.tail_idx)] = 1.0

        # Normalize distances to [0,1] with clipping; unreachable -> 1.
        k = max(1, int(k_hops))
        dh = sg.dist_to_h.to(device=device)
        dt = sg.dist_to_t.to(device=device)
        dh = torch.where(dh < 0, torch.full_like(dh, k + 1), dh).clamp_(0, k + 1).to(dtype=dtype)
        dt = torch.where(dt < 0, torch.full_like(dt, k + 1), dt).clamp_(0, k + 1).to(dtype=dtype)
        dh = dh / float(k + 1)
        dt = dt / float(k + 1)

        return torch.stack([is_h, is_t, dh, dt], dim=1)

    def encode(
        self,
        sg: Subgraph,
        *,
        entity_text_features: torch.Tensor,
        rel_id: int,
        k_hops: int,
        drop_target_edge: bool = True,
        drop_pair_edges: bool = False,
        drop_inverse_rel_id: Optional[int] = None,
        relation_params: Optional[Dict[str, torch.Tensor]] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Returns:
          (x_h, x_t) embeddings at time T (after propagation).
        """
        device = next(self.parameters()).device
        dtype = next(self.parameters()).dtype

        node_ids = sg.node_ids.to(device=device)
        tf = entity_text_features.index_select(0, node_ids).to(device=device, dtype=dtype)
        X0 = self.text_projector(tf)
        markers = self._marker_features(sg, k_hops=int(k_hops), device=device, dtype=dtype)
        X0 = X0 + self.marker_projector(markers)
        X0 = self.dropout(X0)

        # Optionally remove the target edge (h,r,t) from the subgraph before propagation.
        edge_index = sg.edge_index.to(device=device)
        edge_type = sg.edge_type.to(device=device)
        if edge_type.numel() > 0 and (drop_target_edge or drop_pair_edges or drop_inverse_rel_id is not None):
            hloc = int(sg.head_idx)
            tloc = int(sg.tail_idx)
            r = int(rel_id)
            keep = torch.ones(int(edge_type.numel()), dtype=torch.bool, device=device)
            if drop_pair_edges:
                keep = keep & ~(((edge_index[0] == hloc) & (edge_index[1] == tloc)) | ((edge_index[0] == tloc) & (edge_index[1] == hloc)))
            if drop_target_edge:
                keep = keep & ~((edge_index[0] == hloc) & (edge_index[1] == tloc) & (edge_type == r))
            if drop_inverse_rel_id is not None:
                inv_r = int(drop_inverse_rel_id)
                keep = keep & ~((edge_index[0] == tloc) & (edge_index[1] == hloc) & (edge_type == inv_r))
            edge_index = edge_index[:, keep]
            edge_type = edge_type[keep]

        raw_velocities = self.raw_velocities
        if relation_params is not None and "raw_velocities" in relation_params:
            raw_velocities = relation_params["raw_velocities"]
        raw_velocities = raw_velocities.to(device=device, dtype=dtype)
        velocities = _stable_velocities(raw_velocities, tau=float(self.tau), margin=float(self.margin))

        # Compute frequency adaptation parameters if enabled (§3.3, Eq. 8)
        if self.use_frequency_adaptation:
            raw_alpha = self.raw_alpha
            raw_beta = self.raw_beta
            if relation_params is not None:
                if "raw_alpha" in relation_params:
                    raw_alpha = relation_params["raw_alpha"]
                if "raw_beta" in relation_params:
                    raw_beta = relation_params["raw_beta"]
            if raw_alpha is None or raw_beta is None:
                raise RuntimeError("Frequency adaptation enabled but raw_alpha/raw_beta are missing.")
            # α_r ∈ [-1,1]: signed frequency gates
            alpha = torch.tanh(raw_alpha.to(device=device, dtype=dtype))
            # If anchoring is off, disallow sharpening to preserve stability.
            if self.eps_anchor <= 0:
                alpha = alpha.clamp(min=0.0)
            # β_r ≥ 0, Σ_r β_r = 1: normalized importance weights
            beta = torch.softmax(raw_beta.to(device=device, dtype=dtype), dim=0)
        else:
            # Default: α_r = 1 (smoothing only), β_r = 1 (uniform weighting)
            alpha = None
            beta = None

        if not self.use_two_stream:
            # Use original loop-based approach (fused Laplacian was slower on MPS)
            rel_ops = _build_rel_ops_sym(edge_index.detach().cpu(), edge_type.detach().cpu(), int(node_ids.numel()))

            beta_scale = 1.0
            rel_ids = []
            if self.use_frequency_adaptation:
                rel_ids = [op.rel_id for op in rel_ops]
                if rel_ids:
                    rel_ids_t = torch.tensor(rel_ids, device=device, dtype=torch.long)
                    beta_sub = beta.index_select(0, rel_ids_t)
                    denom = float(beta_sub.sum().item())
                    if denom > 0:
                        beta_scale = 1.0 / denom

                    # Signed-gate stability normalization (Eq. 10): eta uses kappa.
                    if self.eps_anchor > 0:
                        a_sq = velocities.index_select(0, rel_ids_t) ** 2
                        alpha_sub = alpha.index_select(0, rel_ids_t).abs()
                        kappa = (beta_sub * beta_scale * alpha_sub * a_sq).sum()
                        kappa_val = float(kappa.item())
                        num = float(self.eps_anchor - self.margin)
                        if num > 0.0 and kappa_val > 0.0:
                            eta = min(1.0, num / (2.0 * (self.tau ** 2) * kappa_val))
                        else:
                            eta = 1.0
                        velocities = velocities * float(np.sqrt(max(0.0, eta)))

            def L_agg_apply(X: torch.Tensor) -> torch.Tensor:
                out = torch.zeros_like(X)
                for op in rel_ops:
                    r_id = int(op.rel_id)
                    a = velocities[r_id]
                    Lx = _apply_centered_operator_sym(
                        X,
                        sym_heads=op.sym_heads.to(device=device),
                        sym_tails=op.sym_tails.to(device=device),
                        deg_inv_sqrt=op.deg_inv_sqrt.to(device=device, dtype=dtype),
                    )
                    # Adaptive aggregation (Eq. 8): L̃_agg = Σ_r (β_r · α_r · a_r² · L_r)
                    if self.use_frequency_adaptation:
                        weight = (beta[r_id] * beta_scale) * alpha[r_id] * (a ** 2)
                    else:
                        weight = a ** 2
                    out = out + weight * Lx
                return out

            X_prev = X0
            if self.x1_mode == "equal":
                X_curr = X0
            else:
                # Taylor-consistent X1 = X0 + (tau^2/2) L X0 (zero velocity)
                X_curr = X0 + (self.tau ** 2 / 2.0) * L_agg_apply(X0)

            if self.num_steps <= 0:
                X_T = X0
            elif self.num_steps == 1:
                X_T = X_curr
            else:
                for _ in range(self.num_steps - 1):
                    L_X = L_agg_apply(X_curr)
                    X_next = 2 * X_curr + (self.tau ** 2) * L_X - X_prev
                    if self.eps_anchor != 0.0:
                        X_next = X_next + float(self.eps_anchor) * (X0 - X_curr)
                    X_prev, X_curr = X_curr, X_next
                X_T = X_curr

            x_h = X_T[int(sg.head_idx)]
            x_t = X_T[int(sg.tail_idx)]
            return x_h, x_t

        # Two-stream lifted propagation.
        N = int(node_ids.numel())
        rel_ops_lift = _build_rel_ops_lift(edge_index.detach().cpu(), edge_type.detach().cpu(), N)
        Z0 = torch.cat([X0, X0], dim=0)  # [2N, d]

        # Use original loop-based approach (fused Laplacian was slower on MPS)
        beta_scale = 1.0
        rel_ids = []
        if self.use_frequency_adaptation:
            rel_ids = [op.rel_id for op in rel_ops_lift]
            if rel_ids:
                rel_ids_t = torch.tensor(rel_ids, device=device, dtype=torch.long)
                beta_sub = beta.index_select(0, rel_ids_t)
                denom = float(beta_sub.sum().item())
                if denom > 0:
                    beta_scale = 1.0 / denom

                # Signed-gate stability normalization (Eq. 10): eta uses kappa.
                if self.eps_anchor > 0:
                    a_sq = velocities.index_select(0, rel_ids_t) ** 2
                    alpha_sub = alpha.index_select(0, rel_ids_t).abs()
                    kappa = (beta_sub * beta_scale * alpha_sub * a_sq).sum()
                    kappa_val = float(kappa.item())
                    num = float(self.eps_anchor - self.margin)
                    if num > 0.0 and kappa_val > 0.0:
                        eta = min(1.0, num / (2.0 * (self.tau ** 2) * kappa_val))
                    else:
                        eta = 1.0
                    velocities = velocities * float(np.sqrt(max(0.0, eta)))

        def L_agg_apply_lift(Z: torch.Tensor) -> torch.Tensor:
            out = torch.zeros_like(Z)
            for op in rel_ops_lift:
                r_id = int(op.rel_id)
                a = velocities[r_id]
                Lz = _apply_centered_operator_lift(
                    Z,
                    lift_heads=op.lift_heads.to(device=device),
                    lift_tails=op.lift_tails.to(device=device),
                    deg_inv_sqrt=op.deg_inv_sqrt.to(device=device, dtype=dtype),
                )
                # Adaptive aggregation (Eq. 8): L̃_agg = Σ_r (β_r · α_r · a_r² · L_r)
                if self.use_frequency_adaptation:
                    weight = (beta[r_id] * beta_scale) * alpha[r_id] * (a ** 2)
                else:
                    weight = a ** 2
                out = out + weight * Lz
            return out

        Z_prev = Z0
        if self.x1_mode == "equal":
            Z_curr = Z0
        else:
            Z_curr = Z0 + (self.tau ** 2 / 2.0) * L_agg_apply_lift(Z0)

        if self.num_steps <= 0:
            Z_T = Z0
        elif self.num_steps == 1:
            Z_T = Z_curr
        else:
            for _ in range(self.num_steps - 1):
                L_Z = L_agg_apply_lift(Z_curr)
                Z_next = 2 * Z_curr + (self.tau ** 2) * L_Z - Z_prev
                if self.eps_anchor != 0.0:
                    Z_next = Z_next + float(self.eps_anchor) * (Z0 - Z_curr)
                Z_prev, Z_curr = Z_curr, Z_next
            Z_T = Z_curr

        zh = torch.cat([Z_T[int(sg.head_idx)], Z_T[int(sg.head_idx) + N]], dim=0)
        zt = torch.cat([Z_T[int(sg.tail_idx)], Z_T[int(sg.tail_idx) + N]], dim=0)
        if self.two_stream_fusion is None:
            raise RuntimeError("two_stream_fusion missing")
        return self.two_stream_fusion(zh), self.two_stream_fusion(zt)


def create_compiled_encoder(
    encoder: KGWNSubgraphEncoder,
    *,
    mode: str = "default",
    fullgraph: bool = False,
    dynamic: bool = True,
) -> KGWNSubgraphEncoder:
    """
    Strategy 7: Apply torch.compile to the encoder for JIT optimization.

    Args:
        encoder: The KGWNSubgraphEncoder instance to compile
        mode: Compilation mode - "default", "reduce-overhead", or "max-autotune"
            - "default": Balanced compilation (recommended)
            - "reduce-overhead": Minimize overhead, good for small models
            - "max-autotune": Aggressive optimization, slower compile, faster runtime
        fullgraph: If True, require entire graph to be compiled (stricter, may fail)
        dynamic: If True, allow dynamic shapes (more flexible, recommended)

    Returns:
        The encoder with compiled encode() method

    Example:
        >>> encoder = KGWNSubgraphEncoder(...)
        >>> encoder = create_compiled_encoder(encoder, mode="default")
        >>> # Now encoder.encode() will use torch.compile for 1.5-3x speedup

    Note:
        - First call will be slow (compilation time)
        - Subsequent calls will be much faster
        - Works best on CUDA, CPU, and recent MPS (macOS M1/M2/M3)
        - May have issues with very dynamic control flow
        - torch.compile requires PyTorch 2.0+ and Python < 3.14
    """
    import torch
    import sys

    # Check if torch.compile is available
    if sys.version_info >= (3, 14):
        import warnings
        warnings.warn(
            f"torch.compile is not supported on Python {sys.version_info.major}.{sys.version_info.minor}. "
            "Skipping compilation. For torch.compile support, use Python 3.13 or earlier.",
            RuntimeWarning
        )
        return encoder

    try:
        # Compile the encode method
        encoder.encode = torch.compile(
            encoder.encode,
            mode=mode,
            fullgraph=fullgraph,
            dynamic=dynamic,
        )
    except Exception as e:
        import warnings
        warnings.warn(
            f"torch.compile failed: {e}. Continuing without compilation.",
            RuntimeWarning
        )

    return encoder
