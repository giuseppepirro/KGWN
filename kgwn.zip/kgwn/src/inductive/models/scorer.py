from __future__ import annotations

import torch
import torch.nn as nn


class TripleScorer(nn.Module):
    """
    Triple validation head: sigmoid(MLP([x_h, x_t, x_h*x_t, e_r])).
    """

    def __init__(self, *, num_relations: int, d_model: int, hidden: int = 512, dropout: float = 0.1):
        super().__init__()
        self.num_relations = int(num_relations)
        self.d_model = int(d_model)
        self.rel_emb = nn.Embedding(self.num_relations, self.d_model)
        self.mlp = nn.Sequential(
            nn.Linear(4 * self.d_model, int(hidden)),
            nn.ReLU(),
            nn.Dropout(float(dropout)),
            nn.Linear(int(hidden), 1),
        )

    def _lookup_rel_emb(self, rel_ids: torch.Tensor, relation_embs: torch.Tensor | None) -> torch.Tensor:
        if relation_embs is None:
            return self.rel_emb(rel_ids.long())
        return relation_embs.index_select(0, rel_ids.long())

    def forward(
        self,
        x_h: torch.Tensor,
        x_t: torch.Tensor,
        rel_id: torch.Tensor,
        relation_embs: torch.Tensor | None = None,
    ) -> torch.Tensor:
        if rel_id.dim() == 0:
            rel_ids = rel_id.unsqueeze(0)
        else:
            rel_ids = rel_id
        e_r = self._lookup_rel_emb(rel_ids, relation_embs).squeeze(0)
        feats = torch.cat([x_h, x_t, x_h * x_t, e_r], dim=0)
        return self.mlp(feats).squeeze(-1)

    def forward_batch(
        self,
        x_h: torch.Tensor,
        x_t: torch.Tensor,
        rel_ids: torch.Tensor,
        relation_embs: torch.Tensor | None = None,
    ) -> torch.Tensor:
        """
        Batched forward pass for multiple triples.

        Args:
            x_h: [B, d] head embeddings
            x_t: [B, d] tail embeddings
            rel_ids: [B] relation IDs

        Returns:
            logits: [B] scores
        """
        e_r = self._lookup_rel_emb(rel_ids, relation_embs)  # [B, d]
        feats = torch.cat([x_h, x_t, x_h * x_t, e_r], dim=1)  # [B, 4*d]
        return self.mlp(feats).squeeze(-1)  # [B]
