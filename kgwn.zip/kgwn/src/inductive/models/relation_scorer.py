from __future__ import annotations

import torch
import torch.nn as nn


class RelationScorer(nn.Module):
    """
    GraIL-style relation prediction head.

    Given (x_h, x_t) it produces logits over relations.
    """

    def __init__(self, *, num_relations: int, d_model: int, hidden: int = 512, dropout: float = 0.1):
        super().__init__()
        self.num_relations = int(num_relations)
        self.d_model = int(d_model)
        self.rel_emb = nn.Embedding(self.num_relations, self.d_model)

        self.fc1 = nn.Linear(3 * self.d_model + self.d_model, int(hidden))
        self.act = nn.ReLU()
        self.drop = nn.Dropout(float(dropout))
        self.fc2 = nn.Linear(int(hidden), 1)

    def forward_all(self, x_h: torch.Tensor, x_t: torch.Tensor) -> torch.Tensor:
        """
        Returns logits [num_relations].
        """
        x_h = x_h.reshape(1, -1)
        x_t = x_t.reshape(1, -1)
        # [R, d]
        e_r = self.rel_emb.weight
        # Broadcast features to [R, d]
        xh = x_h.expand(e_r.size(0), -1)
        xt = x_t.expand(e_r.size(0), -1)
        feats = torch.cat([xh, xt, xh * xt, e_r], dim=1)  # [R, 4d]
        h = self.drop(self.act(self.fc1(feats)))
        return self.fc2(h).squeeze(-1)  # [R]

    def forward(self, x_h: torch.Tensor, x_t: torch.Tensor, rel_id: torch.Tensor) -> torch.Tensor:
        """
        Returns a single logit for rel_id.
        """
        if rel_id.dim() == 0:
            rel_id = rel_id.unsqueeze(0)
        e_r = self.rel_emb(rel_id.long()).reshape(1, -1)
        feats = torch.cat([x_h.reshape(1, -1), x_t.reshape(1, -1), (x_h * x_t).reshape(1, -1), e_r], dim=1)
        h = self.drop(self.act(self.fc1(feats)))
        return self.fc2(h).squeeze(-1).squeeze(0)


class InGramRelationScorer(nn.Module):
    """
    InGram-style relation scorer:
      f(h, r, t) = h^T diag(W z_r) t
    where z_r is a relation embedding and W is a learned projection.
    """

    def __init__(self, *, num_relations: int, d_model: int, rel_emb_dim: int | None = None):
        super().__init__()
        self.num_relations = int(num_relations)
        self.d_model = int(d_model)
        self.rel_emb_dim = int(rel_emb_dim) if rel_emb_dim is not None else int(d_model)
        self.rel_emb = nn.Embedding(self.num_relations, self.rel_emb_dim)
        self.rel_proj = nn.Linear(self.rel_emb_dim, self.d_model, bias=False)

    def _lookup_rel_emb(self, rel_ids: torch.Tensor, relation_embs: torch.Tensor | None) -> torch.Tensor:
        if relation_embs is None:
            return self.rel_emb(rel_ids.long())
        return relation_embs.index_select(0, rel_ids.long())

    def _relation_vectors(self, relation_embs: torch.Tensor | None) -> torch.Tensor:
        if relation_embs is None:
            emb = self.rel_emb.weight
        else:
            emb = relation_embs
        return self.rel_proj(emb)

    def forward_all(self, x_h: torch.Tensor, x_t: torch.Tensor, relation_embs: torch.Tensor | None = None) -> torch.Tensor:
        """
        Returns logits [num_relations].
        """
        pair = (x_h * x_t).reshape(1, -1)  # [1, d]
        rel_vecs = self._relation_vectors(relation_embs)  # [R, d]
        return (pair * rel_vecs).sum(dim=1)  # [R]

    def forward(
        self,
        x_h: torch.Tensor,
        x_t: torch.Tensor,
        rel_id: torch.Tensor,
        relation_embs: torch.Tensor | None = None,
    ) -> torch.Tensor:
        """
        Returns a single logit for rel_id.
        """
        if rel_id.dim() == 0:
            rel_ids = rel_id.unsqueeze(0)
        else:
            rel_ids = rel_id
        e_r = self._lookup_rel_emb(rel_ids, relation_embs).reshape(-1, self.rel_emb_dim)
        rel_vec = self.rel_proj(e_r).squeeze(0)
        return (x_h * x_t * rel_vec).sum()
