from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Sequence, Set, Tuple

import hashlib
import struct

import numpy as np
import torch

from inductive.data.subgraph import EnclosingSubgraphExtractor, Subgraph


def augment_with_inverse(triples: torch.Tensor, *, num_relations_original: int) -> torch.Tensor:
    """
    Add inverse edges: (t, r+R, h) for each (h, r, t), where R=num_relations_original.
    """
    if triples.numel() == 0:
        return triples
    triples = triples.to(dtype=torch.long, device="cpu")
    h = triples[:, 0]
    r = triples[:, 1]
    t = triples[:, 2]
    inv = torch.stack([t, r + int(num_relations_original), h], dim=1)
    return torch.cat([triples, inv], dim=0)


@dataclass(frozen=True)
class SplitGraphs:
    train_edge_index: torch.Tensor  # [2,E]
    train_edge_type: torch.Tensor  # [E]
    test_edge_index: torch.Tensor
    test_edge_type: torch.Tensor


def edge_index_and_type_from_triples(triples: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
    if triples.numel() == 0:
        return torch.empty(2, 0, dtype=torch.long), torch.empty(0, dtype=torch.long)
    triples = triples.to(dtype=torch.long, device="cpu")
    edge_index = triples[:, [0, 2]].t().contiguous()
    edge_type = triples[:, 1].contiguous()
    return edge_index, edge_type


def build_known_true_set(triples: torch.Tensor) -> Set[Tuple[int, int, int]]:
    return set(map(tuple, triples.to(dtype=torch.long, device="cpu").tolist()))


def _hash_u64(*values: int) -> int:
    h = hashlib.blake2b(digest_size=8)
    for val in values:
        h.update(struct.pack("<q", int(val)))
    return int.from_bytes(h.digest(), "little", signed=False)


def sample_negatives_for_pos(
    pos: torch.Tensor,
    *,
    num_neg: int,
    entity_pool: torch.Tensor,
    known_true: Set[Tuple[int, int, int]],
    rng: np.random.Generator | None = None,
    epoch: int | None = None,
) -> torch.Tensor:
    """
    Create `num_neg` negatives by corrupting head or tail.
    If `epoch` is provided, use deterministic hashing instead of RNG.
    """
    h, r, t = (int(pos[0]), int(pos[1]), int(pos[2]))
    pool = entity_pool.to(dtype=torch.long, device="cpu").tolist()
    if not pool:
        raise RuntimeError("Failed to sample a negative (entity_pool is empty)")
    out: List[List[int]] = []
    pool_len = len(pool)
    for neg_idx in range(int(num_neg)):
        cand = (h, r, t)
        for attempt in range(200):
            if epoch is None:
                if rng is None:
                    raise RuntimeError("RNG must be provided when epoch is None.")
                corrupt_tail = bool(rng.random() < 0.5)
                pick = int(pool[int(rng.integers(0, pool_len))])
            else:
                hval = _hash_u64(h, r, t, int(epoch), int(neg_idx), int(attempt))
                corrupt_tail = bool(hval & 1)
                pick = int(pool[(hval >> 1) % pool_len])
            if corrupt_tail:
                cand = (h, r, pick)
            else:
                cand = (pick, r, t)
            if cand != (h, r, t) and cand not in known_true:
                out.append([cand[0], cand[1], cand[2]])
                break
        else:
            # Deterministic fallback: scan the pool to find any valid corruption.
            found = None
            for ent in pool:
                ent = int(ent)
                c1 = (h, r, ent)
                if c1 != (h, r, t) and c1 not in known_true:
                    found = c1
                    break
                c2 = (ent, r, t)
                if c2 != (h, r, t) and c2 not in known_true:
                    found = c2
                    break
            if found is None:
                raise RuntimeError("Failed to sample a negative (entity_pool too small or known_true too dense)")
            out.append([found[0], found[1], found[2]])
    return torch.tensor(out, dtype=torch.long)
