"""
Inductive (entity-disjoint) triple validation pipeline for KGWN.

This package is intentionally self-contained and does not modify the existing
link-prediction training codepaths.
"""

