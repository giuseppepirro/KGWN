#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import torch

from text_init import encode_texts_hf


def _read_entities_file(path: Path) -> List[str]:
    """
    Returns entity tokens in index order (id=0..N-1).
    """
    items: List[Tuple[int, str]] = []
    with open(path, "r") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            tok, idx = line.split()
            items.append((int(idx), tok))
    if not items:
        raise RuntimeError(f"No entities found in {path}")
    items.sort(key=lambda x: x[0])
    max_id = items[-1][0]
    if max_id != len(items) - 1:
        raise RuntimeError(f"Non-contiguous entity IDs in {path}: max_id={max_id}, count={len(items)}")
    return [tok for _, tok in items]


def _try_entities_data_lookup(dataset_dir: Path) -> Optional[Path]:
    cand = dataset_dir / "entities_data.txt"
    return cand if cand.exists() else None


def _load_entities_data(path: Path) -> Dict[str, Tuple[str, str]]:
    """
    Expected format: <entity_id>\\t<name>\\t<desc...>
    """
    out: Dict[str, Tuple[str, str]] = {}
    with open(path, "r") as f:
        for line in f:
            line = line.rstrip("\n")
            if not line:
                continue
            parts = line.split("\t")
            if len(parts) < 2:
                continue
            key = parts[0]
            name = parts[1] if len(parts) >= 2 else ""
            desc = parts[2] if len(parts) >= 3 else ""
            out[key] = (name, desc)
    return out


def _build_texts(tokens: List[str], *, entities_data: Optional[Dict[str, Tuple[str, str]]], prefer: str) -> List[str]:
    prefer = str(prefer)
    texts: List[str] = []
    for tok in tokens:
        if entities_data is None or tok not in entities_data:
            texts.append(tok)
            continue
        name, desc = entities_data[tok]
        if prefer == "name_desc":
            s = (name + " " + desc).strip()
        elif prefer == "name":
            s = str(name).strip()
        elif prefer == "desc":
            s = str(desc).strip()
        else:
            raise ValueError("prefer must be one of: name_desc,name,desc")
        texts.append(s if s else tok)
    return texts


def _default_out_path(root: Path, *, model: str, pooling: str, max_length: int) -> Path:
    safe = model.replace("/", "_")
    return root / f"text_features_entities_{safe}_{pooling}_L{int(max_length)}.pt"


def _one_dir(
    root: Path,
    *,
    model: str,
    pooling: str,
    max_length: int,
    batch_size: int,
    device: str,
    local_files_only: bool,
    prefer: str,
    entities_data_path: Optional[Path],
    out_path: Optional[Path],
) -> Path:
    ent_tokens = _read_entities_file(root / "entities.txt")
    if entities_data_path is None:
        # Try to locate the parent dataset dir (…/src/data/<dataset>/entities_data.txt).
        dataset_dir = root
        if dataset_dir.name.endswith("_ind"):
            dataset_dir = dataset_dir.parent.parent  # …/<dataset>/inductive/<bench>_ind -> …/<dataset>
        else:
            dataset_dir = dataset_dir.parent.parent  # …/<dataset>/inductive/<bench> -> …/<dataset>
        entities_data_path = _try_entities_data_lookup(dataset_dir)

    entities_data = _load_entities_data(entities_data_path) if entities_data_path and entities_data_path.exists() else None
    texts = _build_texts(ent_tokens, entities_data=entities_data, prefer=str(prefer))

    dtype = torch.float16 if str(device) == "mps" else torch.float32
    feats = encode_texts_hf(
        texts,
        model_name_or_path=str(model),
        pooling=str(pooling),
        max_length=int(max_length),
        batch_size=int(batch_size),
        device=str(device),
        local_files_only=bool(local_files_only),
        dtype=dtype,
    )
    # Keep on CPU for saving; normalized.
    out = out_path or _default_out_path(root, model=str(model), pooling=str(pooling), max_length=int(max_length))
    torch.save(feats.to(dtype=dtype), out)
    meta = {
        "num_entities": int(feats.size(0)),
        "dim": int(feats.size(1)),
        "dtype": str(feats.dtype),
        "encoder": "hf",
        "hf_model": str(model),
        "pooling": str(pooling),
        "max_length": int(max_length),
        "prefer": str(prefer),
        "entities_data": str(entities_data_path) if entities_data_path else None,
    }
    with open(str(out) + ".json", "w") as f:
        json.dump(meta, f, indent=2)
    print(f"[OK] {root} -> {out} ({tuple(feats.shape)})")
    return out


def main() -> int:
    p = argparse.ArgumentParser(description="Precompute BERT text features for an AdaProp/GraIL benchmark dir.")
    p.add_argument("--benchmark_dir", type=str, required=True, help="e.g., src/data/wn18rr/inductive/WN18RR_v1")
    p.add_argument("--include_ind", action="store_true", help="Also compute features for '<benchmark_dir>_ind'.")
    p.add_argument("--hf_model", type=str, default="bert-base-uncased")
    p.add_argument("--pooling", type=str, default="cls", choices=["cls", "mean"])
    p.add_argument("--max_length", type=int, default=64)
    p.add_argument("--batch_size", type=int, default=64)
    p.add_argument("--device", type=str, default="cpu")
    p.add_argument("--local_files_only", action="store_true", help="Require HF model files locally.")
    p.add_argument("--prefer", type=str, default="name_desc", choices=["name_desc", "name", "desc"])
    p.add_argument("--entities_data", type=str, default=None, help="Optional path to entities_data.txt for better texts.")
    p.add_argument("--out", type=str, default=None, help="Override output path for the base dir only.")
    args = p.parse_args()

    base = Path(args.benchmark_dir)
    ind = Path(str(base) + "_ind")
    entities_data = Path(args.entities_data) if args.entities_data else None
    out = Path(args.out) if args.out else None

    _one_dir(
        base,
        model=str(args.hf_model),
        pooling=str(args.pooling),
        max_length=int(args.max_length),
        batch_size=int(args.batch_size),
        device=str(args.device),
        local_files_only=bool(args.local_files_only),
        prefer=str(args.prefer),
        entities_data_path=entities_data,
        out_path=out,
    )
    if args.include_ind:
        _one_dir(
            ind,
            model=str(args.hf_model),
            pooling=str(args.pooling),
            max_length=int(args.max_length),
            batch_size=int(args.batch_size),
            device=str(args.device),
            local_files_only=bool(args.local_files_only),
            prefer=str(args.prefer),
            entities_data_path=entities_data,
            out_path=None,
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

