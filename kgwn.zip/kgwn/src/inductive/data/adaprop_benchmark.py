from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import torch


def _read_mapping_tsv(path: Path) -> Dict[str, int]:
    """
    AdaProp format: `<token>\\t<id>` (or whitespace-separated).
    """
    out: Dict[str, int] = {}
    with open(path, "r") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = line.split()
            if len(parts) != 2:
                raise ValueError(f"Bad mapping line in {path}: {line!r}")
            key, idx = parts[0], int(parts[1])
            out[key] = idx
    return out


def _read_triples(path: Path, *, entity2id: Dict[str, int], relation2id: Dict[str, int]) -> torch.Tensor:
    triples: List[List[int]] = []
    with open(path, "r") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            h, r, t = line.split()
            triples.append([int(entity2id[h]), int(relation2id[r]), int(entity2id[t])])
    if not triples:
        return torch.empty(0, 3, dtype=torch.long)
    return torch.tensor(triples, dtype=torch.long)


@dataclass(frozen=True)
class AdaPropInductiveDataset:
    """
    One side of the AdaProp inductive benchmark: a disjoint entity graph with its own entity IDs.
    """

    root: Path
    entity2id: Dict[str, int]
    relation2id: Dict[str, int]
    num_entities: int
    num_relations: int  # original (non-inverse)
    train: torch.Tensor
    valid: torch.Tensor
    test: torch.Tensor


@dataclass(frozen=True)
class AdaPropInductiveBenchmark:
    """
    AdaProp inductive benchmark consists of:
      - transductive graph under `base_dir`
      - inductive graph under `base_dir + '_ind'`

    Both share the same relation set, but have disjoint entity sets.
    """

    base_dir: Path
    ind_dir: Path
    trans: AdaPropInductiveDataset
    ind: AdaPropInductiveDataset


def load_adaprop_benchmark(base_dir: str | Path) -> AdaPropInductiveBenchmark:
    base = Path(base_dir)
    if not base.exists():
        raise FileNotFoundError(f"Benchmark dir not found: {base}")
    ind = Path(str(base) + "_ind")
    if not ind.exists():
        raise FileNotFoundError(f"Inductive counterpart not found: {ind} (expected '{base}_ind')")

    rel_path = base / "relations.txt"
    if not rel_path.exists():
        raise FileNotFoundError(f"Missing relations.txt in {base}")
    relation2id = _read_mapping_tsv(rel_path)

    ent_trans = _read_mapping_tsv(base / "entities.txt")
    ent_ind = _read_mapping_tsv(ind / "entities.txt")

    # Some *_ind folders omit relations.txt; always use base mapping.
    trans = AdaPropInductiveDataset(
        root=base,
        entity2id=ent_trans,
        relation2id=relation2id,
        num_entities=len(ent_trans),
        num_relations=len(relation2id),
        train=_read_triples(base / "train.txt", entity2id=ent_trans, relation2id=relation2id),
        valid=_read_triples(base / "valid.txt", entity2id=ent_trans, relation2id=relation2id),
        test=_read_triples(base / "test.txt", entity2id=ent_trans, relation2id=relation2id),
    )
    ind_ds = AdaPropInductiveDataset(
        root=ind,
        entity2id=ent_ind,
        relation2id=relation2id,
        num_entities=len(ent_ind),
        num_relations=len(relation2id),
        train=_read_triples(ind / "train.txt", entity2id=ent_ind, relation2id=relation2id),
        valid=_read_triples(ind / "valid.txt", entity2id=ent_ind, relation2id=relation2id),
        test=_read_triples(ind / "test.txt", entity2id=ent_ind, relation2id=relation2id),
    )

    return AdaPropInductiveBenchmark(base_dir=base, ind_dir=ind, trans=trans, ind=ind_ds)

