from __future__ import annotations

import json
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import torch


@dataclass(frozen=True)
class InductiveSplit:
    dataset: str
    seed: int
    p_test_entities: float
    p_val_triples: float
    num_entities: int
    num_relations: int
    num_relations_original: int

    v_train: torch.Tensor  # [n_train_entities]
    v_test: torch.Tensor  # [n_test_entities]
    train_pos: torch.Tensor  # [n_train, 3]
    val_pos: torch.Tensor  # [n_val, 3]
    test_pos: torch.Tensor  # [n_test, 3]

    def to_metadata(self) -> Dict:
        meta = asdict(self)
        # Remove tensors from JSON metadata.
        for k in ["v_train", "v_test", "train_pos", "val_pos", "test_pos"]:
            meta.pop(k, None)
        return meta


def _tensorize_triples(triples: Sequence[Sequence[int]]) -> torch.Tensor:
    if not triples:
        return torch.empty(0, 3, dtype=torch.long)
    t = torch.tensor(triples, dtype=torch.long)
    if t.dim() != 2 or int(t.size(1)) != 3:
        raise ValueError(f"Expected triples [N,3], got {tuple(t.shape)}")
    return t


def make_entity_disjoint_split(
    triples: torch.Tensor,
    *,
    dataset: str,
    num_entities: int,
    num_relations: int,
    num_relations_original: int,
    p_test_entities: float = 0.2,
    p_val_triples: float = 0.05,
    seed: int = 0,
    min_rel_train: int = 1,
    max_tries: int = 200,
) -> InductiveSplit:
    """
    Entity-disjoint inductive split.

    - Train/val contain only entities from V_train.
    - Test positives are any triple with at least one entity in V_test.

    Notes:
    - This uses the provided `triples` as the universe (e.g. union of train/valid/test).
    - Relations are kept transductive (same relation IDs across splits).
    """
    if triples.dim() != 2 or int(triples.size(1)) != 3:
        raise ValueError(f"triples must be [N,3], got {tuple(triples.shape)}")
    if not (0.0 < p_test_entities < 1.0):
        raise ValueError("p_test_entities must be in (0,1)")
    if not (0.0 <= p_val_triples < 1.0):
        raise ValueError("p_val_triples must be in [0,1)")
    if num_entities <= 0:
        raise ValueError("num_entities must be > 0")

    triples = triples.to(dtype=torch.long, device="cpu")
    entities_seen = torch.unique(triples[:, [0, 2]].reshape(-1)).tolist()
    entities_seen = [int(e) for e in entities_seen]
    if not entities_seen:
        raise ValueError("No entities found in triples")

    # Prefer sampling test entities from those that actually occur.
    entities_pool = torch.tensor(entities_seen, dtype=torch.long)
    n_test = max(1, int(round(float(p_test_entities) * float(len(entities_pool)))))

    # Precompute relation counts check helper.
    def train_relation_counts(train_triples: torch.Tensor) -> torch.Tensor:
        if train_triples.numel() == 0:
            return torch.zeros(num_relations_original, dtype=torch.long)
        rels = train_triples[:, 1]
        # Only count original relations for this constraint.
        rels = rels[rels < num_relations_original]
        return torch.bincount(rels, minlength=num_relations_original)

    for attempt in range(max_tries):
        gen = torch.Generator(device="cpu")
        gen.manual_seed(int(seed) + attempt)
        perm = torch.randperm(int(entities_pool.numel()), generator=gen)
        v_test = entities_pool[perm[:n_test]]
        v_test_set = set(int(x) for x in v_test.tolist())

        # Train candidates: both endpoints in V_train.
        mask_train = torch.tensor(
            [(int(h) not in v_test_set) and (int(t) not in v_test_set) for h, _, t in triples.tolist()],
            dtype=torch.bool,
        )
        e_train_all = triples[mask_train]
        if e_train_all.numel() == 0:
            continue

        counts = train_relation_counts(e_train_all)
        if min_rel_train > 0 and int((counts >= int(min_rel_train)).sum().item()) != int(num_relations_original):
            continue

        # Test positives: at least one endpoint in V_test.
        mask_test = torch.tensor(
            [(int(h) in v_test_set) or (int(t) in v_test_set) for h, _, t in triples.tolist()],
            dtype=torch.bool,
        )
        e_test = triples[mask_test]

        # Val from train entities only, held out from train triples.
        n_train_total = int(e_train_all.size(0))
        n_val = int(round(float(p_val_triples) * float(n_train_total)))
        n_val = max(1, n_val) if (n_train_total > 1 and p_val_triples > 0) else 0
        if n_val == 0:
            train_pos = e_train_all
            val_pos = torch.empty(0, 3, dtype=torch.long)
        else:
            perm2 = torch.randperm(n_train_total, generator=gen)
            val_idx = perm2[:n_val]
            train_idx = perm2[n_val:]
            val_pos = e_train_all[val_idx]
            train_pos = e_train_all[train_idx]

        # Build V_train from endpoints in train_pos (conservative).
        v_train = torch.unique(train_pos[:, [0, 2]].reshape(-1))
        if len(set(int(x) for x in v_train.tolist()).intersection(v_test_set)) != 0:
            continue

        return InductiveSplit(
            dataset=str(dataset),
            seed=int(seed),
            p_test_entities=float(p_test_entities),
            p_val_triples=float(p_val_triples),
            num_entities=int(num_entities),
            num_relations=int(num_relations),
            num_relations_original=int(num_relations_original),
            v_train=v_train.to(dtype=torch.long),
            v_test=v_test.to(dtype=torch.long),
            train_pos=train_pos.to(dtype=torch.long),
            val_pos=val_pos.to(dtype=torch.long),
            test_pos=e_test.to(dtype=torch.long),
        )

    raise RuntimeError(
        f"Failed to find a valid entity-disjoint split after {max_tries} tries. "
        f"Try decreasing p_test_entities or min_rel_train."
    )


def save_split(split: InductiveSplit, out_dir: str | Path) -> Path:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    torch.save(split.v_train, out / "v_train.pt")
    torch.save(split.v_test, out / "v_test.pt")
    torch.save(split.train_pos, out / "train_pos.pt")
    torch.save(split.val_pos, out / "val_pos.pt")
    torch.save(split.test_pos, out / "test_pos.pt")
    with open(out / "meta.json", "w") as f:
        json.dump(split.to_metadata(), f, indent=2)
    return out


def load_split(split_dir: str | Path) -> InductiveSplit:
    d = Path(split_dir)
    with open(d / "meta.json", "r") as f:
        meta = json.load(f)
    return InductiveSplit(
        dataset=str(meta["dataset"]),
        seed=int(meta["seed"]),
        p_test_entities=float(meta["p_test_entities"]),
        p_val_triples=float(meta["p_val_triples"]),
        num_entities=int(meta["num_entities"]),
        num_relations=int(meta["num_relations"]),
        num_relations_original=int(meta["num_relations_original"]),
        v_train=torch.load(d / "v_train.pt", map_location="cpu"),
        v_test=torch.load(d / "v_test.pt", map_location="cpu"),
        train_pos=torch.load(d / "train_pos.pt", map_location="cpu"),
        val_pos=torch.load(d / "val_pos.pt", map_location="cpu"),
        test_pos=torch.load(d / "test_pos.pt", map_location="cpu"),
    )


def assert_split_sane(split: InductiveSplit) -> None:
    v_train = set(int(x) for x in split.v_train.tolist())
    v_test = set(int(x) for x in split.v_test.tolist())
    if v_train.intersection(v_test):
        raise AssertionError("V_train and V_test are not disjoint")
    for h, _, t in split.train_pos.tolist():
        if int(h) in v_test or int(t) in v_test:
            raise AssertionError("Found a test entity inside train_pos")
    for h, _, t in split.val_pos.tolist():
        if int(h) in v_test or int(t) in v_test:
            raise AssertionError("Found a test entity inside val_pos")
    if split.train_pos.numel() > 0:
        train_set = set(map(tuple, split.train_pos.tolist()))
        if split.val_pos.numel() > 0:
            val_set = set(map(tuple, split.val_pos.tolist()))
            if train_set.intersection(val_set):
                raise AssertionError("train_pos and val_pos overlap")

