"""Inductive data utilities (splits, subgraphs)."""

