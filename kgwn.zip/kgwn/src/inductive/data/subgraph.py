from __future__ import annotations

from dataclasses import dataclass
import os
import threading
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Set, Tuple

import torch


@dataclass(frozen=True)
class Subgraph:
    """
    Enclosing k-hop subgraph around (h, t) in a global graph.

    All node IDs are global entity IDs; edges are stored in LOCAL indexing.
    """

    node_ids: torch.Tensor  # [n] global entity IDs
    edge_index: torch.Tensor  # [2, E] local node indices
    edge_type: torch.Tensor  # [E] relation IDs
    head_idx: int  # local index of h
    tail_idx: int  # local index of t
    dist_to_h: torch.Tensor  # [n] (>=0 or -1 if unreachable in induced graph)
    dist_to_t: torch.Tensor  # [n] (>=0 or -1 if unreachable in induced graph)


def _bfs_k_hop(neighbors: List[List[int]], src: int, k: int) -> Set[int]:
    if k <= 0:
        return {int(src)}
    visited = {int(src)}
    frontier = {int(src)}
    for _ in range(k):
        nxt: Set[int] = set()
        for u in frontier:
            for v in neighbors[u]:
                if v not in visited:
                    visited.add(v)
                    nxt.add(v)
        if not nxt:
            break
        frontier = nxt
    return visited


def _bfs_dist_from_edge_index(edge_index: torch.Tensor, num_nodes: int, src: int) -> torch.Tensor:
    """
    Distances in the induced subgraph (undirected).
    """
    src = int(src)
    dist = torch.full((int(num_nodes),), -1, dtype=torch.long)
    dist[src] = 0

    # Build undirected adjacency list from local edges.
    adj: List[List[int]] = [[] for _ in range(int(num_nodes))]
    if edge_index.numel() > 0:
        heads = edge_index[0].tolist()
        tails = edge_index[1].tolist()
        for u, v in zip(heads, tails):
            u = int(u)
            v = int(v)
            adj[u].append(v)
            adj[v].append(u)

    q = [src]
    qi = 0
    while qi < len(q):
        u = q[qi]
        qi += 1
        du = int(dist[u].item())
        for v in adj[u]:
            if dist[v] < 0:
                dist[v] = du + 1
                q.append(v)
    return dist


class EnclosingSubgraphExtractor:
    """
    k-hop enclosing subgraph extractor backed by adjacency lists.
    """

    def __init__(
        self,
        *,
        num_nodes: int,
        edge_index: torch.Tensor,
        edge_type: torch.Tensor,
        cache_dir: Optional[str | Path] = None,
        cache_log_every: int = 0,
    ):
        if edge_index.dim() != 2 or int(edge_index.size(0)) != 2:
            raise ValueError(f"edge_index must be [2,E], got {tuple(edge_index.shape)}")
        if edge_type.dim() != 1 or int(edge_type.size(0)) != int(edge_index.size(1)):
            raise ValueError(f"edge_type must be [E], got {tuple(edge_type.shape)}")
        self.num_nodes = int(num_nodes)
        self.edge_index = edge_index.to(dtype=torch.long, device="cpu")
        self.edge_type = edge_type.to(dtype=torch.long, device="cpu")

        # Directed edge lists for induced subgraph building.
        self.out_edges: List[List[Tuple[int, int]]] = [[] for _ in range(self.num_nodes)]
        neighbors: List[Set[int]] = [set() for _ in range(self.num_nodes)]
        heads = self.edge_index[0].tolist()
        tails = self.edge_index[1].tolist()
        rels = self.edge_type.tolist()
        for h, r, t in zip(heads, rels, tails):
            h = int(h)
            t = int(t)
            r = int(r)
            if 0 <= h < self.num_nodes and 0 <= t < self.num_nodes:
                self.out_edges[h].append((t, r))
                neighbors[h].add(t)
                neighbors[t].add(h)
        self.neighbors: List[List[int]] = [sorted(list(s)) for s in neighbors]

        # Small LRU cache for repeated queries.
        self._cache: Dict[Tuple[int, int, int], Subgraph] = {}
        self.cache_max = 200000
        self.cache_dir = Path(cache_dir) if cache_dir is not None else None
        if self.cache_dir is not None:
            self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.cache_log_every = int(cache_log_every)
        self._disk_hits = 0
        self._disk_misses = 0
        self._logged_first_hit = False
        self._logged_first_miss = False

    def _cache_path(self, key: Tuple[int, int, int]) -> Path:
        if self.cache_dir is None:
            raise RuntimeError("cache_dir is not set")
        h, t, k = key
        return self.cache_dir / f"{int(h)}_{int(t)}_k{int(k)}.pt"

    def _maybe_log_cache(self, *, kind: str) -> None:
        if self.cache_dir is None:
            return
        total = int(self._disk_hits + self._disk_misses)
        if self.cache_log_every > 0:
            if total % int(self.cache_log_every) == 0:
                print(
                    f"[subgraph cache] {kind} (hits={self._disk_hits} misses={self._disk_misses}) in {self.cache_dir}"
                )
            return
        if kind == "hit" and not self._logged_first_hit:
            self._logged_first_hit = True
            print(f"[subgraph cache] first hit in {self.cache_dir}")
        elif kind == "miss" and not self._logged_first_miss:
            self._logged_first_miss = True
            print(f"[subgraph cache] first miss in {self.cache_dir}")

    def extract(self, h: int, t: int, *, k_hops: int) -> Subgraph:
        h = int(h)
        t = int(t)
        k_hops = int(k_hops)
        key = (h, t, k_hops) if h <= t else (t, h, k_hops)
        cached = self._cache.get(key)
        if cached is not None:
            # Cached subgraph already contains both endpoints, but head/tail order might differ.
            if int(cached.node_ids[cached.head_idx].item()) == h and int(cached.node_ids[cached.tail_idx].item()) == t:
                return cached
            # Re-map head/tail indices.
            inv = {int(e): i for i, e in enumerate(cached.node_ids.tolist())}
            return Subgraph(
                node_ids=cached.node_ids,
                edge_index=cached.edge_index,
                edge_type=cached.edge_type,
                head_idx=int(inv[h]),
                tail_idx=int(inv[t]),
                dist_to_h=_bfs_dist_from_edge_index(cached.edge_index, int(cached.node_ids.numel()), int(inv[h])),
                dist_to_t=_bfs_dist_from_edge_index(cached.edge_index, int(cached.node_ids.numel()), int(inv[t])),
            )

        if self.cache_dir is not None:
            cache_path = self._cache_path(key)
            if cache_path.exists():
                try:
                    cached_disk = torch.load(cache_path, map_location="cpu")
                except Exception:
                    cached_disk = None
                if isinstance(cached_disk, Subgraph):
                    self._disk_hits += 1
                    self._maybe_log_cache(kind="hit")
                    self._cache[key] = cached_disk
                    if int(cached_disk.node_ids[cached_disk.head_idx].item()) == h and int(cached_disk.node_ids[cached_disk.tail_idx].item()) == t:
                        return cached_disk
                    inv = {int(e): i for i, e in enumerate(cached_disk.node_ids.tolist())}
                    return Subgraph(
                        node_ids=cached_disk.node_ids,
                        edge_index=cached_disk.edge_index,
                        edge_type=cached_disk.edge_type,
                        head_idx=int(inv[h]),
                        tail_idx=int(inv[t]),
                        dist_to_h=_bfs_dist_from_edge_index(cached_disk.edge_index, int(cached_disk.node_ids.numel()), int(inv[h])),
                        dist_to_t=_bfs_dist_from_edge_index(cached_disk.edge_index, int(cached_disk.node_ids.numel()), int(inv[t])),
                    )
            self._disk_misses += 1
            self._maybe_log_cache(kind="miss")

        nodes_h = _bfs_k_hop(self.neighbors, h, k_hops)
        nodes_t = _bfs_k_hop(self.neighbors, t, k_hops)
        nodes = nodes_h.union(nodes_t)
        nodes.add(h)
        nodes.add(t)

        node_ids = torch.tensor(sorted(nodes), dtype=torch.long)
        id2local = {int(e): i for i, e in enumerate(node_ids.tolist())}
        head_idx = int(id2local[h])
        tail_idx = int(id2local[t])

        # Induce edges among selected nodes.
        edges_u: List[int] = []
        edges_v: List[int] = []
        edges_r: List[int] = []
        nodes_set = set(id2local.keys())
        for u_global in node_ids.tolist():
            u_global = int(u_global)
            u_local = int(id2local[u_global])
            for v_global, r in self.out_edges[u_global]:
                if int(v_global) in nodes_set:
                    edges_u.append(u_local)
                    edges_v.append(int(id2local[int(v_global)]))
                    edges_r.append(int(r))

        if edges_u:
            edge_index = torch.tensor([edges_u, edges_v], dtype=torch.long)
            edge_type = torch.tensor(edges_r, dtype=torch.long)
        else:
            edge_index = torch.empty(2, 0, dtype=torch.long)
            edge_type = torch.empty(0, dtype=torch.long)

        dist_to_h = _bfs_dist_from_edge_index(edge_index, int(node_ids.numel()), head_idx)
        dist_to_t = _bfs_dist_from_edge_index(edge_index, int(node_ids.numel()), tail_idx)

        sg = Subgraph(
            node_ids=node_ids,
            edge_index=edge_index,
            edge_type=edge_type,
            head_idx=head_idx,
            tail_idx=tail_idx,
            dist_to_h=dist_to_h,
            dist_to_t=dist_to_t,
        )

        if len(self._cache) >= int(self.cache_max):
            # Cheap eviction: clear all.
            self._cache.clear()
        self._cache[key] = sg
        if self.cache_dir is not None:
            cache_path = self._cache_path(key)
            if not cache_path.exists():
                try:
                    tmp_name = f"{cache_path.name}.tmp{os.getpid()}_{threading.get_ident()}"
                    tmp_path = cache_path.with_name(tmp_name)
                    torch.save(sg, tmp_path)
                    if not cache_path.exists():
                        tmp_path.replace(cache_path)
                    else:
                        tmp_path.unlink(missing_ok=True)
                except Exception:
                    pass
        return sg
