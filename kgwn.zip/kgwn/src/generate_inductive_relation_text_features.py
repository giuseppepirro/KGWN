#!/usr/bin/env python3
"""
Generate relation text features for inductive datasets.

Usage:
    python src/generate_inductive_relation_text_features.py --dataset WN18RR_v1_ind
    python src/generate_inductive_relation_text_features.py --dataset fb237_v1_ind --use_hash
"""

from __future__ import annotations

import argparse
from pathlib import Path

import torch

from datasets import KGDataset
from text_init import (
    build_relation_texts,
    encode_texts_feature_hash,
    encode_texts_hf,
)


def main() -> None:
    p = argparse.ArgumentParser(description="Generate relation text features for inductive datasets")
    p.add_argument("--dataset", type=str, required=True, help="Dataset name (e.g., WN18RR_v1_ind)")
    p.add_argument("--induction_kind", type=str, default="relation", choices=["entity", "relation"])
    p.add_argument("--data_root", type=str, default="src/data/inductive", help="Root directory for datasets")
    p.add_argument("--use_hash", action="store_true", help="Use feature hashing instead of BERT")
    p.add_argument("--dim", type=int, default=768, help="Embedding dimension")
    p.add_argument("--max_length", type=int, default=32, help="Max sequence length for BERT")
    p.add_argument("--batch_size", type=int, default=64, help="Batch size for BERT encoding")
    p.add_argument("--device", type=str, default="auto", help="Device (auto/cpu/cuda/mps)")
    p.add_argument("--model_name", type=str, default="bert-base-uncased", help="HuggingFace model name")
    p.add_argument("--pooling", type=str, default="cls", choices=["cls", "mean"], help="Pooling strategy")

    args = p.parse_args()

    # Auto device selection
    if args.device == "auto":
        if torch.cuda.is_available():
            device = "cuda"
        elif torch.backends.mps.is_available():
            device = "mps"
        else:
            device = "cpu"
    else:
        device = args.device

    data_root = Path(args.data_root)
    if data_root.name not in {"entities", "relations"}:
        subdir = "relations" if str(args.induction_kind).lower() == "relation" else "entities"
        data_root = data_root / subdir

    print(f"Loading dataset {args.dataset}...")
    ds = KGDataset(root=str(data_root), name=args.dataset, download=False, percentage=1.0)

    print("Building relation texts...")
    relation_texts = build_relation_texts(ds, prefer="name_desc")
    print(f"Encoding {len(relation_texts)} relation texts (dim={args.dim})...")

    if args.use_hash:
        print("Using feature hashing encoder...")
        features = encode_texts_feature_hash(
            relation_texts,
            dim=args.dim,
            seed=0,
            normalize="l2",
            dtype=torch.float32,
        )
        encoder_name = "hash"
    else:
        print(f"Using HuggingFace encoder: {args.model_name}")
        try:
            features = encode_texts_hf(
                relation_texts,
                model_name_or_path=args.model_name,
                pooling=args.pooling,
                max_length=args.max_length,
                batch_size=args.batch_size,
                device=device,
                local_files_only=False,
                dtype=None,
            )
            encoder_name = args.model_name.replace("/", "_")
        except Exception as e:
            print(f"Error using HuggingFace encoder: {e}")
            print("Falling back to feature hashing...")
            features = encode_texts_feature_hash(
                relation_texts,
                dim=args.dim,
                seed=0,
                normalize="l2",
                dtype=torch.float32,
            )
            encoder_name = "hash"

    output_dir = data_root / args.dataset
    output_path = output_dir / f"text_features_relations_{encoder_name}_{args.pooling}_L{args.max_length}.pt"

    print(f"Saving features to {output_path}...")
    output_dir.mkdir(parents=True, exist_ok=True)
    torch.save(features, output_path)

    print(f"Done! Features shape: {features.shape}")
    print(f"  - Relations: {features.shape[0]}")
    print(f"  - Dimension: {features.shape[1]}")
    print(f"  - Dtype: {features.dtype}")

    assert features.shape[0] == ds.num_relations, \
        f"Feature count {features.shape[0]} != num_relations {ds.num_relations}"

    print("\nYou can now use this file with:")
    print(f"  --relation_text_features_path {output_path}")


if __name__ == "__main__":
    main()
