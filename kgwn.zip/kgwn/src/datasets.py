"""
Knowledge Graph Dataset Loader and Preprocessor
Supports FB15k-237, WN18RR, and other standard KG benchmarks.
"""

import os
import torch
import numpy as np
import requests
import zipfile
import tarfile
from pathlib import Path
from typing import Dict, Tuple, List, Optional
from collections import defaultdict
import pickle


class KGDataset:
    """
    Base class for Knowledge Graph datasets.
    """

    def __init__(self, root: str, name: str, download: bool = True, percentage: float = 1.0):
        """
        Args:
            root: Root directory for datasets
            name: Dataset name (fb15k237, wn18rr, etc.)
            download: Whether to download if not present
            percentage: Percentage of data to use (0.0-1.0). For quick testing.
        """
        self.root = Path(root)
        self.name = name.lower()
        self.data_dir = self.root / self.name
        self.percentage = max(0.0, min(1.0, percentage))

        if download and not self.data_dir.exists():
            self.download()

        # Load data
        self.train_triples, self.valid_triples, self.test_triples = self.load_triples()

        # Subsample early (on string triples) so we can rebuild entity/relation mappings
        # for the subset. Subsampling after building mappings keeps the full entity set,
        # which makes evaluation on small percentages look "broken" (many unseen entities,
        # huge candidate set, and validation/test triples containing entities never trained).
        if self.percentage < 1.0:
            self._subsample_triples()

        # Build entity and relation mappings
        self.entity2id, self.id2entity = self.build_entity_mapping()
        self.relation2id, self.id2relation = self.build_relation_mapping()

        self.num_entities = len(self.entity2id)
        self.num_relations = len(self.relation2id)

        # Convert triples to indices
        self.train_data = self.triples_to_indices(self.train_triples)
        self.valid_data = self.triples_to_indices(self.valid_triples)
        self.test_data = self.triples_to_indices(self.test_triples)

        # Build inverse augmentation
        self.augment_with_inverse()

        print(f"Dataset {self.name} loaded:")
        print(f"  Entities: {self.num_entities}")
        print(f"  Relations (original): {self.num_augmented_relations // 2}")
        print(f"  Relations (after augmentation): {self.num_relations}")
        if self.percentage < 1.0:
            print(f"  Using {self.percentage*100:.1f}% of data for quick testing")
        print(f"  Train triples: {len(self.train_data)}")
        print(f"  Valid triples: {len(self.valid_data)}")
        print(f"  Test triples: {len(self.test_data)}")

    def _subsample_triples(self):
        """
        Subsample triples before building mappings.

        Strategy:
        1) Subsample training triples.
        2) Restrict valid/test to entities+relations seen in the sampled training set.
        3) Subsample the restricted valid/test splits.

        This keeps evaluation meaningful for small `percentage` values by avoiding
        triples with completely unseen entities and by shrinking the candidate set
        (via remapped `entity2id`/`relation2id`).
        """
        train_full = self.train_triples
        valid_full = self.valid_triples
        test_full = self.test_triples

        def sample_list(items):
            if not items:
                return []
            n = max(1, int(len(items) * self.percentage))
            idx = torch.randperm(len(items))[:n].tolist()
            return [items[i] for i in idx]

        # 1) Sample train first
        self.train_triples = sample_list(train_full)

        # Build allowed vocab from sampled train
        train_entities = set()
        train_relations = set()
        for h, r, t in self.train_triples:
            train_entities.add(h)
            train_entities.add(t)
            train_relations.add(r)

        def restrict(items):
            return [
                (h, r, t)
                for (h, r, t) in items
                if (h in train_entities and t in train_entities and r in train_relations)
            ]

        # 2) Restrict valid/test to train vocab.
        #
        # We intentionally do NOT further subsample valid/test: the `percentage` flag is
        # meant to speed up training/experimentation, while keeping evaluation meaningful
        # and less noisy (especially for small percentages).
        valid_restricted = restrict(valid_full)
        test_restricted = restrict(test_full)
        self.valid_triples = valid_restricted
        self.test_triples = test_restricted

        # Ensure non-empty val/test for training loops that always evaluate.
        # If restriction drops everything (possible for tiny percentages), fall back
        # to sampling from training triples (debug-only behavior).
        if not self.valid_triples:
            self.valid_triples = sample_list(self.train_triples)
        if not self.test_triples:
            self.test_triples = sample_list(self.train_triples)

    def download(self):
        """Download dataset."""
        self.data_dir.mkdir(parents=True, exist_ok=True)

        if self.name == 'fb15k237':
            self._download_fb15k237()
        elif self.name == 'wn18rr':
            self._download_wn18rr()
        elif self.name == 'fb15k':
            self._download_fb15k()
        else:
            raise ValueError(f"Unknown dataset: {self.name}")

    def _download_fb15k237(self):
        """Download FB15k-237."""
        url = "https://download.microsoft.com/download/8/7/0/8700516A-AB3D-4850-B4BB-805C515AECE1/FB15K-237.2.zip"
        zip_path = self.data_dir / "FB15k-237.zip"

        print(f"Downloading FB15k-237 from {url}...")
        response = requests.get(url, stream=True)
        response.raise_for_status()

        with open(zip_path, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)

        print("Extracting...")
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(self.data_dir)

        # Move files to correct location
        extracted_dir = self.data_dir / "Release"
        if extracted_dir.exists():
            for file in extracted_dir.glob("*"):
                file.rename(self.data_dir / file.name)
            extracted_dir.rmdir()

        zip_path.unlink()
        print("Download complete!")

    def _download_wn18rr(self):
        """Download WN18RR."""
        url = "https://github.com/TimDettmers/ConvE/raw/master/WN18RR.tar.gz"
        tar_path = self.data_dir / "WN18RR.tar.gz"

        print(f"Downloading WN18RR from {url}...")
        response = requests.get(url, stream=True)
        response.raise_for_status()

        with open(tar_path, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)

        print("Extracting...")
        with tarfile.open(tar_path, 'r:gz') as tar_ref:
            tar_ref.extractall(self.data_dir)

        # Move files
        extracted_dir = self.data_dir / "WN18RR"
        if extracted_dir.exists():
            for file in extracted_dir.glob("*"):
                file.rename(self.data_dir / file.name)
            extracted_dir.rmdir()

        tar_path.unlink()
        print("Download complete!")

    def _download_fb15k(self):
        """Download FB15k."""
        url = "https://everest.hds.utc.fr/lib/exe/fetch.php?media=en:fb15k.tgz"
        tar_path = self.data_dir / "FB15k.tgz"

        print(f"Downloading FB15k from {url}...")
        response = requests.get(url, stream=True)
        response.raise_for_status()

        with open(tar_path, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)

        print("Extracting...")
        with tarfile.open(tar_path, 'r:gz') as tar_ref:
            tar_ref.extractall(self.data_dir)

        tar_path.unlink()
        print("Download complete!")

    def load_triples(self) -> Tuple[List, List, List]:
        """
        Load train/valid/test triples.

        Returns:
            train, valid, test lists of (head, relation, tail) strings
        """
        train_file = self.data_dir / "train.txt"
        valid_file = self.data_dir / "valid.txt"
        test_file = self.data_dir / "test.txt"

        # Try alternative names
        if not train_file.exists():
            train_file = self.data_dir / "train2id.txt"
        if not valid_file.exists():
            valid_file = self.data_dir / "valid2id.txt"
        if not test_file.exists():
            test_file = self.data_dir / "test2id.txt"

        def read_triples(path):
            triples = []
            with open(path, 'r', encoding='utf-8') as f:
                for i, line in enumerate(f):
                    line = line.strip()
                    if not line or (i == 0 and line.isdigit()):
                        continue
                    parts = line.split('\t')
                    if len(parts) >= 3:
                        triples.append((parts[0], parts[1], parts[2]))
            return triples

        train = read_triples(train_file)
        valid = read_triples(valid_file)
        test = read_triples(test_file)

        return train, valid, test

    def build_entity_mapping(self) -> Tuple[Dict, Dict]:
        """Build entity to ID mapping."""
        entities = set()
        for triple in self.train_triples + self.valid_triples + self.test_triples:
            entities.add(triple[0])
            entities.add(triple[2])

        entity2id = {e: i for i, e in enumerate(sorted(entities))}
        id2entity = {i: e for e, i in entity2id.items()}

        return entity2id, id2entity

    def build_relation_mapping(self) -> Tuple[Dict, Dict]:
        """Build relation to ID mapping."""
        relations = set()
        for triple in self.train_triples + self.valid_triples + self.test_triples:
            relations.add(triple[1])

        relation2id = {r: i for i, r in enumerate(sorted(relations))}
        id2relation = {i: r for r, i in relation2id.items()}

        return relation2id, id2relation

    def triples_to_indices(self, triples: List[Tuple[str, str, str]]) -> torch.Tensor:
        """
        Convert string triples to index tensor.

        Args:
            triples: List of (head, relation, tail) strings

        Returns:
            Tensor of shape [num_triples, 3] with indices
        """
        indexed = []
        for h, r, t in triples:
            h_id = self.entity2id[h]
            r_id = self.relation2id[r]
            t_id = self.entity2id[t]
            indexed.append([h_id, r_id, t_id])

        return torch.tensor(indexed, dtype=torch.long)

    def _subsample_data(self):
        """
        Subsample data to use only a percentage of triples.
        Useful for quick testing and debugging.
        """
        if self.percentage >= 1.0:
            return

        # Calculate sizes
        train_size = int(len(self.train_data) * self.percentage)
        valid_size = int(len(self.valid_data) * self.percentage)
        test_size = int(len(self.test_data) * self.percentage)

        # Make sure we have at least some data
        train_size = max(1, train_size)
        valid_size = max(1, valid_size)
        test_size = max(1, test_size)

        # Randomly subsample
        train_indices = torch.randperm(len(self.train_data))[:train_size]
        valid_indices = torch.randperm(len(self.valid_data))[:valid_size]
        test_indices = torch.randperm(len(self.test_data))[:test_size]

        self.train_data = self.train_data[train_indices]
        self.valid_data = self.valid_data[valid_indices]
        self.test_data = self.test_data[test_indices]

    def augment_with_inverse(self):
        """
        Augment with inverse relations (Definition 2.2).

        Creates inverse relation for each original relation.
        """
        # Check if already augmented to prevent double augmentation
        if hasattr(self, '_is_augmented') and self._is_augmented:
            return

        # Number of original relations
        num_original = self.num_relations

        # Add inverse relations to mapping
        for r_id in range(num_original):
            r_name = self.id2relation[r_id]
            inv_r_id = num_original + r_id
            inv_r_name = f"{r_name}_inverse"

            self.relation2id[inv_r_name] = inv_r_id
            self.id2relation[inv_r_id] = inv_r_name

        self.num_augmented_relations = 2 * num_original

        # CRITICAL FIX: Update num_relations so decoder has embeddings for ALL relations!
        self.num_relations = self.num_augmented_relations

        # Augment training data
        self.train_data_aug = self._augment_triples(self.train_data, num_original)
        self.valid_data_aug = self._augment_triples(self.valid_data, num_original)
        self.test_data_aug = self._augment_triples(self.test_data, num_original)

        # Mark as augmented
        self._is_augmented = True

    def _augment_triples(self, triples: torch.Tensor, num_original: int) -> torch.Tensor:
        """
        Add inverse triples: (t, r_inv, h) for each (h, r, t).

        Args:
            triples: [N, 3] tensor
            num_original: Number of original relations

        Returns:
            Augmented triples [2N, 3]
        """
        # Original triples
        heads = triples[:, 0]
        rels = triples[:, 1]
        tails = triples[:, 2]

        # Inverse triples: (tail, rel + num_original, head)
        inv_heads = tails
        inv_rels = rels + num_original
        inv_tails = heads

        # Concatenate
        all_heads = torch.cat([heads, inv_heads])
        all_rels = torch.cat([rels, inv_rels])
        all_tails = torch.cat([tails, inv_tails])

        augmented = torch.stack([all_heads, all_rels, all_tails], dim=1)

        return augmented

    def get_edge_index_and_type(self, use_augmented: bool = True) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Get edge_index and edge_type for GNN processing.

        Args:
            use_augmented: Whether to use inverse-augmented data

        Returns:
            edge_index: [2, num_edges] tensor
            edge_type: [num_edges] tensor
        """
        data = self.train_data_aug if use_augmented else self.train_data

        # edge_index: [2, E] with (head, tail)
        edge_index = data[:, [0, 2]].t()  # [2, E]

        # edge_type: [E]
        edge_type = data[:, 1]  # [E]

        return edge_index, edge_type

    def get_all_triples_dict(self) -> Dict[Tuple[int, int], List[int]]:
        """
        Get dictionary of all observed (h, r) -> [tails].

        Useful for filtered evaluation.
        """
        all_triples = torch.cat([self.train_data, self.valid_data, self.test_data], dim=0)

        hr2t = defaultdict(list)
        for h, r, t in all_triples.tolist():
            hr2t[(h, r)].append(t)

        return dict(hr2t)


class NegativeSampler:
    """
    Negative sampling for link prediction.
    """

    def __init__(self, num_entities: int, num_neg: int = 1):
        """
        Args:
            num_entities: Total number of entities
            num_neg: Number of negative samples per positive
        """
        self.num_entities = num_entities
        self.num_neg = num_neg

    def sample(self, positive_triples: torch.Tensor, corrupt: str = 'tail') -> torch.Tensor:
        """
        Sample negative triples by corrupting heads or tails.

        Args:
            positive_triples: [batch_size, 3] tensor
            corrupt: 'head' or 'tail'

        Returns:
            Negative triples [batch_size * num_neg, 3]
        """
        batch_size = positive_triples.size(0)
        # CRITICAL FIX: Use repeat_interleave, not repeat!
        # repeat_interleave: [[a],[b]] → [[a],[a],[a],[b],[b],[b]] (correct)
        # repeat: [[a],[b]] → [[a],[b],[a],[b],[a],[b]] (wrong - interleaved!)
        neg_triples = positive_triples.repeat_interleave(self.num_neg, dim=0)  # [batch*num_neg, 3]

        # Random entities
        neg_entities = torch.randint(0, self.num_entities, (batch_size * self.num_neg,))

        if corrupt == 'tail':
            neg_triples[:, 2] = neg_entities
        else:
            neg_triples[:, 0] = neg_entities

        return neg_triples


def collate_fn(batch):
    """
    Collate function for DataLoader.

    Args:
        batch: List of triples

    Returns:
        Batched tensor
    """
    return torch.stack(batch, dim=0)


def create_data_loaders(dataset: KGDataset, batch_size: int = 128,
                        num_workers: int = 0) -> Tuple:
    """
    Create PyTorch DataLoaders for train/valid/test.

    Args:
        dataset: KGDataset instance
        batch_size: Batch size
        num_workers: Number of worker processes

    Returns:
        train_loader, valid_loader, test_loader
    """
    from torch.utils.data import TensorDataset, DataLoader

    train_dataset = TensorDataset(dataset.train_data)
    valid_dataset = TensorDataset(dataset.valid_data)
    test_dataset = TensorDataset(dataset.test_data)

    train_loader = DataLoader(
        train_dataset, batch_size=batch_size, shuffle=True,
        num_workers=num_workers, pin_memory=True
    )

    valid_loader = DataLoader(
        valid_dataset, batch_size=batch_size, shuffle=False,
        num_workers=num_workers, pin_memory=True
    )

    test_loader = DataLoader(
        test_dataset, batch_size=batch_size, shuffle=False,
        num_workers=num_workers, pin_memory=True
    )

    return train_loader, valid_loader, test_loader


if __name__ == "__main__":
    # Test dataset loading
    dataset = KGDataset(root="../data", name="fb15k237", download=True)

    edge_index, edge_type = dataset.get_edge_index_and_type()
    print(f"\nEdge index shape: {edge_index.shape}")
    print(f"Edge type shape: {edge_type.shape}")

    # Test negative sampling
    sampler = NegativeSampler(dataset.num_entities, num_neg=5)
    pos_triples = dataset.train_data[:10]
    neg_triples = sampler.sample(pos_triples, corrupt='tail')
    print(f"\nPositive triples: {pos_triples.shape}")
    print(f"Negative triples: {neg_triples.shape}")
