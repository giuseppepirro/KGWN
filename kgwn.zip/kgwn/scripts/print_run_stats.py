#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Dict, Tuple


def _load_results(path: Path) -> Tuple[Path, Dict[str, object]]:
    if path.is_dir():
        path = path / "results.json"
    if not path.exists():
        raise FileNotFoundError(f"results.json not found at {path}")
    with path.open("r") as f:
        data = json.load(f)
    return path, data


def _max_epoch_stat(epoch_stats, key: str) -> float:
    vals = [float(e.get(key, 0.0)) for e in epoch_stats if isinstance(e, dict)]
    return max(vals) if vals else 0.0


def _gb(x: float) -> str:
    return f"{x / (1024 ** 3):.2f} GB" if x > 0 else "n/a"


def main() -> int:
    p = argparse.ArgumentParser(description="Print timing + memory summary from a run.")
    p.add_argument("--run_dir", type=str, required=True, help="Run directory (or results.json path).")
    args = p.parse_args()

    path, data = _load_results(Path(args.run_dir))
    timing = data.get("timing", {}) if isinstance(data, dict) else {}
    epoch_stats = data.get("epoch_stats", []) if isinstance(data, dict) else []

    avg_epoch = float(timing.get("avg_train_epoch_sec", 0.0))
    train_peak = _max_epoch_stat(epoch_stats, "train_peak_mem_bytes")
    val_peak = _max_epoch_stat(epoch_stats, "val_peak_mem_bytes")
    test_peak = float(timing.get("test_peak_mem_bytes", 0.0))
    test_driver = float(timing.get("test_peak_driver_mem_bytes", 0.0))

    print(f"Run: {path.parent}")
    print(f"Avg train epoch: {avg_epoch:.2f} sec" if avg_epoch > 0 else "Avg train epoch: n/a")
    print(f"Train peak mem:  {_gb(train_peak)}")
    print(f"Val peak mem:    {_gb(val_peak)}")
    print(f"Test peak mem:   {_gb(test_peak)}")
    if test_driver > 0:
        print(f"Test driver mem: {_gb(test_driver)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
